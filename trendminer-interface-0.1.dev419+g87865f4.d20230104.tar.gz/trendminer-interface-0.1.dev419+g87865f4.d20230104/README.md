# TrendMiner Python Interface

## Goal 

The goal of this package is to provide a user-friendly interface to all TrendMiner functionality. This allows a user
to automate any in-app workflow with python. As such, this package should prove very useful as a basis for creating
scripts that automate tasks, or that extend upon the basic TrenMiner functionality.

This package is a work in progress. Not all in-app functionality is represented, and the package should not be
considered stable (names may change; functions have not been tested thoroughly).

## Development

To get started with development execute the following:

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
pip install -r dev_requirements.txt
```

### Linting

This package uses [Pylint](https://pylint.org/) to verify the Python code. 
The configuration of the tool is done in `.pylintrc`.

To run the linting:
```
pylint trendminer_core
```


## To Do

- [x] First set of Pylint warnings
- [x] Circular dependency `_access_rule`
- [ ] Re-enable more checkers in Pylint
- [x] Fix OO of `LinkedObject`
  - [x] Separate authentication
  - [x] Separate get/list
  - [x] Separate payload/save
  - [x] copy to dunder?
- [x] `TrendHubView` and `TrendHubViewBeta` (also `Layer` and `LayerBeta`): 
  ideally there is no SDK facing difference between those (see tm-python-sdk)
- [x] Extract `trendminer_confighub` into separate package
- [x] Extract `trendminer_plus` into separate package
- [x] Extract `trendminer_tiles` into separate package
- [x] Rename `trendminer_core` ?? (`trendminer` is already taken by 
  `tm-python-sdk`)
- [x] JSON to object mapping => library available? Instead of from_json/to_json
- [x] to_tile in Tile class (`from_view` from `from_context_view`; 
  `from_work_item`?)
- [x] Tag => extract tag identifier? Link with Attribute/Asset?
- [ ] Converting an object from one user to another/from one server to another
  -> Use case to keep in mind; no focus at this point
- [ ] Elaborate on TrendMiner object
- [ ] Complete functionality for managing context sql connections
- [x] If we use a client object as the basis for all calls, we do not need to underscore module names anymore
- [ ] Implementation of searches and monitors 
- [ ] Implementation of io module (tag and context data import/export) to match new version and code base
- [ ] Implement tag builder functionality
- [ ] Implement compare and statistics tables
- [ ] Implement exporting/importing work organizer objects
- [ ] Add smart cacheing of ojbects where applicable
- [ ] Add blueprint attribute for all classes
- [ ] Getting users currently (likely only works) for local users (fixed endpoint: /local/users/)
- [ ] Review what responses might be paginated and are currently capped by a certain size. These should use the 
automatic paginator that iterates over all pages.
- [ ] Work out token (+url) authentication for use in MLHub
- [ ] Allow full class-based configuration of ContextHub and TrendHub views. Some configuration options are still in raw json format.
- [x] Searching for indexed tags
- [ ] Caching is a problem: lru_cache return the same instance, not a fresh copy of that instance
- [x] Working with the combination of a list of lazy attributes (.lazy) and asserting they are None is giving too many headaches. An attribute could legitimately be None. We should make a dummy placeholder class that explicitly signifies the attribute is lazy.
