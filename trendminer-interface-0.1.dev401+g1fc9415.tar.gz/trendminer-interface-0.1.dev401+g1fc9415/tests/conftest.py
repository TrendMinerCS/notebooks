import pytest
import pickle
import json
import hashlib
import glob
import os
import re
import datetime
from typing import Type

from tests.credentials import user_credentials, client_credentials, confighub_credentials
from trendminer_interface import TrendMinerClient
from confighub_interface import ConfigClient
from tests.mock import MockClient, MockConfigClient


def pytest_addoption(parser):
    parser.addoption(
        "--log",
        action="store",
        default="none",
        choices=("changes", "all", "none"),
        help="logging"
             "\n changes (default): runs test functions that have changed against server, stores output" \
             " Runs unchanged test functions against cached responses." \
             "\n all: runs everything against server, stores outputs" \
             "\n none: runs all functions against cached responses"
    )


def hash_function(request):
    return hashlib.sha1(request.function.__code__.co_code).hexdigest()


def get_folders(request):
    # Base path on test function being executed
    relative_path = re.match("(.*/).*\\.py::.*", os.getenv("PYTEST_CURRENT_TEST"))[1] + request.function.__name__
    main = __file__.replace("tests/conftest.py", relative_path)

    # Make sure main path exists
    os.makedirs(main, exist_ok=True)

    folder_response = os.path.join(main, "response")
    folder_body = os.path.join(main, "body")
    folder_pickle = os.path.join(main, "pickle")

    os.makedirs(folder_response, exist_ok=True)
    os.makedirs(folder_body, exist_ok=True)
    os.makedirs(folder_pickle, exist_ok=True)

    return {
        "main": main,
        "response": folder_response,
        "body": folder_body,
        "pickle": folder_pickle,
    }


def log_history(folders, request, client):

    client.history_df.to_csv(os.path.join(folders["main"], f'{request.fixturename}.csv'))

    for i, response in enumerate(client.history):

        f_pickle = os.path.join(folders["pickle"], f"{request.fixturename}{i:03}.pkl")
        with open (f_pickle, 'wb') as f:
            pickle.dump(response, f)

        f_response = os.path.join(folders["response"], f"{request.fixturename}{i:03}.json")
        try:
            with open(f_response, 'w') as f:
                json.dump(response.json(), f, indent=4)

        except json.JSONDecodeError:
            with open(f_response, 'wb') as f:
                f.write(response.content)

        if response.request.body is None:
            continue
        try:
            data = json.loads(response.request.body)
            f_body = os.path.join(folders["body"], f"{request.fixturename}{i:03}.json")
            with open(f_body, 'w') as f:
                json.dump(data, f, indent=4)
        except json.JSONDecodeError:
            f_body = os.path.join(folders["body"], f"{request.fixturename}{i:03}.txt")
            if isinstance(response.request.body, str):
                data = response.request.body
                data = re.sub("(?<=password=)[^\n]*", "***********", data)  # do not print password
                with open(f_body, 'w') as f:
                    f.write(data)
            else:
                with open(f_body, 'wb') as f:
                    f.write(response.request.body)


def clear_history(folders, request):
    for filename in glob.glob(os.path.join(folders['response'], f"{request.fixturename}*.json")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['pickle'], f"{request.fixturename}*.pkl")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['body'], f"{request.fixturename}*.json")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['main'], f"*.csv")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['main'], f"*.txt")):
        os.remove(filename)


def get_history(folders, request):
    responses = []
    filenames = glob.glob(os.path.join(folders['pickle'], f"{request.fixturename}*.pkl"))
    filenames = sorted(filenames)
    for filename in filenames:
        with open(filename, "rb") as f:
            responses.append(pickle.load(f))
    return responses


def run_against_server(request, folders):
    logging = request.config.getoption("--log")

    if logging == "all":
        return True

    elif logging == "changes":
        try:
            with open(os.path.join(folders["main"], "hash.txt"), "r") as f:
                previous_hash = f.read()
        except FileNotFoundError:
            previous_hash = None

        if previous_hash != hash_function(request):
            return True

    return False


def open_client(request, credentials, client_type: Type = TrendMinerClient, mock_type: Type = MockClient):
    folders = get_folders(request)

    against_server = run_against_server(request, folders)

    if against_server:
        clear_history(folders, request)
        client = client_type(**credentials, keep_history=True)
    else:
        client = mock_type(**credentials, history=get_history(folders, request))

    return client, folders, against_server


def close_client(folders, request, client):
    log_history(folders, request, client)

    if request.session.testsfailed == 0:
        function_hash = hash_function(request)
        with open(os.path.join(folders["main"], "hash.txt"), "w") as f:
            f.write(function_hash)


@pytest.fixture
def user(request):
    client, folders, rerun = open_client(request, credentials=user_credentials)
    yield client
    if rerun:
        close_client(folders, request, client)


@pytest.fixture
def client(request):
    client, folders, rerun = open_client(request, credentials=client_credentials)
    yield client
    if rerun:
        close_client(folders, request, client)


@pytest.fixture
def cfg(request):
    client, folders, rerun = open_client(
        request,
        credentials=confighub_credentials,
        client_type=ConfigClient,
        mock_type=MockConfigClient
    )
    yield client
    if rerun:
        close_client(folders, request, client)


@pytest.fixture
def prefix(request):
    """Yields a time-based prefix for creating new items to avoid clashes with existing or soft-deleted items"""
    folders = get_folders(request)
    file_path = os.path.join(folders["main"], f"prefix.txt")

    try:
        with open(file_path, "r") as f:
            pf = f.read()
    except FileNotFoundError:
        pf = None

    if pf is None or run_against_server(request, folders):
        pf = 'QA%d' % datetime.datetime.now().timestamp()
        yield pf
        with open(file_path, "w") as f:
            f.write(pf)
    else:
        yield pf

