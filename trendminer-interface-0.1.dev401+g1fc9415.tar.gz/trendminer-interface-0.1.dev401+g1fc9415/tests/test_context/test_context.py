from pprint import pprint
import json


def test_cleanup(user):

    ctypes = user.context.type.by_key('QA*')

    if len(ctypes) > 0:
        # delete items
        view = user.context.view(filters=[
            user.context.filter.context_types(ctypes),
        ])
        view.delete_items()

    # delete types
    for ctype in ctypes:
        ctype.delete()

    # delete fields
    cfields = user.context.field.by_name('QA*')
    for cfield in cfields:
        cfield.delete()

    # delete workflows
    cflows = user.context.workflow.by_name('QA*')
    for cflow in cflows:
        cflow.delete()


def test_view(user, prefix):
    folder = user.folder(prefix)
    folder.post()
    view = user.context.view(
        [
            user.context.filter.period("1y")
        ],
        name=prefix,
        description=prefix,
        folder=prefix,
    )
    view.post()
    view = user.context.view.from_path(f"{prefix}/{prefix}")
    print(view)
    assert len(view.filters) > 0
    folder.delete()

    filters = [
        user.context.filter.period('1h')
    ]
    view = user.context.view(filters=filters, name=prefix)
    view.post()
    view.filters = view.filters + [user.context.filter.users(user.user.self())]
    view.description = "new_description"
    view.put()
    view2 = user.context.view.get(view.identifier)
    assert view2.description == view.description
    view2.delete()


def test_full_flow(user, prefix):

    # fields
    all_fields = user.context.field.all()
    assert all_fields

    key_num = prefix + "num"
    f_num = user.context.field(key=key_num,
                               name=key_num,
                               field_type="Numeric",
                               placeholder='numeric field')
    f_num.post()
    f_num.placeholder = 'edited placeholder'
    f_num.put()

    key_str = prefix + "str"
    f_str = user.context.field(key=key_str,
                               name=key_str,
                               field_type="STRING",
                               placeholder='string field')
    f_str.post()
    f_str.name = f_str.name + "_edited"
    f_str.put()

    key_enum = prefix + "enum"
    f_enum = user.context.field(key=key_enum,
                                name=key_enum,
                                field_type="enumeration",
                                placeholder=None,
                                options=["yes", "no"])
    f_enum.post()
    f_enum.options.append("maybe")
    f_enum.put()

    # workflow
    wf = user.context.workflow(name=prefix+"wf",
                               states=["QA_start", "QA_end"],
                               )
    wf.post()

    # types
    type1 = user.context.type(key=prefix+"t1",
                              name="QA type 1",
                              workflow=wf,
                              fields=[f_num.name, f_str.key, f_enum.identifier],
                              color="green",
                              audit_trail_enabled=True,
                              approvals_enabled=True
                              )
    type1.post()
    type1.name = type1.name + " updated"
    type1.put()

    type2 = user.context.type(key=prefix+"t2",
                              name="QA type 2",
                              workflow=None,
                              fields=[f_num, f_str],
                              color=None,
                              audit_trail_enabled=False,
                              approvals_enabled=False
                              )
    type2.post()
    type2.color = 'blue'
    type2.fields = type2.fields + [f_enum]
    type2.put()

    # items
    other_property_key = prefix + '_other'
    component = '[CS]BA:ACTIVE.1'
    item = user.context.item(context_type=type1.key,
                             components=[component],
                             events=user.time.slice('1h'),
                             keywords=[prefix],
                             fields={
                                 f_str: 'test',
                                 f_enum.key: 'yes',
                                 f_num.key: 12.3,
                                 other_property_key: 'other',
                             }
                             )
    item.post()
    item.description = prefix
    item.put()
    item.approve()
    item.remove_approval()
    item.approve()
    assert item.interval.data
    assert item.key == user.context.item.get(item.identifier).key
    assert user.context.item.get(item.key).description == item.description

    # filters
    kw = user.context.filter.keywords([prefix])
    filter_sets = [
        [kw],
        [user.context.filter.field(field=f_num, values=[">12", ('<', 15)])],
        [user.context.filter.field(field=f_str, values=['test', 'foo'])],
        [user.context.filter.field(field=f_enum, values=['yes', 'maybe'])],
        [user.context.filter.property(key=other_property_key, values='other')],
        [user.context.filter.approval(True), kw],
        [user.context.filter.context_types([type1.key])],
        [user.context.filter.users([user.user.self()]), kw],
        [user.context.filter.components([component]), kw],
        [user.context.filter.duration(['> 50m', ('<', 3700)]), kw],
        [user.context.filter.description(prefix)],
        [user.context.filter.interval(user.time.interval('1h')), kw],
        [user.context.filter.period(user.time.period('1h')), kw],
        [user.context.filter.states(['QA_end']), kw],
        [user.context.filter.interval(user.time.interval('1h').shift("5m"), created_date=True), kw],
        [user.context.filter.created_date(('<=', user.time.now() + user.time.timedelta("5m"))), kw]
    ]

    for i, filters in enumerate(filter_sets):
        print(f"{i} - {filters}")
        chv = user.context.view(
            name=f"{prefix}_view{i}",
            description="view test",
            filters=filters,
        )
        chv.post()
        chv = user.context.view.from_identifier(chv.identifier)
        assert len(chv.search_items()) == 1
        chv.delete()

    # cleanup
    item.delete()
    type1.delete()
    type2.delete()
    f_num.delete()
    f_str.delete()
    f_enum.delete()
    wf.delete()


def test_items(user):
    anomaly = user.context.item(context_type="ANOMALY",
                                events=["2021", "2022"],
                                components=["[CS]BA:ACTIVE.1"])

    anomaly = user.context.item(context_type="ANOMALY",
                                events=user.time.interval("2021", "2022"),
                                components=["[CS]BA:ACTIVE.1"])

    info = user.context.item(context_type="INFORMATION",
                             events=["2021-01-01"],
                             components=["[CS]BA:ACTIVE.1"])

    info = user.context.item(context_type="INFORMATION",
                             events=user.time.datetime("2021-01-01"),
                             components=["[CS]BA:ACTIVE.1"])

    info.post()

    item = user.context.item.get(info.identifier)
    item.delete()

    item = user.context.item(context_type="ANOMALY",
                             components=["[CS]BA:CONC.1"],
                             events=user.time.slice("8h"),
                             description="sdk test",
                             keywords=["QA"],
                             )
    item.post()
    item = user.context.item.get(item.key)
    item = user.context.item.get(item.identifier)
    assert item.interval.start.tzinfo.zone == "Europe/Brussels"
    item.delete()


def test_bulk_items(client, prefix):
    intervals = client.time.interval("1y").split(max_size="1d")
    item = client.context.item("Anomaly", components="[CS]BA:ACTIVE.1", keywords=[prefix])
    items = [item.copy({"events": interval}) for interval in intervals]
    client.context.item.bulk_post(items)
    chv = client.context.view(
        filters = [
            client.context.filter.keywords([prefix])
        ]
    )
    assert len(chv.search_items()) == len(intervals)
    chv.delete_items()


def test_from_search(user, prefix):
    vbs = user.search.value(
        queries=[("[CS]BA:CONC.1", ">", 42)],
        operator="AND"
    )

    results = vbs.get_results("6M")

    kw = "QA_sdk_test_from_search"

    item = user.context.item(
        context_type="ANOMALY",
        components="[CS]BA:CONC.1",
        events=None,
        description=None,
        fields=None,
        keywords=[prefix, f"{prefix}/{prefix}.xlsx", kw]
    )

    items = [item.copy({"events": result}) for result in results]

    user.context.item.bulk_post(items)

    chv = user.context.view(
        filters=[user.context.filter.keywords([kw])]
    )

    chv.delete_items()
