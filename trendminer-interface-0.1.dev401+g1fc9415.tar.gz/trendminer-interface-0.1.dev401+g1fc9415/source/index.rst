trendminer-interface
====================

.. toctree::
   :maxdepth: 2

   get_started
   how_to/index
   references
