.. _client:

======
client
======
.. currentmodule:: trendminer_interface

.. autoclass:: TrendMinerClient
    :inherited-members:
