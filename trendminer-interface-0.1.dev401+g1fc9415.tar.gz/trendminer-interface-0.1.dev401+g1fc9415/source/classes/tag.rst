Tag
===
.. currentmodule:: trendminer_interface
.. autoclass:: trendminer_interface.tag.Tag(..)

Client methods
--------------
``client.tag``

Construction
************
.. automethod:: trendminer_interface.tag.TagFactory::__call__

Retrieval
*********

.. automethod:: trendminer_interface.tag.TagFactory::from_name
.. automethod:: trendminer_interface.tag.TagFactory::from_identifier
.. automethod:: trendminer_interface.tag.TagFactory::from_attribute


.. automethod:: trendminer_interface.tag.TagFactory::by_name
.. automethod:: trendminer_interface.tag.TagFactory::by_description

Other
*****
.. automethod:: trendminer_interface.tag.TagFactory::delete_imported

Attributes and properties
-------------------------
.. autoattribute:: trendminer_interface.tag.Tag::name

    Unique tag name

.. autoattribute:: trendminer_interface.tag.Tag::description

    Description providing additional info on the tag

.. autoattribute:: trendminer_interface.tag.Tag::units

    Measurement physical units. Can be blank. Units are never interpreted by the appliance, ``units`` is simply a string
    metadata property that gives the user additional information.

.. autoattribute:: trendminer_interface.tag.Tag::tag_type

    - **ANALOG**: numerical values, linear interpolation
    - **DISCRETE**: numerical values, step-after interpolation
    - **DIGITAL**: Selection from fixed set of string values, step-after interpolation
    - **STRING**: Any string value, step after interpolation

    STRING and DIGITAL tags are treated exactly the same in TrendMiner: a state is created for every new string tag
    value

.. autoattribute:: trendminer_interface.tag.Tag::data

    Timeseries data as a ``pandas.Series`` object. Can be set directly by the user with the purpose to create a new tag via
    csv upload, or can be set with the ``get_data`` method for an existing tag.

    The data Series instance has the following properties:

    - **name** is equal to the tag name
    - **index** is a DatetimeIndex. If a timezone-unaware index is given by the user, it is assumed to be in the client
      timezone.
    - **dtype** is ``float64`` for numeric tags, ``str`` for string tags

.. autoattribute:: trendminer_interface.tag.Tag::color

    The tag color as a ``Color`` object. Only relevant when the tag is in a TrendHub view. The color can be set by the
    user by assigning a color string or a ``Color`` object. For example::

        tag.color = "blue"
        tag.color = "#ff0000"

    For more info and examples: https://pypi.org/project/colour/

.. autoattribute:: trendminer_interface.tag.Tag::scale

    Scale as a ``[min, max]`` list of two values for manual scale, ``None`` for auto-scale. Only relevant when the tag
    is in a TrendHub view. Can be set by the user.

.. autoattribute:: trendminer_interface.tag.Tag::shift

    Tag shift as a ``datetime.timedelta``. Impacts getting data, searches, calculations and TrendHub view appearance.
    Can be set by the user.

.. autoattribute:: trendminer_interface.tag.Tag::visible

    Boolean indicating if the tag is visible in the TrendHub view. Can be set by the user.

.. autoattribute:: trendminer_interface.tag.Tag::interpolation

.. autoattribute:: trendminer_interface.tag.Tag::index

.. autoattribute:: trendminer_interface.tag.Tag::calculate


Methods
-------
.. automethod:: trendminer_interface.tag.Tag::index()
    :noindex:

.. automethod:: trendminer_interface.tag.Tag::isnumeric

.. automethod:: trendminer_interface.tag.Tag::get_data
