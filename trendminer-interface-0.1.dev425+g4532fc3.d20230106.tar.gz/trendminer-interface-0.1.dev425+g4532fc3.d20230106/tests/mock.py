import pytz
import datetime
import json

from trendminer_interface.client import ClientCollection
from trendminer_interface.authentication.session import TrendMinerSession

from confighub_interface.client import ConfigClientCollection
from confighub_interface.authentication import ConfigSession


class MockSession(ConfigSession):
    def __init__(self, base_url, *args, **kwargs):
        super().__init__(base_url=base_url, verify=True, keep_history=False)
        self.history = []  # is set in MockClient constructor
        self.k = 0

    def request(self, method, url, *args, **kwargs):
        kwargs = self._set_kwargs(kwargs)

        if "json" in kwargs:
            json.dumps(kwargs["json"])  # might load lazy objects as would happen with a real request

        while True:
            response = self.history[self.k]
            self.k += 1
            if not response.is_redirect:
                break

        hooks = kwargs['hooks'].get("response", [])
        for hook in hooks:
            hook(response)

        return response

    @property
    def token_decoded(self):
        return self.userinfo()

    @property
    def access_expired(self):
        return False

    @property
    def token(self):
        return self._token

    @token.setter
    def token(self, token):
        self._token = token

    def login(self, *args, **kwargs):
        self.token = {"access_token": datetime.datetime.now().isoformat()}

    def logout(self, *args, **kwargs):
        pass

    def token_refresh(self):
        self.token = {"access_token": datetime.datetime.now().isoformat()}

    def userinfo(self):
        return {
            'createdDate': 1550000000000,
            'email': 'mockclient@softwareag.com',
            'email_verified': False,
            'family_name': 'Session',
            'given_name': 'Mock',
            'name': 'Mock Session',
            'preferred_username': 'mocksession',
            'roles': ['default-roles-trendminer', 'offline_access', 'tm_admin'],
            'sub': '00000000-0000-0000-0000-000000000000'
        }

    def config_login(self, password):
        # history is not loaded yet on login, skip request but increment k
        self.k += 3  # There are 2 redirects so we need to skip 3 requests

    def _confighub_token_refresh(self):
        pass


class MockClient(ClientCollection):
    def __init__(self, url, client_id, client_secret, history, username=None, tz=pytz.utc, *args, **kwargs):
        super().__init__(url=url,
                         client_id=client_id,
                         client_secret=client_secret,
                         username=username,
                         password=None,
                         token=None,
                         verify=False,
                         keep_history=False,
                         session_type=MockSession,
                         tz=tz)
        self.session.history = history
        self._username = username or f"service-account-{client_id}"

    @property
    def username(self):
        return self._username

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.session.base_url} >>"


class MockConfigClient(ConfigClientCollection):
    def __init__(self, url, history, tz=pytz.utc, *args, **kwargs):
        super().__init__(
            url=url,
            password=None,
            verify=False,
            keep_history=False,
            tz=tz,
            session_type=MockSession,
        )
        self.session.history = history