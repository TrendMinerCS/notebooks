trendminer-interface
====================

.. toctree::
    :maxdepth: 2

    how_to/index
    references
    use_cases/index

