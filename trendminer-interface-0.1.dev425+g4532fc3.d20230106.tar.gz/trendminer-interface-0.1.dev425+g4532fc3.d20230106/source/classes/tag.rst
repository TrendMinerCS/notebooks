.. currentmodule:: trendminer_interface.tag

Tag
===
.. autoclass:: Tag()
    :members: interpolation, get_data, data, index, calculate

Client Methods
==============
.. autoclass:: TagFactory
    :members: __call__, from_identifier, from_name, from_attribute, all, by_name, by_description, index

