.. currentmodule:: trendminer_interface.tag.index

IndexStatus
============
.. autoclass:: IndexStatus()
    :members: __call__, refresh, delete

Client Methods
==============
.. autoclass:: IndexStatusFactory
    :members: all, from_identifier, from_tag, by_name
