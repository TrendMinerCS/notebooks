import abc
import json

import trendminer_interface._input as ip

from trendminer_interface.base import TrendMinerFactory, HasOptions, ByFactory, Savable

from .connector import ConnectorFactory
from .constants import datasource_default_raw

datasource_options = list(datasource_default_raw.keys())


class DatasourceClient(abc.ABC):
    @property
    def datasource(self):
        return DatasourceFactory(client=self)


class Datasource(Savable):
    endpoint = "/ds/datasources/"

    connector = ByFactory(ConnectorFactory)
    provider = HasOptions(datasource_options)

    def __init__(
            self,
            client,
            name,
            connector,
            identifier,
            provider,
            host,
            tagfilter,
            prefix,
            username,
            max_connections,
            raw,
    ):
        super().__init__(client=client, identifier=identifier)

        self.name = name
        self.connector = connector
        self.username = username
        self.host = host
        self.provider = provider
        self.tagfilter = tagfilter or ""
        self.prefix = prefix or ""
        self.max_connections = max_connections
        self.raw = raw or datasource_default_raw[self.provider]

    def _post_updates(self, response):
        self.identifier = response.json()["datasourceId"]

    def connection_properties(self, password):
        return {
            "prefix": self.prefix,
            "connectionString": self.host,
            "provider": self.provider,
            "tagFilter": self.tagfilter,
            "username": self.username,
            "password": password,
            "version": "other",
        }

    def __json__(self, password=""):
        return {
            "builtin": False,
            "capabilityTypes": ["TIME_SERIES"],
            "connectionProperties": json.dumps(self.connection_properties(password=password), separators=(",", ":")),
            "connectorId": self.connector.identifier,
            "datasourceId": self.identifier,
            "maxConnections": self.max_connections,
            "name": self.name,
            "onlySupportsRawValues": self.raw,
            "providerTypeProperties": [
                {"name": "TAGFILTER", "value": self.tagfilter, "encrypted": False}
            ],
            "type": self.provider
        }

    def post(self, password=""):
        self.identifier = None  # prevents accidental overwriting
        payload = self.__json__(password=password)
        response = self.client.session.post(self.endpoint, json=payload)
        self._post_updates(response)

    def put(self, password=""):
        payload = self.__json__(password=password)
        response = self.client.session.put(self.link, json=payload)
        self._put_updates(response)

    def blueprint(self):
        raise NotImplementedError()

    def __repr__(self):
        return f"<< Datasource | {self.name} | {self.provider} >>"


class DatasourceFactory(TrendMinerFactory):
    tm_class = Datasource

    def __call__(
            self,
            name,
            connector,
            provider,
            host,
            tagfilter=None,
            prefix=None,
            username="",
            max_connections=None,
            raw=None,
    ):
        return self.tm_class(
            client=self.client,
            name=name,
            identifier=None,
            connector=connector,
            provider=provider,
            host=host,
            tagfilter=tagfilter,
            prefix=prefix,
            username=username,
            max_connections=max_connections,
            raw=raw,
        )

    def all(self):
        params = {"size": 1000}
        content = self.client.session.paginated(keys=["content"]).get(self.tm_class.endpoint, params=params)
        content = [ds for ds in content if ds["type"] in datasource_options]
        return [self.from_json(data) for data in content]

    def from_json(self, data):
        cp = json.loads(data["connectionProperties"])

        return self.tm_class(
            client=self.client,
            name=data["name"],
            connector=ConnectorFactory(client=self.client).from_json_identifier_only(data["connectorId"]),
            identifier=data["datasourceId"],
            provider=data["type"],
            host=cp["connectionString"],
            tagfilter=cp["tagFilter"],
            prefix=cp["prefix"],
            username=cp["username"],
            max_connections=data["maxConnections"],
            raw=data["onlySupportsRawValues"],
        )

    def from_name(self, ref):
        return ip.object_match_nocase(self.all(), "name", ref)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name