import pandas as pd


def test_asset(user):
    assets = user.asset.by_name(ref="Hasselt")
    assets = user.asset.by_description(ref="Hasselt")
    assets = user.asset.by_template(ref="SIN-CH")
    print(assets)

    asset = user.asset.from_identifier("38577c7d-6ca2-4d06-8210-f1b3f7ada431")
    print(asset.source)
    root = user.asset.root()
    print(root.children)
    assets = user.asset.by_template(ref="SIN-CH", frameworks="Edwards")
    print(assets)

    asset = user.asset.get("AF-example/Europe/Belgium")
    asset = user.asset.from_path("AF-example/Europe/Belgium")
    asset = user.asset.from_identifier(asset.identifier)
    print(asset)
    print(asset.children)
    print(asset.parent)
    print(asset.path)


def test_frameworks(user):
    frameworks = user.asset.framework.all()[0:5]
    for fw in frameworks:
        print(fw.name)
        print(fw.root_asset.children)
        if fw.sync.status == "DONE_WITH_ERRORS":
            try:
                print(fw.get_errors())
            except FileNotFoundError:
                pass
        elif fw.af_type != "CSV":
            print(fw.af_type)
        else:
            fw.export()


def test_framework_create(user, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "/"+prefix, prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = user.asset.framework(name=prefix, df=df)
    af.post()
    print(af.ordering)
    af = user.asset.framework.from_identifier(af.identifier)
    af.delete()


def test_framework_errors(user, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "incorrect path", prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = user.asset.framework(name=prefix, df=df)
    af.post()
    while True:
        if af.sync.status != "RUNNING":
            break
    print(af.get_errors())
    af.delete()


def test_attribute(user):
    asset = user.asset.from_identifier("a164876e-55b7-4d3a-b1e4-752b3c50d1a0")
    asset = user.asset.get(asset.path)
    print(asset.tag)


def test_access(user):
    asset = user.asset.root().children[1]
    print(asset.access.all())
    print(asset.children[0].access_inherited.all())


def test_sync_status(user):
    syncs = user.asset.framework.sync.all()
    print(syncs)
    print(syncs[0].started)
    print(syncs[0].ended)
