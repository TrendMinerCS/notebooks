import cachetools

from trendminer_interface.base import TrendMinerFactory, LazyAttribute, ByFactory
import trendminer_interface._input as ip
from .access import MemberFactoryGroup, Member, HasMembers


class GroupClient():
    @property
    def group(self):
        return GroupFactory(client=self)


class Group(Member, HasMembers):
    endpoint = "confighub/groups/"
    member_type = "GROUP"
    parent = ByFactory(lambda *args, **kwargs: GroupFactory(*args, **kwargs))  # not yet defined, circumvent w lambda

    def __init__(self, client, identifier, name, parent):
        Member.__init__(self, client=client, identifier=identifier, name=name)
        self.parent = parent

    @property
    def path(self):
        if self.parent is None:
            return f"/{self.name}"
        return "/".join([self.parent.path, self.name])

    def members_get(self):
        response = self.client.session.get(f"{self.link}/members")
        return [MemberFactoryGroup(client=self.client)._from_json(member) for member in response.json()]

    def member_add_list(self, members):
        members = MemberFactoryGroup(client=self.client).list(members)
        self.client.session.put(f"{self.link}/members", json=[member.json_member() for member in members])

    def member_add(self, member):
        self.member_add_list([member])

    def member_remove(self, member):
        member = MemberFactoryGroup(client=self.client).get(member)
        self.client.session.delete(f"{self.link}/members/{member.identifier}")

    def _post_updates(self, response):
        self.identifier = response.json()["id"]

    def _full_instance(self):
        if ("identifier" in self.lazy) or self.identifier is None:
            return GroupFactory(client=self.client).from_name(self.name)
        else:
            return GroupFactory(client=self.client).from_identifier(self.identifier)

    def __json__(self):
        return {
            "id": self.identifier,
            "name": self.name,
        }

    def blueprint(self):
        raise NotImplementedError


class GroupFactory(TrendMinerFactory):
    tm_class = Group

    def __call__(self, name):
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            parent=self.local(),
        )

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=10), key=TrendMinerFactory._cache_key_no_args)
    def local(self):
        return self.from_name("local")

    def by_name(self, ref):
        params = {
            "size": 1000,
            "enabled": True,
            "searchPattern": ref,
        }
        content = self.client.session.paginated(keys=["content"]).get("confighub/groups", params=params)
        return [self._from_json(group) for group in content]

    def from_name(self, ref):
        return ip.object_match_nocase(self.by_name(ref), "name", ref)

    def _from_json_path_only(self, data):
        # Iteratively create a structure of parent groups, identified only by their names
        parts = data.split("/")
        if len(parts) == 1:
            parent = None
            name = parts[0]
        else:
            name = parts[-1]
            parent = self._from_json_path_only("/".join(parts[0:-1]))
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=name,
            parent=parent,
        )

    def _from_json_name_only(self, data):
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=data,
            parent=LazyAttribute(),
        )

    def _from_json_member_acl(self, data):
        return self._from_json_path_only(data["name"])

    def _from_json_member_group(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            parent=LazyAttribute(),
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Group
        """
        path_parts = "/".split(data["path"])
        parent_path = "/".join(path_parts[:-1])
        if parent_path:
            parent = self._from_json_path_only(data=data["path"])
        else:
            parent = None
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            parent=parent
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    @property
    def _search_methods(self):
        return self.by_name,



