import json
import keyring
import pandas as pd
import glob
import os

from getpass import getpass

from confighub_interface import ConfigClient
from trendminer_interface import TrendMinerClient

password_placeholder = "QA-Passw0rd-Pl@ceholder"
key_prefix = "sdkqa0"

user_config = {
    "user1": {
        "suffix": "u1",
        "admin": False,
    },
    "user2": {
        "suffix": "u2",
        "admin": False,
    },
    "admin": {
        "suffix": "a1",
        "admin": True,
    }
}

# Initialize defaults file if it does not exist
defaults_path = "tests/_config/defaults.json"
if not os.path.exists(defaults_path):
    with open(defaults_path, "w") as f:
        json.dump(
            {
                "configuration": None
            },
            f,
            indent=4,
        )

while True:
    # Load defaults
    with open(defaults_path, "r") as f:
        default_data = json.load(f)

    # Load current configurations
    print("\nCurrent environments:")
    print("---------------------")
    filenames = glob.glob("tests/_config/configurations/*.json")
    for filename in filenames:
        with open(filename, "r") as f:
            data = json.load(f)
        if data["key"] == default_data["configuration"]:
            selector = "-> "
        else:
            selector = "   "
        print(f"{selector}{data['key']:<16}{data['url']}")

    selection = input("\nadd (a), delete (d), set default (s), or quit (q)?\n").lower().strip()

    # Quit the script
    if selection == "q":
        break

    # Set new default key
    elif selection == "s":
        new_default_key = input("\nDefault key: ").lower().strip()
        default_data.update({"configuration": new_default_key})
        with open(defaults_path, "w") as f:
            json.dump(default_data, f, indent=4)

    # ADD NEW SETUP
    elif selection == "a":

        # Basic inputs
        print("\nNew setup, initial parameters")
        key = input("key (a-z, 0-9): ").strip()
        url = input("url: ").strip(" /")

        # Retrieve or request ConfigHub password
        print("\nChecking for ConfigHub password...")
        config_password = keyring.get_password(url, "admin")
        if config_password is None:
            print(" -> Not found. Enter password (will be saved with keyring)")
            config_password = getpass("password: ")
            keyring.set_password(url, "admin", config_password)
        else:
            print(" -> Retrieved")

        # Log in to ConfigHub
        cfg = ConfigClient(
            url=url,
            password=config_password,
        )
        print(" -> Login successful")

        # Retrieve or create 'ALL' ACL
        print("\nRetrieving/creating acces rights to 'ALL' datasources")
        try:
            acl_all = cfg.access.from_identifier("ALL")
            print(" -> Retrieved")
        except:
            acl_all = cfg.access(name="ALL")
            acl_all.post()
            print(" -> Created")

        # Retrieve or create client
        client_name = key_prefix + key
        print(f"\nClient user setup: {client_name}")
        try:
            client_user = cfg.client.from_identifier(client_name)
            print(" -> Client exists; retrieved")
        except:
            client_user = cfg.client(name=client_name)
            client_user.post()
            keyring.set_password(url, client_name, client_user.get_secret())
            print(" -> Created; password saved")

        acl_all.member_add(client_user)
        print(" -> Datasource access rights granted ('ALL')")

        # Log in as client
        client = TrendMinerClient(
            url=url,
            client_id=client_name,
            client_secret=keyring.get_password(url, client_name)
        )
        print(" -> client login successful")

        # Create group, give permissions
        group_name = f"{key_prefix}.{key}"
        print(f"\n Retrieving/creating group '{group_name}'")
        try:
            group = cfg.group.from_name(group_name)
            print(" -> Retrieved")
        except:
            group = cfg.group(name=group_name)
            group.post()
            print(" -> Created")

        acl_all.member_add(group)
        print(" -> Datasource access rights granted ('ALL')")

        # Create users, add to group
        for _, u in user_config.items():
            username = f"{key_prefix}.{key}.{u['suffix']}"
            print(f"\nUser setup: {username}")
            try:
                user = cfg.user.from_name(username)
                print(" -> User exists; retrieved")
            except:
                user = cfg.user(
                    name=username,
                    first=key_prefix,
                    last=key + u['suffix'],
                    mail=username + "@trendminer.com"
                )
                user.post(password=password_placeholder)
                print(f" -> Initialized; please log in to {url} and change the password\n"
                      f"    Username:         {username}\n"
                      f"    Current password: {password_placeholder}")

                new_password = getpass("    New password: ")
                keyring.set_password(url, username, new_password)
                print("    -> Saved")

                if u["admin"]:
                    user.set_roles(admin=True)
                    print("    -> Granted admin permissions")

                group.member_add(user)
                print(f"    -> Added to {group.name}")

                TrendMinerClient(
                    url=url,
                    client_id=client_name,
                    client_secret=keyring.get_password(url, client_name),
                    username=username,
                    password=keyring.get_password(url, username)
                )
                print("    -> Login successful")

        # TODO: create tag csv files, and upload them for the admin users

        # Create or retrieve test asset framework
        af_name = f"{key_prefix}.{key}"
        print(f"\nRetrieving/creating asset framework '{af_name}'")
        df = pd.read_csv("tests/_config/asset framework.csv")
        admin_name = f"{key_prefix}.{key}.{user_config['admin']['suffix']}"
        admin = TrendMinerClient(
            url=url,
            client_id=client_name,
            client_secret=keyring.get_password(url, client_name),
            username=admin_name,
            password=keyring.get_password(url, admin_name)
        )
        try:
            af = admin.asset.framework.from_name(af_name)
            print(" -> Retrieved")
        except:
            af = admin.asset.framework(
                name=af_name,
                df=df,
                published=True,
            )
            af.post()
            print(" -> Created")

        # Add user permissions to asset framework
        af.root_asset.access.clear() # avoid duplicate permission error
        for _, u in user_config.items():
            username = f"{key_prefix}.{key}.{u['suffix']}"
            af.root_asset.access.add(username, "ASSET_READ_CONTEXT_ITEM")
            print(f" -> {username} browse+context access granted")

        # Save configuration .json file
        file_path = f"tests/_config/configurations/{key}.json"
        with open(file_path, "w+") as f:
            json.dump(
                {
                    "key": key,
                    "url": url,
                    "af": af_name,
                    "prefix": key_prefix+key,
                    "users": {
                        **{"client": client_name},
                        **{user_key: f"{key_prefix}.{key}.{user_data['suffix']}"
                           for user_key, user_data in user_config.items()}
                    }
                },
                f,
                indent=4,
            )

    # UNKNOWN INPUT
    else:
        print("Unsupported input, terminating")
        break
