# TrendMiner Python Interface

## Goal 

The goal of this package is to provide a user-friendly interface to all TrendMiner functionality. This allows a user
to automate any in-app workflow with python. As such, this package should prove very useful as a basis for creating
scripts that automate tasks, or that extend upon the basic TrenMiner functionality.

This package is a work in progress. Not all in-app functionality is represented, and the package should not be
considered stable (names may change; functions have not been tested thoroughly).

## Development

To get started with development execute the following:

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
pip install -r dev_requirements.txt
```

### Linting

This package uses [Pylint](https://pylint.org/) to verify the Python code. 
The configuration of the tool is done in `.pylintrc`.

To run the linting:
```
pylint trendminer_core
```


## To Do
- [ ] Re-enable more checkers in Pylint
- [ ] Converting an object from one user to another/from one server to another
  -> Use case to keep in mind; no focus at this point
- [ ] Elaborate on TrendMiner object
- [ ] Complete functionality for managing context sql connections
- [ ] Implementation of searches and monitors 
- [ ] Implementation of io module (tag and context data import/export) to match new version and code base
- [ ] Implement tag builder functionality
- [ ] Implement compare and statistics tables
- [ ] Implement exporting/importing work organizer objects
- [ ] Add smart cacheing of ojbects where applicable
- [ ] Add blueprint attribute for all classes
- [ ] Getting users currently (likely only works) for local users (fixed endpoint: /local/users/)
- [ ] Review what responses might be paginated and are currently capped by a certain size. These should use the 
automatic paginator that iterates over all pages.
- [ ] Work out token (+url) authentication for use in MLHub
- [ ] Allow full class-based configuration of ContextHub and TrendHub views. Some configuration options are still in raw json format.
- [x] Caching is a problem: lru_cache return the same instance, not a fresh copy of that instance
- [ ] Caching strategy for asset, placed on the browse; cache should be cleared when AF is updated
