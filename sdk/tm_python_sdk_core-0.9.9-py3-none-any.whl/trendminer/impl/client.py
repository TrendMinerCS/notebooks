from __future__ import annotations

import functools

# from .services.services import Services
import pytz
from requests.exceptions import RequestException
from trendminer.sdk.client import Client
from trendminer.impl.asset import AssetFactory
from trendminer.impl.context.client import ContextFactory
from trendminer.impl.models.models import ModelsFactory
from trendminer.impl.search import SearchFactory
from trendminer.impl.tag import TagFactory
from trendminer.impl.trend import TrendHubViewFactory
from trendminer.sdk.asset.asset import AssetAPI
from trendminer.sdk.client import Client
from trendminer.sdk.context.context import ContextAPI
from trendminer.sdk.models.models import MlModelsAPI
from trendminer.sdk.search.search import SearchAPI
from trendminer.sdk.tag.tag import TagAPI
from trendminer.sdk.trend.trend import TrendViewAPI

from ._util import DefaultUrlUtils
from .authentication import BaseClient, TrendMinerSession
from .constants import CLUSTER_LOCAL_NAME, SERVICE_NAMES
from .datasource import DatasourceClient
# from .version import Version
from .exception_messages import ExceptionMessages
from .exceptions import ResourceNotFound
from .folder import FolderClient
# from .monitor import MonitorClient
# from .tagbuilder import FormulaClient, AggregationClient
# from .dashhub import DashHubClient
# from .io import IOClient
from .times import TimeClient
from .user import UserClient


class ClientCollection(
    BaseClient,
    TimeClient,
    UserClient,
    DatasourceClient,
    FolderClient,
    # MonitorClient
    # FormulaClient,
    # DashHubClient,
    # AggregationClient,
    # IOClient,
    # Services,
):
    def __init__(
        self,
        url,
        token,
        session_type,
        tz,
    ):
        TimeClient.__init__(self, tz=tz)
        BaseClient.__init__(
            self,
            url=url,
            token=token,
            #History disabled for this version
            keep_history=False,
            session_type=session_type,
        )

    # @property
    # @functools.lru_cache(maxsize=10)
    # def version(self):
    #     """TrendMiner appliance version

    #     Returns
    #     -------
    #     Version
    #     """
    #     params = {"timestamp": int(datetime.timestamp(datetime.utcnow()))}
    #     response = self.session.get("/trendhub/version", params=params)
    #     return Version.from_string(response.json()["release.version"])

    def _request_service_endpoints(self, req_endpoint_in_ds , service_name):
        try:
            if self.session.base_url is None:
                self.session.base_url = DefaultUrlUtils().get_default_url(service_name)
            elif CLUSTER_LOCAL_NAME in self.session.base_url:
                self.session.base_url = DefaultUrlUtils().get_default_url(service_name)
            response = self.session.get(req_endpoint_in_ds)
            response.raise_for_status()
            return response
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    @property
    @functools.lru_cache(maxsize=10)
    def resolution(self):
        """TrendMiner appliance index resolution

        Returns
        -------
        timedelta
        """
        service_name = SERVICE_NAMES["datasource"]
        response = self._request_service_endpoints(
            "/ds/configurations/INDEX_RESOLUTION", service_name
        )
        return self.time.timedelta(float(response.json()["value"]))


    @property
    @functools.lru_cache(maxsize=10)
    def index_horizon(self):
        """TrendMiner appliance index horizon

        Returns
        -------
        datetime
        """
        service_name = SERVICE_NAMES["datasource"]
        response = self._request_service_endpoints(
            "/ds/timeseries/indexhorizon", service_name
        )
        return self.time.datetime(response.json()["horizon"])

    #Rename this property as we are unable to assign some properties in Client Constructor
    @property
    @functools.lru_cache(maxsize=10)
    def client_username(self):
        """Client username

        Returns
        -------
        str
        """
        return self.session.token_decoded["preferred_username"]



class ClientImpl(Client, ClientCollection):
    def __init__(
        self,
        token=None,
        url=None,
        tz=pytz.utc,
    ):
        super().__init__(
        token=token,
        url = url,
        tz=tz)
                
        ClientCollection.__init__(
            self,
            url=url,
            token=token,
            session_type=TrendMinerSession,
            tz=tz,
        )

    #Update return type for each property with client api
    @property
    def asset(self) -> AssetAPI:
        return AssetFactory(client=self)
    
    @property
    def context(self) -> ContextAPI:
        return ContextFactory(client=self)
    
    @property
    def ml(self) -> MlModelsAPI:
        return ModelsFactory(client=self)
    
    @property
    def tag(self) -> TagAPI:
        return TagFactory(client=self)
    
    @property
    def view(self) -> TrendViewAPI:
        return TrendHubViewFactory(client=self)
    
    @property
    def search(self) -> SearchAPI:
        return SearchFactory(client=self)
