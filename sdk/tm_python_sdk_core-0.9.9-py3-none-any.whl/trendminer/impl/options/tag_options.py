from trendminer.sdk.tag.tag import InterpolationTypeOptions, TagTypeOptions

_TAG_TYPE_OPTIONS_DICT = {
    "ANALOG": TagTypeOptions.ANALOG,
    "DISCRETE": TagTypeOptions.DISCRETE,
    "DIGITAL": TagTypeOptions.DIGITAL,
    "STRING": TagTypeOptions.STRING,
}


_INTERPOLATION_TYPE_OPTIONS_DICT = {
    "LINEAR": InterpolationTypeOptions.LINEAR,
    "STEPPED": InterpolationTypeOptions.STEPPED,
    "STEP_AFTER": InterpolationTypeOptions.STEP_AFTER,
    "STEP-AFTER": InterpolationTypeOptions.STEP_AFTER,
}