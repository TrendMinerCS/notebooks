from trendminer.sdk.search.search import (LogicalOperators, SearchCalculationOptions,
                                   ValueBasedSearchOperators)

_SEARCH_CALCULATION_OPTIONS_DICT = {
    "mean": SearchCalculationOptions.MEAN,
    "avg": SearchCalculationOptions.MEAN,
    "average": SearchCalculationOptions.MEAN,
    "min": SearchCalculationOptions.MINIMUM,
    "minimum": SearchCalculationOptions.MINIMUM,
    "max": SearchCalculationOptions.MAXIMUM,
    "maximum": SearchCalculationOptions.MAXIMUM,
    "range": SearchCalculationOptions.RANGE,
    "start": SearchCalculationOptions.START,
    "startvalue": SearchCalculationOptions.START,
    "end": SearchCalculationOptions.END,
    "endvalue": SearchCalculationOptions.END,
    "delta": SearchCalculationOptions.DELTA,
    "integral": SearchCalculationOptions.INTEGRAL,
    "int": SearchCalculationOptions.INTEGRAL,
    "stdev": SearchCalculationOptions.STDEV,
    "std": SearchCalculationOptions.STDEV,
    "standard deviation": SearchCalculationOptions.STDEV,
}

_LOGICAL_OPERATORS_DICT = {
    "and": LogicalOperators.AND,
    "or": LogicalOperators.OR,
    "AND": LogicalOperators.AND,
    "OR": LogicalOperators.OR,
}

_VALUE_BASED_SEARCH_OPERATORS_DICT = {
    ">": ValueBasedSearchOperators.GREATER_THAN,
    ">=": ValueBasedSearchOperators.GREATER_THAN_EQUAL_TO,
    "<": ValueBasedSearchOperators.LESS_THAN,
    "<=": ValueBasedSearchOperators.LESS_THAN_EQUAL_TO,
    "=": ValueBasedSearchOperators.EQUAL_TO,
    "!=": ValueBasedSearchOperators.NOT_EQUAL_TO,
    "<>": ValueBasedSearchOperators.NOT_EQUAL_TO,
    "constant": ValueBasedSearchOperators.CONSTANT,
    "in_set": ValueBasedSearchOperators.IN_SET,
    "in set": ValueBasedSearchOperators.IN_SET,
}

_ANALOG_TAG_VBS_OPERATORS = [ValueBasedSearchOperators.GREATER_THAN,
                                ValueBasedSearchOperators.GREATER_THAN_EQUAL_TO,
                                ValueBasedSearchOperators.LESS_THAN,
                                ValueBasedSearchOperators.LESS_THAN_EQUAL_TO,
                                ValueBasedSearchOperators.EQUAL_TO,
                                ValueBasedSearchOperators.NOT_EQUAL_TO,
                                ValueBasedSearchOperators.CONSTANT
                                ]

_DIGITAL_TAG_VBS_OPERATORS = [ValueBasedSearchOperators.CONSTANT,
    ValueBasedSearchOperators.IN_SET]
