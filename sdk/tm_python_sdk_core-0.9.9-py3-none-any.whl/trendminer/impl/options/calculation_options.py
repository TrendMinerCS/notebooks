
from trendminer.sdk.search.search import SearchCalculationOptions

_ANALOG_TAG_CALCULATION_OPTIONS = [SearchCalculationOptions.MEAN,
                                    SearchCalculationOptions.MINIMUM,
                                    SearchCalculationOptions.MAXIMUM,
                                    SearchCalculationOptions.RANGE,
                                    SearchCalculationOptions.DELTA,
                                    SearchCalculationOptions.INTEGRAL,
                                    SearchCalculationOptions.STDEV,
                                    SearchCalculationOptions.START,
                                    SearchCalculationOptions.END
                                    ]

_DIGITAL_TAG_CALCULATION_OPTIONS = [
                                    SearchCalculationOptions.START,
                                    SearchCalculationOptions.END
                                    ]