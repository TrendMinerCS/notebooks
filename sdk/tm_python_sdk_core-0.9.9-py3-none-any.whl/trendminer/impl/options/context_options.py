from trendminer.sdk.context import (ContextDateOperators, ContextFieldOptions,
                                    ContextFilterModes,
                                    ContextFilterStatesModes, ContextOperators)
from trendminer.sdk.context.filter import (ContextDateOperators,
                                           ContextFilterModes,
                                           ContextFilterStatesModes,
                                           ContextOperators)

_CONTEXT_FIELD_OPTIONS = {
    "STRING" : ContextFieldOptions.STRING,
    "ENUMERATION" : ContextFieldOptions.ENUMERATION,
    "NUMERIC" : ContextFieldOptions.NUMERIC,
    "string" : ContextFieldOptions.STRING,
    "enumeration" : ContextFieldOptions.ENUMERATION,
    "numeric" : ContextFieldOptions.NUMERIC,
}

_CONTEXT_DATE_OPERATORS = {
    "<": ContextDateOperators.LESS_THAN,
    ">": ContextDateOperators.GREATER_THAN,
    "<=": ContextDateOperators.LESS_THAN_OR_EQUAL,
    ">=": ContextDateOperators.GREATER_THAN_OR_EQUAL,
    "LESS_THAN": ContextDateOperators.LESS_THAN,
    "GREATER_THAN": ContextDateOperators.GREATER_THAN,
    "LESS_THAN_OR_EQUAL": ContextDateOperators.LESS_THAN_OR_EQUAL,
    "GREATER_THAN_OR_EQUAL": ContextDateOperators.GREATER_THAN_OR_EQUAL,
}


_CONTEXT_FILTER_MODES_STATES = {
    "OPEN_ONLY": ContextFilterStatesModes.OPEN_ONLY,
    "open": ContextFilterStatesModes.OPEN_ONLY,
    "open only": ContextFilterStatesModes.OPEN_ONLY,
    "CLOSED_ONLY": ContextFilterStatesModes.CLOSED_ONLY,
    "closed": ContextFilterStatesModes.CLOSED_ONLY,
    "closed only": ContextFilterStatesModes.CLOSED_ONLY,
}


_CONTEXT_FILTER_MODES_EMPTY = {
    "EMPTY": ContextFilterModes.EMPTY,
    "NON_EMPTY": ContextFilterModes.NON_EMPTY,
    "non empty": ContextFilterModes.NON_EMPTY,
    "not empty": ContextFilterModes.NON_EMPTY,
}

_CONTEXT_OPERATORS = {
    "<": ContextOperators.LESS_THAN,
    ">": ContextOperators.GREATER_THAN,
    "=": ContextOperators.NOT_EQUAL,
    "!=": ContextOperators.NOT_EQUAL,
    "<=": ContextOperators.LESS_THAN_OR_EQUAL,
    ">=": ContextOperators.LESS_THAN_OR_EQUAL,
    "LESS_THAN": ContextOperators.LESS_THAN,
    "GREATER_THAN": ContextOperators.GREATER_THAN,
    "EQUAL": ContextOperators.EQUAL,
    "NOT_EQUAL": ContextOperators.NOT_EQUAL,
    "LESS_THAN_OR_EQUAL": ContextOperators.LESS_THAN_OR_EQUAL,
    "GREATER_THAN_OR_EQUAL": ContextOperators.LESS_THAN_OR_EQUAL
}
