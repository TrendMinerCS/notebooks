import abc
import re

import cachetools
from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.base import (MultiFactory, TrendMinerFactory,
                                  kwargs_to_class, to_subfactory)
from trendminer.impl.constants import (FOLDER_BROWSE_SIZE, MAX_FOLDER_CACHE,
                                       WORK_ORGANIZER_CONTENT_OPTIONS)
from trendminer.impl.context.view import ContextHubViewFactory
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.search import \
    ValueBasedSearchFactory  # , SimilaritySearchFactory
from trendminer.impl.services.services import _work_service
from trendminer.impl.trend.view import TrendHubViewFactory
from trendminer.impl.work.work_organizer_object import (WorkOrganizerFactory,
                                                        WorkOrganizerObject)
from trendminer.sdk.commons.folder import Folder

# from trendminer.impl.tagbuilder import FormulaFactory #, AggregationFactory
# from trendminer.impl.dashhub import DashboardFactory
# TODO: from trendminer.impl_interface.fingerprint import FingerprintFactory


class FolderClient(abc.ABC):
    """Client for folder factory"""

    @property
    def folder(self):
        """Factory for creating and retrieving folders"""
        return FolderFactory(client=self)


class FolderImpl(WorkOrganizerObject,Folder):
    """Work organizer folder

    Attributes
    ----------
    client : TrendMinerClient
        Trendminer client instance for the appliance
    identifier : uuid
        Unique identifier to the view object on the appliance
    name : str
        The view name
    description : str
        The view description
    folder : Folder or str
        Folder in which the view would be saved (when doing a post or put request)
    owner : str
        The view owner
    last_modified : datetime.datetime
        View last modified time
    """

    content_type = "FOLDER"

    def __init__(self, client, identifier, name, folder, owner, last_modified):
        WorkOrganizerObject.__init__(self,
                                    client=client,
                                    identifier=identifier,
                                    name=name,
                                    description=None,
                                    folder=folder,
                                    owner=owner,
                                    last_modified=last_modified,
                                )
        Folder.__init__(self,
                        identifier  = identifier,
                        name = name,
                        owner = owner,
                        last_modified  = last_modified,
                        description = None)

    def _json_data(self):
        return

    def __json__(self):
        return {
            "id": self.identifier,
            "name": self.name,
            "folder": True,
            "parentId": self.folder.identifier if self.folder else None,
        }

    def subfolders(self):
        """Retrieve subfolder in the current folder

        Returns
        -------
        list
            List of Folder

        Example
        -------
        .. code-block:: python

            # Retrive subfolders in the current directory
            folder.subfolders()
        """
        return self.browse(folders_only=True)

    def browse(self, included=None, excluded=None, folders_only=False):
        """Browse the items in the current folder

        Parameters
        ----------
        included : list of str, optional
            Included work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        excluded : list of str, optional
            Excluded work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        folders_only : bool, default False
            Whether to only search for subfolders. Ignores `included` and èxcluded`

        Example
        -------
        .. code-block:: python

            # Browse the items in the directory
            folder = client.folder.get("sdk")
            folder.browse()
        """
        if excluded is None:
            excluded = ["MONITOR"]
        included = [
            t if isinstance(t, str) else t.content_type for t in ip.any_list(included)
        ]
        excluded = [
            t if isinstance(t, str) else t.content_type for t in ip.any_list(excluded)
        ]
        included = [
            ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in included
        ]
        excluded = [
            ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in excluded
        ]

        params = {
            "size": FOLDER_BROWSE_SIZE,
            "folders_only": folders_only,
            "parent": self.identifier,
        }

        if included:
            params.update({"include_types": included})
        elif excluded:
            params.update({"exclude_types": excluded})

        # response = self.client.session.get("/work/saveditem/browse", params=params)
        response = _work_service(self.client).browse_folder(**params)

        try:
            content = response.json()["_embedded"]["content"]
        except KeyError:
            content = []

        ret_val = []
        for data in content:
            try:
                ret_val.append(
                    FolderContentFactory(client=self.client)._from_json_work_organizer(
                        data
                    )
                )
            except:
                pass
        return ret_val

    def get(self, name, included=None):
        """Get an object from folder by name

        Parameters
        ----------
        name : str
            The name of the work organizer item to retrieve
        included : list of str, optional
            The item types to search in to retrieve by name. Prevents errors if there are work organizer items of
            another type with the same name. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"

        Example
        ------

        .. code-block:: python

            # Retriving the object from the folder name
            client.folder.get("sdk")
        """
        content = self.browse(included=included)
        return ip.object_match_nocase(content, attribute="name", value=name)

    def _content_blueprint(self):
        raise NotImplementedError()

    # TODO: implement uniform strategy for cacheing and clearing the cache
    def _clear_cache(self):
        """Clear the folder getting cache every time the folder structure is changed"""
        self.client.folder.get_by_identifier.cache_clear()

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< Folder | {str(self)} >>"

    def __str__(self):
        if self.name is None:
            return "<ROOT>"
        return self.name


class FolderFactory(WorkOrganizerFactory):
    """Factory for creating and retrieving folders

    Parameters
    ----------
    client : TrendMinerClient
        Trendminer client instance for the appliance
    identifier : uuid
        Unique identifier to the view object on the appliance
    name : str
        The view name
    description : str
        The view description
    folder : Folder or str
        Folder in which the view would be saved (when doing a post or put request)
    owner : str
        The view owner
    last_modified: datetime.datetime
        View last modified time"""

    _tm_class = FolderImpl

    def __call__(self, name, parent=None):
        """Instantiate a new folder object"""
        return self._tm_class(
            client=self.client,
            identifier=None,
            name=name,
            folder=parent,
            owner=None,
            last_modified=None,
        )

    @kwargs_to_class
    def _from_json(self, data):
        """Full enriched payload"""
        kwargs = self._json_to_kwargs_base(data)
        kwargs.pop("description")  # no description for folders
        return kwargs

    def _from_json_work_organizer(self, data):
        """Browse payload is equal to full enriched payload"""
        return self._from_json(data)

    # TODO: get rid of root concept. use client.work
    def root(self):
        """Retrieve the root work organizer folder

        The root folder is an artificial construct. It is not an actual folder in the appliance (i.e., it does not have
        a name or identifier).

        Returns
        -------
        Folder
            Root folder
        """
        return FolderImpl(
            client=self.client,
            identifier=None,
            name=None,
            folder=None,
            owner=self.client.user._from_json_name_only(self.client.client_username),
            last_modified=None,
        )

    def get_by_path(self, ref):
        """Retrieve or create a folder on a given path

        Parameters
        ----------
        ref : str
            Folder path
        create_new : bool, default False
            Whether a new folder needs to be created at the given path if no folder is found there. Creates intermediate
            folders on the path too.

        Returns
        -------
        Folder
            Folder on the given path

        Example
        ------

        .. code-block:: python

            # Retriving a folder from a given path
            client.folder.get_by_path("sdk")
        """
        return self.__from_path(ref)

    def __from_path(self, ref, create_new=False):
        """Retrieve or create a folder on a given path

        Parameters
        ----------
        ref : str
            Folder path
        create_new : bool, default False
            Whether a new folder needs to be created at the given path if no folder is found there. Creates intermediate
            folders on the path too.

        Returns
        -------
        Folder
            Folder on the given path
        """
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.root()

        # Iterate folders
        for part in parts:
            try:
                current_folder = ip.object_match_nocase(
                    current_folder.subfolders(), attribute="name", value=part
                )
            except ResourceNotFound as e:
                if create_new:
                    current_folder = current_folder.add_folder(name=part)
                else:
                    raise e

        return current_folder

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=MAX_FOLDER_CACHE),
        key=TrendMinerFactory._cache_key_ref,
    )
    def get_by_identifier(self, ref):
        """Retrieve folder from its identifier

        Parameters
        ----------
        ref : str
            Folder UUID

        Returns
        -------
        Folder
            Folder from it's identifier

        Example
        ------

        .. code-block:: python

            # Retriving folder from an identifier
            client.folder.get_by_identifier("f47eafa6-3cb9-403e-a3b6-15933dd02902")
        """
        return self.__from_identifier(ref)

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=MAX_FOLDER_CACHE),
        key=TrendMinerFactory._cache_key_ref,
    )
    def __from_identifier(self, ref):
        """Retrieve folder from its identifier

        Parameters
        ----------
        ref : str
            Folder UUID

        Returns
        -------
        Folder
        """
        return super().get_by_identifier(ref)

    @property
    def _get_methods(self):
        return self.get_by_identifier, self.get_by_path

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)

        try:
            responses = [method(**kwargs["params"])]
            responses[0].raise_for_status()
            # if responses[0].status_code in [400, 404]:
            #     raise ResourceNotFound
            total_pages = self._prepare_response(responses[0])["page"]["totalPages"]

            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
                if "folder" in item and item["folder"] is True
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp


class WorkOrganizerPlaceholder(WorkOrganizerObject):
    """Placeholder for work organizer objects which have not yet been implemented in the SDK

    These item can be managed and deleted in the work organizer, but they cannot otherwise be interacted with. Their
    data is simply dumped as a dict in the `data` parameter.

    Attributes
    ----------
    client : TrendMinerClient
        Trendminer client instance for the appliance
    identifier : uuid
        Unique identifier to the view object on the appliance
    name : str
        The view name
    description : str
        The view description
    folder : Folder or str
        Folder in which the view would be saved (when doing a post or put request)
    owner : str
        The view owner
    last_modified: datetime.datetime
        View last modified time
    data : dict
        Dump of the object json data
    content_type : str
        Work organizer item type
    """

    def __init__(
        self,
        client,
        identifier,
        name,
        description,
        folder,
        owner,
        last_modified,
        data,
        content_type,
    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )
        self.data = data
        self.content_type = content_type

    def _json_data(self):
        return self.data

    def _content_blueprint(self):
        pass

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< {self.content_type} (not implemented) | {self.name} >>"


# class WorkOrganizerPlaceholderFactory(WorkOrganizerFactory):
#     """Factory for retrieving work organizer placeholder objects"""
#     _tm_class = WorkOrganizerPlaceholder

#     @kwargs_to_class
#     def _from_json(self, data):
#         """Full enriched payload"""
#         return {
#             **self._json_to_kwargs_base(data),
#             "content_type": data["type"],
#             "data": data["data"],
#         }

#     @kwargs_to_class
#     def _from_json_work_organizer(self, data):
#         """Need to add placeholder arguments not present in work organizer"""
#         return {
#             **super()._from_json_work_organizer.__wrapped__(self, data),
#             "content_type": data["type"],
#         }


implemented_factories = {
    factory._tm_class.content_type: factory
    for factory in [
        ContextHubViewFactory,
        TrendHubViewFactory,
        FolderFactory,
        ValueBasedSearchFactory,
        # FormulaFactory,
        # AggregationFactory,
        # DashboardFactory,
        # SimilaritySearchFactory,
    ]
}

# Initialize dummy factories for unimplemented methods
# wo_factories = {
#     content_type: WorkOrganizerPlaceholderFactory
#     for content_type in WORK_ORGANIZER_CONTENT_OPTIONS
# }

# Update with implemented factories
wo_factories = {}
wo_factories.update(implemented_factories)


class FolderContentFactory(MultiFactory):
    """Generates objects from any content json content found in a folder"""

    factories = wo_factories

    @to_subfactory
    def _from_json(self, data):
        """Full response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data.get("type", "FOLDER")

    @to_subfactory
    def _from_json_work_organizer(self, data):
        """Limited response json from work organizer browsing"""
        return data.get("type", "FOLDER")

    @property
    def _get_methods(self):
        return ()
