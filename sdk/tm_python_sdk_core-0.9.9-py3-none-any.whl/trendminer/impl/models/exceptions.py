"""
This module lists different types of exceptions thrown by the :code:`trendminer.models.ml` subpackage
"""


class MLModelException(Exception):
    """
    General exception for things gone wrong in this subpackage
    """


class MLModelNotFoundException(MLModelException):
    """
    The requested model cannot be found by TrendMiner
    """


class MLModelDuplicateIdentifierException(Exception):
    """
    There already exists a model with the provided identifier
    """


class MLModelInvalidIdentifierException(Exception):
    """
    The specified model identifier is not a valid one
    """


class MLModelInconsistencyException(Exception):
    """
    The specified model is logically inconsistent
    """


class InvalidFilePathException(Exception):
    """
    The specified model file path is not valid
    """
