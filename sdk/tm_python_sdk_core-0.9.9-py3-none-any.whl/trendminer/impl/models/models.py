import os
from abc import ABC, abstractmethod
from typing import Any, List
from urllib.parse import quote, urljoin

from trendminer.impl.authentication import Authenticated
from trendminer.impl.constants import SERVICE_NAMES
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.models.exceptions import (
    InvalidFilePathException, MLModelDuplicateIdentifierException,
    MLModelException, MLModelInconsistencyException,
    MLModelInvalidIdentifierException, MLModelNotFoundException)
from trendminer.impl.services.services import (_timeseries_service,
                                               set_default_url)
from trendminer.sdk.models.models import MlModelsAPI, PmmlModelsAPI


class ModelsFactory(Authenticated, MlModelsAPI):
    @property
    def pmml(self) -> PmmlModelsAPI:
        return PmmlModelsFactory(client=self.client)


class PmmlModelsFactory(ModelsFactory, PmmlModelsAPI):
    _service_name = SERVICE_NAMES["ts"]

    def get_by_identifier(self, model_id: str) -> dict:
        PmmlModelsFactory.__check_id(model_id)
        response = _timeseries_service(self.client).get_machine_learning_model(model_id)
        body = response.json()
        if response.status_code == 404:
            raise MLModelNotFoundException(body["message"])
        if response.status_code != 200:
            raise MLModelException(body["message"])
        if response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED)
        return body

    def deploy_model_file(self, model_path: str) -> str:
        PmmlModelsFactory.__validate_file(model_path)
        file = {"file": model_path}
        response = _timeseries_service(self.client).create_machine_learning_model(
            **file
        )
        body = response.json()
        if response.status_code == 409:
            raise MLModelDuplicateIdentifierException(
                PmmlModelsFactory.__extract_error_message(body)
            )
        if response.status_code == 400:
            raise MLModelInconsistencyException(
                PmmlModelsFactory.__extract_error_message(body)
            )
        if response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED)
        if response.status_code != 201:
            raise MLModelException(PmmlModelsFactory.__extract_error_message(body))
        return body["modelName"]

    def deploy_model(self, model: str) -> str:
        _endpoint = "/tb/machinelearning/model/"
        url = self.__tsb_model_url(_endpoint)
        file = {"file": ("pmml.xml", model)}
        self.client = set_default_url(self.client, self._service_name)
        response = self.client.session.post(url, files=file)
        body = response.json()
        if response.status_code == 409:
            raise MLModelDuplicateIdentifierException(
                PmmlModelsFactory.__extract_error_message(body)
            )
        if response.status_code == 400:
            raise MLModelInconsistencyException(
                PmmlModelsFactory.__extract_error_message(body)
            )
        if response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED)
        if response.status_code != 201:
            raise MLModelException(PmmlModelsFactory.__extract_error_message(body))
        return body["modelName"]

    def delete_model(self, model_id: str) -> None:
        PmmlModelsFactory.__check_id(model_id)
        # url = self.__tsb_model_url(model_id)
        response = _timeseries_service(self.client).delete_machine_learning_model(
            model_id
        )
        if response.status_code == 404:
            raise MLModelNotFoundException(
                PmmlModelsFactory.__extract_error_message(response.json())
            )
        if response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED)
        if response.status_code != 204:
            raise MLModelException(
                PmmlModelsFactory.__extract_error_message(response.json())
            )

    def search(self, *args, **kwargs) -> list[dict]:
        results = []
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    results.extend(data)
        return results
    
    def list(self) -> list[dict]:
        response = _timeseries_service(self.client).get_machine_learning_models()
        body = response.json()
        if response.status_code != 200:
            raise MLModelException(PmmlModelsFactory.__extract_error_message(body))
        if response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED)
        return [PmmlModelsFactory.__remove_links(model) for model in body["content"]]

    
    def __by_name(self, ref):
        try:
            return [self.get_by_identifier(ref)]
        except MLModelNotFoundException:
            return []
        except MLModelException:
            return []

    @property
    def _search_methods(self):
        return (self.__by_name,)


    def __tsb_model_url(self, _endpoint, suffix=""):
        _url = self.client.url
        return urljoin(_url, _endpoint + quote(suffix))

    @staticmethod
    def __extract_error_message(body):
        if "message" in body:
            return body["message"]
        if "error" in body:
            return body["error"]
        return "Unknown error"

    @staticmethod
    def __remove_links(model_content):
        model_content.pop("links")
        return model_content

    @staticmethod
    def __check_id(identifier):
        if len(identifier) == 0:
            raise MLModelInvalidIdentifierException(
                "Invalid model identifier: identifier cannot be empty"
            )
        if len(identifier) == 0:
            raise MLModelInvalidIdentifierException(
                f"Invalid model identifier: '{identifier}'"
            ) from identifier

    @staticmethod
    def __validate_file(path: str):
        if not os.path.exists(path):
            raise InvalidFilePathException(
                "Invalid model input file, file does not exist"
            )
