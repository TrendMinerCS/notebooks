# pylint: disable=R0201

from trendminer.impl.asset import (AssetFactory, AssetFactoryBase,
                                   AttributeFactoryBase)
from trendminer.impl.base import MultiFactory, to_subfactory
from trendminer.impl.tag import TagFactory


class ComponentFactory(MultiFactory):
    """Factory for retrieving ContextHub componenets"""

    factories = {
        "TAG": TagFactory,
        "ASSET": AssetFactoryBase,
        "ATTRIBUTE": AttributeFactoryBase,
    }

    @property
    def _get_methods(self):
        return (
            self._subfactory("TAG").get_by_identifier,
            AssetFactory(
                client=self.client
            )._get_by_identifier_in_context,  # general; works for asset and attribute
            self._subfactory("TAG").get_by_name,
            AssetFactory(
                client=self.client
            )._get_by_path_hex_in_context,  # general; works for asset and attribute
            AssetFactory(
                client=self.client
            )._get_by_path_in_context,  # general; works for asset and attribute
        )

    @to_subfactory
    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]

    @to_subfactory
    def _from_json_context_item(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]

    @to_subfactory
    def _from_json_current_value_tile(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]
