from trendminer.impl.base import HasOptions, TrendMinerFactory
from trendminer.impl.options.vbs_options import \
    _SEARCH_CALCULATION_OPTIONS_DICT
from trendminer.sdk.search.search import SearchCalculation, SearchCalculationOptions
from trendminer.impl.options.calculation_options import _ANALOG_TAG_CALCULATION_OPTIONS,_DIGITAL_TAG_CALCULATION_OPTIONS
from trendminer.impl.options.vbs_options import _ANALOG_TAG_VBS_OPERATORS,_DIGITAL_TAG_VBS_OPERATORS
from trendminer.sdk.tag.tag import Tag

from .tag import ReferencingTag, TagFactory


class SearchCalculationImpl(ReferencingTag,SearchCalculation):

    operation = HasOptions(SearchCalculationOptions)

    def __init__(
        self,
        client,
        key,
        tag: Tag,
        operation: SearchCalculationOptions,
        units,
    ):
        ReferencingTag.__init__(self,client=client, tag=tag)
        SearchCalculation.__init__(self,
                                    tag = tag,
                                    operation = operation,
                                    key = key,
                                    units = units)

        self.operation = operation
        self.key = key
        self.units = units



    def __json__(self):
        return {
            **super().__json__(),
            "name": self.key,
            "type": self.operation,
            "unit": self.units,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.tag.name} | {self.operation} >>"


class SearchCalculationFactory(TrendMinerFactory):
    """Factory class for creating search calculation objects"""

    _tm_class = SearchCalculationImpl

    def __call__(self, tag, operation, key=None, units=""):
        """Instantiate a new seach calculator

        Parameters
        ----------
        operation : SearchCalculationOptions
            Operations to perform on the Search.Calculations operation can be
            of type SearchCalculationOptions
        key : str
            Calculation reference key.
        units : str
            Calculation units
        """
        return self._tm_class(
            client=self.client,
            tag=tag,
            operation=operation,
            key=key,
            units=units,
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        SearchCalculation
        """
        return self._tm_class(
            client=self.client,
            tag=TagFactory(client=self.client)._from_json_calculation(
                data["reference"]
            ),
            operation=_SEARCH_CALCULATION_OPTIONS_DICT[data["type"].lower()],
            key=data["name"],
            units=data["unit"],
        )

    def from_dict(self, refs):
        """Create list of search calculations from a dict

        Dict keys are calculation keys. Values are `(tag, operation, unit)` tuples, where the unit entry is optional.

        Parameters
        ----------
        refs : dict
            Dictionary of calculations

        Returns
        -------
        list
            List of SearchCalculation

        Examples
        --------
        .. code-block:: python

            from_dict(
                {
                    'max flow': (flow_tag, 'MAX', 'm3/h'),
                }
            )
        """

        calculations = []
        for key, value in refs.items():
            tag = value[0]
            if not isinstance(tag, Tag): 
                tag = TagFactory(client=self.client).get(tag)
            if isinstance(value[1],str):
                raise ValueError(
                    f"'{value[1]}' is not a valid member of {str(SearchCalculationOptions)} type: Supported Enum members {', '.join(SearchCalculationOptions.__dict__['_member_names_'])}"
        )
            else:
                if tag.tag_type == 'DIGITAL':
                    if value[1] in _DIGITAL_TAG_CALCULATION_OPTIONS:
                        operation = value[1]
                    else:
                        raise ValueError(
                                    f"'{value[1].name}' is not a valid option of {str(SearchCalculationOptions)} type for DIGITAL type tag: Supported Enum members {', '.join([i.name for i in _DIGITAL_TAG_CALCULATION_OPTIONS])}"
                                        )
                elif tag.tag_type == 'ANALOG':
                    if value[1] in _ANALOG_TAG_CALCULATION_OPTIONS:
                        operation = value[1]
                    else:
                        raise ValueError(
                                    f"'{value[1].name}' is not a valid option of {str(SearchCalculationOptions)} type for ANALOG type tag : Supported Enum members {', '.join([i.name for i in _ANALOG_TAG_CALCULATION_OPTIONS])}"
                                        )
            try:
                units = value[2]
            except IndexError:
                units = ""
            calculations.append(
                self._tm_class(
                    client=self.client,
                    tag=tag,
                    operation=operation,
                    key=key,
                    units=units,
                )
            )
        return calculations

    def list(self, refs):
        """Retrieves instances from list of references

        Attributes
        ----------
        refs : list or dict or Any
            References to be converted to search calculations

        Returns
        -------
        list
            List of SearchCalculation
        """
        try:
            return self.from_dict(refs)
        except AttributeError:
            return super().list(refs)

    @property
    def _get_methods(self):
        return ()
