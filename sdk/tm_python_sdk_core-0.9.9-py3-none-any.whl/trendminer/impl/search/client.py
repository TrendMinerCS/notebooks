# pylint: disable=R0201

import abc
import json
import re

from requests.exceptions import RequestException

import trendminer.impl._input as ip
from trendminer.impl.base import MultiFactory, to_subfactory
from trendminer.impl.constants import DEFAULT_ENCODING
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _work_service
from trendminer.sdk.search.search import SearchAPI

from .value import ValueBasedSearchFactory

# from .similarity import SimilaritySearchFactory

search_factories = {
    factory._tm_class._search_type: factory
    for factory in [
        ValueBasedSearchFactory,
        # SimilaritySearchFactory,
    ]
}

content_type_to_search_type = {
    factory._tm_class.content_type: search_type
    for search_type, factory in search_factories.items()
}


# TODO: copying a lot of functions from WorkOrganizerObject. Should be one factory for getting any wo object that can be subclassed.
class SearchFactory(MultiFactory,SearchAPI):

    # endpoint = "/work/saveditem/"
    factories = search_factories

    @property
    def value(self):
        return ValueBasedSearchFactory(client=self.client)

    def get_by_identifier(self, ref):
        
        return self.__from_identifier(ref)

    def __from_identifier(self, ref):
        try:
            response = _work_service(self.client).get_saved_item(ref)
            response.raise_for_status()
            return self._from_json(response.json())
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def get_by_path(self, ref):
        
        return self.__from_path(ref)

    def __from_path(self, ref):
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.client.folder.root()

        # Iterate folders
        for part in parts[0:-1]:
            current_folder = ip.object_match_nocase(
                current_folder.subfolders(), attribute="name", value=part
            )

        return current_folder.get(
            parts[-1],
            included=[factory._tm_class for factory in self.factories.values()],
        )

    def __by_name(self, ref):
        # data = {"query": ref}
        params = {
            "query": ref,
            "include_types": [
                factory._tm_class.content_type for factory in self.factories.values()
            ],
            "include_data": True,
        }
        method = _work_service(self.client).search_saved_items
        content = self._prepare_paged_response(
            method, keys=["_embedded", "content"], params=params
        )
        # content = self.client.session.paginated(keys=["_embedded", "content"]).get(
        #     url="work/saveditem/search",
        #     params=params
        # )
        return [self._from_json(data) for data in content]

    def get_by_name(self, ref):
        
        return self.__from_name(ref)

    def __from_name(self, ref):
        return ip.object_match_nocase(self.__by_name(ref), attribute="name", value=ref)

    def all(self):
        
        return self.__by_name("*")

    @to_subfactory
    def _from_json_monitor(self, data):
        return data["type"]

    @to_subfactory
    def _from_json_monitor_nameless(self, data):
        return data["type"]

    @to_subfactory
    def _from_json(self, data):
        return content_type_to_search_type[data["type"]]

    @property
    def _get_methods(self):
        return self.get_by_identifier, self.get_by_path, self.get_by_name

    @property
    def _search_methods(self):
        return (self.__by_name,)

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = [method(**kwargs["params"])]
            responses[0].raise_for_status()
            total_pages = self._prepare_response(responses[0])["page"]["totalPages"]

            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
