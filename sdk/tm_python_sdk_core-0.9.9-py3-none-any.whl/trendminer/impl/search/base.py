# pylint: disable=R0201

import abc
import json
import time

from requests.exceptions import RequestException

import trendminer.impl._input as ip
from trendminer.impl.base import ByFactory, kwargs_to_class
from trendminer.impl.constants import (DEFAULT_ENCODING, MAX_GET_SIZE,
                                       SEARCH_REFRESH_SLEEP)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _compute_service
from trendminer.impl.times import IntervalFactory
from trendminer.impl.work import WorkOrganizerFactory, WorkOrganizerObject

from .calculation import SearchCalculationFactory


class Search(WorkOrganizerObject, abc.ABC):

    _search_type = None
    _refresh_sleep = SEARCH_REFRESH_SLEEP

    interval = ByFactory(IntervalFactory, "__call__")
    calculations = ByFactory(SearchCalculationFactory, "list")

    def __init__(
        self,
        client,
        identifier,
        identifier_complex,
        name,
        description,
        folder,
        owner,
        last_modified,
        calculations,
    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.search_request_identifier = None
        self.calculations = calculations
        self.identifier_complex = identifier_complex

    def _full_instance(self):
        if "identifier" not in self.lazy:
            return self.client.search.get_by_identifier(self.identifier)

        # identifier is lazy when we get a search from a monitor
        # If name is also lazy, the name is loaded when we load the monitor
        # if "name" in self.lazy:
        #     self.get_monitor()
        #     assert "name" not in self.lazy

        # Retrieve potential matches by name; match exactly on the complex identifier
        if "name" not in self.lazy:
            return ip.object_match_nocase(
                self.client.search.search(name=self.name),
                "identifier_complex",
                self.identifier_complex,
            )

    @property
    @abc.abstractmethod
    def tags(self):
        """Tags used in the search"""

    # def _post_updates(self, response):
    #     super()._post_updates(response)
    #     self.identifier_complex = response.json()["complexId"]

    def _json_definition(self):
        return {
            "calculations": self.calculations,
            "type": self.content_type,
        }

    def _execute(self, interval="6M", excluded_intervals=None):
        interval = self.client.time.interval(interval)
        excluded_intervals = self.client.time.interval.list(excluded_intervals)
        json_search = {
            "contextTimePeriod": interval,
            "definition": self._json_definition(),
            "exclusionPeriods": excluded_intervals,
        }
        try:
            # response = self.client.session.post("/compute/search-requests", json=json_search)
            response = _compute_service(self.client).search_async(body=json_search)
            response.raise_for_status()
            self.search_request_identifier = response.json()["id"]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def _extract_results(self):
        params = {"size": MAX_GET_SIZE}
        # content = self.client.session.paginated(keys=["content"]).get(
        #     f"/compute/search-requests/{self.search_request_identifier}/results",
        #     params={"size": MAX_GET_SIZE},
        # )
        method = _compute_service(self.client).get_search_results
        content = self._prepare_paged_response(
            self.search_request_identifier, method, keys=["content"], params=params
        )
        results = [
            self.client.time.interval._from_json_search_result(data) for data in content
        ]
        results = sorted(results, key=lambda x: x.start)  # oldest result first

        # null results not part of json result, set them manually
        # convert digital tag results
        for calculation in self.calculations:
            numeric = calculation.tag.isnumeric()
            if not numeric:
                states = calculation.tag._state_dict
            for result in results:
                result._data.setdefault(calculation.key)
                if not numeric and isinstance(result._data[calculation.key], int):
                    result._data[calculation.key] = states.get(
                        result._data[calculation.key]
                    )

        return results

    def _ready(self):
        try:
            response = _compute_service(self.client).get_search_request(
                self.search_request_identifier
            )
            response.raise_for_status()
            return response.json()["status"].upper() != "IN_PROGRESS"
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def get_results(self, interval="6M", excluded_intervals=None):
        self._execute(interval=interval, excluded_intervals=excluded_intervals)
        time.sleep(self._refresh_sleep)
        while not self._ready():
            time.sleep(self._refresh_sleep)
        return self._extract_results()

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, search_id, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = [method(search_id, **kwargs["params"])]
            responses[0].raise_for_status()
            total_pages = self._prepare_response(responses[0])["page"]["totalPages"]

            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(search_id, **kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp


class SearchBaseFactory(WorkOrganizerFactory, abc.ABC):

    def _json_to_kwargs_monitor(self, data):
        username = data.get("username", self.client.client_username)
        owner = self.client.user._from_json_name_only(username)
        return {
            "identifier_complex": data["searchId"],
            "owner": owner,
        }

    @kwargs_to_class
    def _from_json_monitor(self, data):
        return {
            **self._json_to_kwargs_monitor(data),
            "name": data["name"],
        }

    @kwargs_to_class
    def _from_json_monitor_nameless(self, data):
        return self._json_to_kwargs_monitor(data)
