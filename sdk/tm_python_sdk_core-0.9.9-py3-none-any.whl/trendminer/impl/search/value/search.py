from requests.exceptions import RequestException

from trendminer.impl.base import (ByFactory, HasOptions, LazyAttribute,
                                  kwargs_to_class)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.options.vbs_options import _LOGICAL_OPERATORS_DICT
from trendminer.impl.search.base import Search, SearchBaseFactory
from trendminer.impl.search.calculation import SearchCalculationFactory
from trendminer.impl.services.services import _work_service
from trendminer.impl.times import TimedeltaFactory
from trendminer.impl.user import UserFactory
from trendminer.sdk.search.search import (LogicalOperators, ValueBasedSearch,
                                   ValueBasedSearchAPI)

from .query import SearchQueryFactory

# from trendminer.sdk.search import SearchAPI, ValueBasedSearch, ValueBasedSearchAPI

class ValueBasedSearchImpl(Search,ValueBasedSearch):
    

    content_type = "VALUE_BASED_SEARCH"
    _search_type = "valuebased"

    queries = ByFactory(SearchQueryFactory, "list")
    duration = ByFactory(TimedeltaFactory, "__call__")
    operator = HasOptions(LogicalOperators)

    def __init__(
        self,
        client,
        identifier,
        identifier_complex,
        name,
        description,
        folder,
        owner,
        last_modified,
        queries,
        calculations,
        duration,
        operator: LogicalOperators,
    ):
        Search.__init__(self,
                        client=client,
                        identifier=identifier,
                        name=name,
                        description=description,
                        folder=folder,
                        owner=owner,
                        last_modified=last_modified,
                        calculations=calculations,
                        identifier_complex=identifier_complex,
                    )
        ValueBasedSearch.__init__(self,
                                identifier = identifier,
                                identifier_complex= identifier_complex,
                                name = name,
                                description = description ,
                                folder = folder,
                                owner = owner,
                                last_modified = last_modified,
                                queries = queries,
                                calculations = calculations,
                                duration = duration,
                                operator = operator,
                                )

        self.queries = queries
        self.duration = duration
        self.operator=operator
        
    @property
    def tags(self):
        return [query.tag for query in self.queries]

    def _json_definition(self):
        return {
            **super()._json_definition(),
            "queries": self.queries,
            "parameters": {
                "minimumDuration": int(self.duration.total_seconds()),
                "operator": self.operator,
            },
        }

    def _json_data_queries(self):
        query_data = []

        for query in self.queries:
            value = query.values_numeric
            operator = query.condition
            if operator.lower() == "constant":
                value = ""
            elif query.tag.isnumeric():
                value = value[0]
                if value == int(value):
                    value = int(
                        value
                    )  # converting to int when possible avoids phantom 'unsaved changes' in ux
                value = str(value)
            elif operator == "=":
                operator = "In set"

            query_data.append(
                {
                    "interpolationType": query.tag._interpolation_data,
                    "operator": operator,
                    "shift": int(query.tag.shift.total_seconds()),
                    "tagName": query.tag.name,
                    "value": value,
                }
            )

        return query_data

    def _json_data(self):
        return {
            "calculations": self.calculations,
            "minimumIntervalLength": str(int(self.duration.total_seconds())),
            "operator": self.operator,
            "queries": self._json_data_queries(),
        }

    

class ValueBasedSearchFactory(SearchBaseFactory,ValueBasedSearchAPI):
    """Factory for generating and retrieving Value based searches"""

    _tm_class = ValueBasedSearchImpl

    def __call__(
        self,
        queries,
        name="New Search",
        description="",
        folder=None,
        duration=None,
        calculations=None,
        operator=LogicalOperators.AND,
    ):
        """Instantiate a new Value based search

        Parameters
        ----------
        queries : list of SearchQuery or list of Any
            value search queries
            List of queries can be of tuples.

            Query can contain operatior of type ValueBasedSearchOperators

            - LESS_THAN: Represents "<" operator for value based search
            - GREATER_THAN: Represents ">" operator for value based search
            - EQUAL_TO: Represents "=" operator for value based search
            - NOT_EQUAL_TO: Represents "!=" operator for value based search
            - LESS_THAN_EQUAL_TO: Represents "<=" operator for value based search
            - GREATER_THAN_EQUAL_TO: Represents ">=" operator for value based search
            - CONSTANT: Represents "CONSTANT" operator for value based search
            - IN_SET: Represents "IN_SET" operator for value based search
        name : str
            Name of the search; only relevant when saving
        description : str
            Description of the search; only relevant when saving
        folder : Folder or Any
            Folder to save the search in
        duration : Time
            time duration needs to be defined for the search
        calculations : list of SearchCalculation or Any
            Calculations to perform on the search.Calculation operation can be
            of type SearchCalculationOptions

            Supported SearchCalculationOptions include

            - SearchCalculationOptions.MEAN: maximum operation
            - SearchCalculationOptions.MINIMUM: minimum operation
            - SearchCalculationOptions.MAXIMUM: maximum operation
            - SearchCalculationOptions.START: minimum operation
            - SearchCalculationOptions.DELTA: delta operation
            - SearchCalculationOptions.INTEGRAL: integral operation
            - SearchCalculationOptions.STDEV: standart deviation operation

        operator : LogicalOperators Enum, default LogicalOperators.AND
            Operations allowed for handling multiple queries.

            - LogicalOperators.AND: AND operation
            - LogicalOperators.OR: OR operation

        Returns
        -------
        ValueBasedSearch

        Example
        -------

        .. code-block:: python

            from trendminer.impl.search import ValueBasedSearchOperators
            queries=[
                (level, ValueBasedSearchOperators.GREATER_THAN, 35),
                ("TM-BP2-PRODUCT.1",ValueBasedSearchOperators.EQUAL_TO ,"ALPHA"),
            ],

        Note
        ----
        In order to perform below example the tags or attribute need to be active.

        Example
        -------

        .. code-block:: python

            #Example1: Simple Value Based Search Operation
            from trendminer.impl.search import ValueBasedSearchOperators,LogicalOperators

            level = client.tag.get_by_name("TM-BP2-LEVEL.1")
            vbs = client.search.value(queries=[
                (level, ValueBasedSearchOperators.GREATER_THAN, 35),
                ("TM-BP2-PRODUCT.1",ValueBasedSearchOperators.EQUAL_TO ,"ALPHA"),
            ],
            operator=LogicalOperators.AND,
            duration="2m"
            )

            results = vbs.get_results(("2019-01-20", "2019-01-29"))

            #Example2: Value Based Search Operation by adding calculations

            from trendminer.impl.search import ValueBasedSearchOperators,SearchCalculationOptions

            calculations = {
                        "test": ("TM-BP2-LEVEL.1", SearchCalculationOptions.MAXIMUM),
                        "test2": ("TM-BP2-PRODUCT.1", SearchCalculationOptions.START),
                    }
            vbs = client.search.value(
                queries=[("TM-BP2-LEVEL.1", ValueBasedSearchOperators.GREATER_THAN, 40)],
                calculations=calculations,
            )
            results = vbs.get_results(("2019-01-20", "2019-01-22"))

            # Value Based Search results by excluding intervals

            search_interval = client.time.interval("2019-01-20 01:00", "2019-01-29 23:00")
            excluded = [
                client.time.interval("2019-01-22 02:00", "2019-01-22 23:00"),
                client.time.interval("2019-01-24 01:00", "2019-01-24 23:00"),
            ]
            results = vbs.get_results(search_interval, excluded_intervals=excluded)
        """
        duration = duration or 2 * self.client.resolution.total_seconds()

        return self._tm_class(
            client=self.client,
            identifier=None,
            identifier_complex=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            queries=queries,
            duration=duration,
            calculations=calculations,
            operator=operator,
        )

    @kwargs_to_class
    def _from_json(self, data):
        """From json with full info"""
        return {
            **self._json_to_kwargs_base(data),
            "identifier_complex": data["data"]["id"],
            "calculations": [
                SearchCalculationFactory(client=self.client)._from_json(calc)
                for calc in data["data"]["calculations"]
            ],
            "duration": float(data["data"]["minimumIntervalLength"]),
            "operator": _LOGICAL_OPERATORS_DICT[data["data"]["operator"]],
            "queries": [
                SearchQueryFactory(client=self.client)._from_json(query)
                for query in data["data"]["queries"]
            ],
        }
