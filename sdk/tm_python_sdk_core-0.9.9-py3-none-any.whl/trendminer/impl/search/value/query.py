import re

from trendminer.impl import _input as ip
from trendminer.impl.base import HasOptions, TrendMinerFactory
# from trendminer.impl.constants import VALUE_BASED_SEARCH_OPERATORS
from trendminer.impl.options.vbs_options import (
    _VALUE_BASED_SEARCH_OPERATORS_DICT, ValueBasedSearchOperators,
    _ANALOG_TAG_VBS_OPERATORS,_DIGITAL_TAG_VBS_OPERATORS)
from trendminer.impl.search.tag import ReferencingTag, TagFactory
from trendminer.sdk.search.search import SearchQuery


class SearchQueryImpl(ReferencingTag,SearchQuery):
    """Query on value based search

    Attributes
    ----------
    tag : Tag
        The tag or attribute we are searching
    condition : str
        <, >, =, !=, <=, ">=", "Constant", "In set"
    values : Any
        value to assign for the tag
    """

    condition = HasOptions(ValueBasedSearchOperators)

    def __init__(self, client, tag, condition, values):
        ReferencingTag.__init__(self,client=client, tag=tag)
        SearchQuery.__init__(self,
                            tag = tag,
                            condition = condition,
                            value = values,
                            )
        self.condition = condition
        self.values = values


    @property
    def values(self):
        if self.tag.isnumeric():
            return [float(value) for value in ip.any_list(self._values)]
        else:
            # return strings to the user for non-numeric tags
            return [self.tag.states[i] for i in self._values]

    @property
    def values_numeric(self):
        if self.tag.isnumeric():
            return [float(value) for value in ip.any_list(self._values)]
        return self._values

    @values.setter
    def values(self, values):
        # json input, avoid request to load tag data
        if "_tag_type" in self.tag.lazy:
            self._values = values
        # user input, process
        else:
            values = ip.any_list(values)
            if self.condition.lower() == "constant":
                values = []
            if self.tag.isnumeric():
                # converting numeric values to floats
                self._values = [float(value) for value in values]
            else:
                # convert to state indices for non-numeric tags
                self._values = [
                    state if isinstance(state, int) else self.tag._state_index(state)
                    for state in values
                ]

    def __json__(self):
        return {
            **super().__json__(),
            "condition": self.condition,
            "values": self.values_numeric,
        }

    def __repr__(self):
        if self.condition == "Constant":
            value_str = ""
        else:
            value_str = f" {self.values}"
        return f"<< {self.__class__.__name__} | {self.tag.name} {self.condition}{value_str} >>"


class SearchQueryFactory(TrendMinerFactory):
    """Factory for generating and retrieving search query"""

    _tm_class = SearchQueryImpl

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        SearchQuery
            An instance of the SearchQuery class
        """
        operator = data["operator"]
        values = data["value"]
        if operator == "Constant":
            values = []
        return self._tm_class(
            client=self.client,
            tag=TagFactory(client=self.client)._from_json_search_query(data),
            condition=_VALUE_BASED_SEARCH_OPERATORS_DICT[data["operator"].lower()],
            values=values,
        )

    def __from_query(self, query):
        if isinstance(query, str):
            condition = (
                re.search("([<>=!]{1,2}[ ]*)|(constant[ ]*$)", query, re.IGNORECASE)
                .group()
                .strip()
                .lower()
            )
            (tag, value) = [part.strip() for part in query.split(condition)]
            values = [value]

        elif isinstance(query, dict):
            tag = query["reference"]
            condition = query["operator"]
            values = query["values"]

        else:
            tag = query[0]
            condition = query[1]
            if tag.tag_type == 'DIGITAL':
                if query[1] in _DIGITAL_TAG_VBS_OPERATORS:
                    condition = query[1]
                else:
                    raise ValueError(
                                f"'{query[1].name}' is not a valid option of {str(ValueBasedSearchOperators)} type for DIGITAL type tag: Supported Enum members {', '.join([i.name for i in _DIGITAL_TAG_VBS_OPERATORS])}"
                                    )
            elif tag.tag_type == 'ANALOG':
                if query[1] in _ANALOG_TAG_VBS_OPERATORS:
                    condition = query[1]
                else:
                    raise ValueError(
                                f"'{query[1].name}' is not a valid option of {str(ValueBasedSearchOperators)} type for ANALOG type tag : Supported Enum members {', '.join([i.name for i in _ANALOG_TAG_VBS_OPERATORS])}"
                                    )
            try:
                values = ip.any_list(query[2])
            except IndexError:
                values = None

        return SearchQueryImpl(
            client=self.client,
            tag=tag,
            condition=condition,
            values=values,
        )

    def get_by_query(self, query):
        """Generating a value based search query

        Parameters
        ----------
        query : str or dict or tuple
            query from which parameter, operator and value need to be extracted

        Returns
        -------
        SearchQuery
            An instance of the SearchQuery class     
        """
        return self.__from_query(query)

    @property
    def _get_methods(self):
        return (self.get_by_query,)
