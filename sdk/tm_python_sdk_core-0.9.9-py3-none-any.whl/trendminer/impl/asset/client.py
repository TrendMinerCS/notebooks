import abc

from trendminer.sdk.asset.asset import AssetAPI

from .factory import AssetFactory


class AssetClient(abc.ABC):
    """Asset client"""

    @property
    def asset(self) -> AssetAPI:
        """Factory for retrieving assets and attributes

        Returns
        -------
        AssetFactory
        """
        return AssetFactory(client=self)
