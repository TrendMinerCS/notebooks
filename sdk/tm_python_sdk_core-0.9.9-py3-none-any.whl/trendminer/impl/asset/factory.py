# pylint: disable=R0201

import abc
import json

import requests
from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.base import (MultiFactory, TrendMinerFactory,
                                  kwargs_to_class, to_subfactory)
from trendminer.impl.constants import (CONTEXT_ITEM_PERMISSION,
                                       DEFAULT_ENCODING, MAX_GET_SIZE,
                                       SERVICE_NAMES)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import AmbiguousResource, ResourceNotFound
from trendminer.impl.services.services import _assets_service, set_default_url
from trendminer.impl.tag import TagFactory
from trendminer.impl.visuals import default_shiftable_config
from trendminer.sdk.asset.asset import AssetAPI

from .asset import AssetImpl
from .attribute import AttributeImpl

# from .framework import AssetFrameworkFactory


class NodeFactoryBase(TrendMinerFactory, abc.ABC):
    """NodeFactoryBase abstract class"""

    @kwargs_to_class
    def _from_json(self, data):
        if data.get("deleted", False) is True:
            return self._json_to_kwargs_deleted(data)
        else:
            return self._json_to_kwargs(data)

    def _json_to_kwargs(self, data):
        return {
            "name": data["name"],
            "description": data.get("description"),
            "identifier": data["identifier"],
            "source": {"identifier" : data["source"].get('identifier'), "af_type" : data["source"].get('type'), "name" : data["source"].get('name')},
            "template": data.get("template"),
            "identifier_template": data.get(
                "templateId"
            ),  # TODO: perhaps create template class?
            "identifier_external": data.get(
                "externalId"
            ),  # TODO: UPGRADE; no longer present in 2023.R1. Affects path
            "path_hex": data["paths"][0],
        }

    def _json_to_kwargs_deleted(self, data):
        return {
            "name": data["name"],
            "description": data.get("description"),
            "identifier": data["identifier"],
            "source": None,
            "template": data.get("template"),
            "identifier_template": data.get("templateId"),
            "identifier_external": data.get("externalId"),
            "path_hex": None,
        }

    def _json_to_kwargs_context_item(self, data):
        return {
            "name": data["name"],
            "description": data.get("description", ""),
            "identifier": data["reference"],
        }


class AssetFactoryBase(NodeFactoryBase):
    """AssetFactoryBase class"""

    _tm_class = AssetImpl

    def _json_to_kwargs(self, data):
        if "ASSET_NO_PERMISSIONS" in data["permissions"]:
            #Ideally this block should not get executed as permission based filteration should
            #get applied in asset/attribute fetch apis, but keeping this block for now,
            #not to introduce any breaking changes
            return {
                "name": data["name"],
                "identifier": data["identifier"],
            }
        else:
            return super()._json_to_kwargs(data)

    @kwargs_to_class
    def _from_json_context_item(self, data):
        return self._json_to_kwargs_context_item(data)


class AttributeFactoryBase(NodeFactoryBase):
    """AttributeFactoryBase class"""

    _tm_class = AttributeImpl

    def _json_to_kwargs(self, data):
        super_kwargs = super()._json_to_kwargs(data)
        try:
            if super_kwargs["source"].get("af_type") == "CSV":
                tag = TagFactory(client=self.client)._from_json(
                    data["timeSeriesDefinition"]
                )
            else:  # pragma: no cover
                # for PI AF, only name given
                tag = TagFactory(client=self.client)._from_json_name_only(data["data"])
        except KeyError as excp:
            raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp

        return {
            **super_kwargs,
            **default_shiftable_config,
            "tag": tag,
        }

    def _json_to_kwargs_deleted(self, data):
        return {
            **super()._json_to_kwargs_deleted(data),
            **default_shiftable_config,
            "tag": data.get("timeSeriesDefinition"),
        }

    def _json_to_kwargs_datareference(self, data):
        return {
            "name": data["name"],
            "description": data.get("description"),
            "identifier": data["id"],
            "path_hex": data["path"],
            "color": data["options"]["color"],
            "scale": data["options"]["scale"],
            "shift": data["options"]["shift"] / 1000,
            "visible": data["options"]["visible"],
        }

    @kwargs_to_class
    def _from_json_trendhub_group(self, data):
        return self._json_to_kwargs_datareference(data)

    @kwargs_to_class
    def _from_json_trendhub(self, data):
        return self._json_to_kwargs_datareference(data["dataReference"])

    @kwargs_to_class
    def _from_json_fingerprint(self, data):
        # TODO: we have information on the interpolation type that we are not using -> additional requests when calling __json__ to get the interpolation type that we are ignoring here
        return {
            "identifier": data["identifier"],
            "path_hex": data["properties"]["path"],
            "color": None,
            "scale": None,
            "shift": data["properties"]["shift"],
            "visible": data["properties"]["visible"],
        }

    @kwargs_to_class
    def _from_json_context_item(self, data):
        return {
            **super()._json_to_kwargs_context_item(data),
            **default_shiftable_config,
        }

    @kwargs_to_class
    def _from_json_current_value_tile(self, data):
        return {
            "identifier": data["componentIdentifier"],
            "path_hex": data["path"],
            **default_shiftable_config,
        }

    # TODO: better way of implementing. Implementation on (another) base class?
    def __from_path(self, ref):
        attribute = AssetFactory(client=self.client).get_by_path(ref)
        if not isinstance(attribute, self._tm_class):
            raise TypeError(ExceptionMessages.TYPE_ERROR.format(ref, "ATTRIBUTE"))
        return attribute

    def get_by_path(self, ref):
        return self.__from_path(ref)

    def __from_path_hex(self, ref):
        attribute = AssetFactory(client=self.client).get_by_path_hex(ref)
        if not isinstance(attribute, self._tm_class):
            raise TypeError(ExceptionMessages.TYPE_ERROR.format(ref, "ATTRIBUTE"))
        return attribute

    def get_by_path_hex(self, ref):
        return self.__from_path_hex(ref)


# TODO: rename to NodeFactory. Then we can use AssetFactory and AttributeFactory
class AssetFactory(MultiFactory, AssetAPI):
    """Implements methods for Asset and Attribute retrieval returns an AssetFactory instance"""

    factories = {
        "ASSET": AssetFactoryBase,
        "ATTRIBUTE": AttributeFactoryBase,
    }

    # @property
    # def framework(self):
    #     """Interface to factory for retrieving and creating asset frameworks
    #     Returns
    #     -------
    #     AssetFrameworkFactory
    #         Factory for retrieving retrieving and creating asset frameworks
    #     """
    #     return AssetFrameworkFactory(client=self.client)

    def __validate_permissions(self, data : dict, permission = None):
        """Validate if an assset/attribute response dictionary has required permissions
        Parameters
        ----------
        data : dict
            assset/attribute response json
        permission : str, optional
            filter property for specific permission

        Returns
        -------
        nodes : list[dict]
            list of dictionary with valid permission
        """
        if 'permissions' in data:
            if "ASSET_NO_PERMISSIONS" in data['permissions']:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_PERMITTED)
            if permission is not None:
                if permission not in data['permissions']:
                    raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_PERMITTED)
        else:
            raise ResourceNotFound(ExceptionMessages.ASSET_NO_PERMISSION)

    @to_subfactory
    def _from_json(self, data):
        if "type" in data:
            return data["type"]
        elif "ASSET_NO_PERMISSIONS" in data["permissions"]:
            return "ASSET"  # only assets can have no permissions
        else:  # pragma: no cover
            raise ValueError(ExceptionMessages.RESOURCE_NOT_PERMITTED)

    def __from_identifier(self, ref, permission = None):
        try:
            response = _assets_service(self.client).get_asset(ref)
            response.raise_for_status()
            content = response.json()
            if permission is not None:
                self.__validate_permissions(content, permission)
            else:
                self.__validate_permissions(content)
            return self._from_json(content)
        except requests.exceptions.RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def get_by_identifier(self, ref):
        return self.__from_identifier(ref)

    # TODO: investigate if we can query path directly via rsql
    def __from_path(self, ref, permission = None):
        asset_name_list = [name for name in ref.split("/") if name != ""]
        # asset = self._root()
        #setting intial path parent to blank
        path_hex = None
        for idx, asset_name in enumerate(asset_name_list):
            #only check for asset context permission when it is the last node of asset hierarchy
            if idx == len(asset_name_list) - 1:
                asset = ip.object_match_nocase(
                self.__browse_asset(path_hex, permission), attribute="name", value=asset_name
                )
            else:
                asset = ip.object_match_nocase(
                    self.__browse_asset(path_hex, None), attribute="name", value=asset_name
                )
            path_hex = asset.path_hex
        return asset
    
    def __browse_asset(self, path_hex, permission):
        """Direct children of the asset in the asset framework. Children can be attributes other assets.

        Parameters
        ----------
        path_hex : str
            Hexagonal path as string, e.g. "0000025e.0000025f.00000260"
        permission : str
            Permission for asset/attribute filtering

        Returns
        -------
        List[Union[Asset, Attribute]]: Direct children of the current asset, which can be assets or attributes.
        """
        endpoint = "/af/asset/"
        service_name = SERVICE_NAMES["assets"]
        params = {"size": MAX_GET_SIZE, "parentPath": path_hex}
        self.client = set_default_url(self.client, service_name)
        try:
            response = self.client.session.get(
                url=f"{endpoint}browse", params=params
            )
            response.raise_for_status()
            contents = response.json()["content"]
            if permission is not None:
                return [self._from_json(node) for  node in ip.filter_assets(contents, permission)]
            return [self._from_json(node) for  node in ip.filter_assets(contents)]
        except requests.exceptions.RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
    
    # def dict_match_nocase(self, items, key, value):
    #     """
    #     Return dict ojbect of which a given key matches given string value.

    #     Try case-insensitive match when no sensitive match is found.

    #     Parameters
    #     ----------
    #     items : list
    #         list of dicts
    #     key : str
    #         key present in all dicts in the list
    #     value : str
    #         string that should match dict[key] (case insenstive)

    #     Returns
    #     -------
    #     data : dict
    #         dict of which dict[key] matches value
    #     """

    #     results = [item for item in items if item[key].lower() == value.lower()]

    #     if len(results) == 1:
    #         data = results[0]

    #     elif len(results) == 0:
    #         raise ResourceNotFound(f'No match for {key}=="{value}"')

    #     else:
    #         case_sensitive = [item for item in results if item[key] == value]
    #         if len(case_sensitive) == 1:
    #             data = results[0]
    #         else:
    #             raise AmbiguousResource(
    #                 f'Multiple matches for {key}=="{value}": '
    #                 f'{", ".join([item[key] for item in results])}'
    #             )

    #     return data

    def get_by_path(self, ref):
        return self.__from_path(ref)

    def __from_path_hex(self, ref, permission = None):
        params = {"path": ref}
        # response = self.client.session.get(Node.endpoint, params=params)
        try:
            response = _assets_service(self.client).get_asset_by_path(**params)
            response.raise_for_status()
            content = response.json()["content"]
            if len(content) > 1:  # pragma: no cover
                raise AmbiguousResource(ref)
            if len(content) == 0:  # pragma: no cover
                raise ResourceNotFound(ref)
            if permission is not None:
                self.__validate_permissions(content[0], permission)
            else:
                self.__validate_permissions(content[0])
            return self._from_json(content[0])
        except requests.exceptions.RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def get_by_path_hex(self, ref):
        return self.__from_path_hex(ref)
    
    def _get_by_path_hex_in_context(self, ref):
        """Returns Asset or Attribute from path with hex values
        Only used  for internal retrieval of Assets or Attributes from ComponentFactory

        Parameters
        ----------
        ref : str
            Hexagonal path as string, e.g. "0000025e.0000025f.00000260"

        Returns
        -------
        Asset or Attribute: The asset or attribute at the given path

        """
        return self.__from_path_hex(ref, CONTEXT_ITEM_PERMISSION)
    
    def _get_by_identifier_in_context(self, ref):
        """Returns Asset or Attribute from path with hex values
        Only used for internal retrieval of Assets or Attributes from ComponentFactory

        Parameters
        ----------
        ref : str
            Hexagonal path as string, e.g. "0000025e.0000025f.00000260"

        Returns
        -------
        Asset or Attribute: The asset or attribute at the given path
        """

        return self.__from_identifier(ref, CONTEXT_ITEM_PERMISSION)
    
    def _get_by_path_in_context(self, ref):
        """Retrieve an asset on a given path
        Only used for internal retrieval of Assets or Attributes from ComponentFactory

        Parameters
        ----------
        ref : str
            Asset path

        Returns
        -------
        Asset: Asset on the given path
        """
        return self.__from_path(ref, CONTEXT_ITEM_PERMISSION)

    def __by_rsql(self, query):
        """Executes RSQL query to the assets database
        Used by other functions to retrieve assets, though use cases could exist where a custom query is input directly.

        Parameters
        ----------
        query: str
            RSQL query, e.g. "name==my_asset"

        Returns
        -------
        List[Union[Asset, Attribute]]: List of assets and attributes found by the query
        """
        body = {"query": query, "size": MAX_GET_SIZE}

        # paginator = self.client.session.paginated(keys=["content"], json_params=True)
        # content = paginator.post(
        #     url=f"{Node.endpoint}search",
        #     json=data,
        # )
        method = _assets_service(self.client).search_asset_using_post
        content = self._prepare_paged_response(body, method, keys=["content"])
        # return [self._from_json(data) for data in content]
        return [self._from_json(node) for  node in ip.filter_assets(content)]

    def _query_rsql(self, key, ref, frameworks):
        """Boilerplate for executing RSQL search method. Mainly adds filters on the asset frameworks to search."""
        query = f"{key}=='{ref}'"
        if frameworks is not None:
            frameworks = self.client.asset.framework.list(frameworks)
            identifier_str = ",".join([source.identifier for source in frameworks])
            query = query + f";source.identifier=in=('{identifier_str}')"
        return self.__by_rsql(query=query)

    def __by_template(self, ref, frameworks=None):
        return self._query_rsql(key="template", ref=ref, frameworks=frameworks)

    def __by_name(self, ref, frameworks=None):
        return self._query_rsql(key="name", ref=ref, frameworks=frameworks)

    def __by_description(self, ref, frameworks=None):
        return self._query_rsql(key="description", ref=ref, frameworks=frameworks)

    def search(self, *args, **kwargs):
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        results = []
        get_ids = lambda obj: obj.identifier
        search_counter = -1
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    search_counter += 1
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    #For the first iteration skip the comparision of common identifiers
                    if search_counter == 0:
                        results.extend(data)
                        continue
                    data_ids = list(map(get_ids, data))
                    result_ids = list(map(get_ids, results))
                    common_ids = set(data_ids).intersection(result_ids)
                    #Only add the items with matching identifiers
                    results = [obj for obj in data if obj.identifier in common_ids]
        return results
    @property
    def _get_methods(self):
        return (
            self._subfactory("ATTRIBUTE").get_by_identifier,
            self._subfactory("ASSET").get_by_identifier,
            self.get_by_path_hex,
            self.get_by_path,
        )

    @property
    def _search_methods(self):
        return self.__by_name, self.__by_description, self.__by_rsql, self.__by_template

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, data, method, keys, **kwargs):
        setter_key = "json"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = []
            response = method(data)
            response.raise_for_status()
            total_pages = self._prepare_response(response)["page"]["totalPages"]
            responses.append(response)
            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(data))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
