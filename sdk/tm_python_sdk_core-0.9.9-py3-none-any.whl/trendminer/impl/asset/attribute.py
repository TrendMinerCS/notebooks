from trendminer.impl.base import ByFactory
from trendminer.impl.tag import TagFactory
from trendminer.impl.visuals import Shiftable
from trendminer.sdk.asset.asset import Attribute

from .node import Node


class AttributeImpl(Node, Shiftable, Attribute):
    # pylint: disable=too-many-arguments
    _component_type = "ATTRIBUTE"
    tag = ByFactory(TagFactory)

    def __init__(
        self,
        client,
        name,
        description,
        identifier,
        source,
        template,
        identifier_template,
        identifier_external,
        path_hex,
        tag,
        color,
        scale,
        shift,
        visible,
    ):
        Node.__init__(
            self=self,
            client=client,
            name=name,
            description=description,
            identifier=identifier,
            source=source,
            template=template,
            identifier_template=identifier_template,
            identifier_external=identifier_external,
            path_hex=path_hex,
        )

        Shiftable.__init__(
            self=self,
            color=color,
            scale=scale,
            shift=shift,
            visible=visible,
        )

        Attribute.__init__(
            self=self,
            name = name,
            description = description,
            identifier = identifier,
            source = source,
            template = template,
            identifier_template = identifier_template,
            identifier_external = identifier_external,
            path_hex = path_hex,
            tag = tag,
            color = color,
            scale = scale,
            shift = shift,
            visible = visible
        )

        self.tag = tag

    @property
    def interpolation_type(self):
        return self.tag.interpolation_type

    def isnumeric(self):
        return self.tag.isnumeric()

    def __json__(self):
        return {
            "dataReference": {
                **Shiftable.__json__(self),
                "description": self.description,
                "id": self.identifier,
                "name": self.name,
                "path": self.path_hex,
                "type": self._component_type,
            },
            "type": "DATA_REFERENCE",
        }
