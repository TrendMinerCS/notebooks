from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.constants import MAX_GET_SIZE, SERVICE_NAMES
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import set_default_url
from trendminer.sdk.asset.asset import Asset

from .node import Node


class AssetImpl(Node, Asset):

    _component_type = "ASSET"
    _service_name = SERVICE_NAMES["assets"]

    def __init__(
        self,
        client,
        name,
        description,
        identifier,
        source,
        template,
        identifier_template,
        identifier_external,
        path_hex,
    ):
        Node.__init__(self, client=client, name=name, description=description, identifier=identifier, source=source,
            template=template, identifier_template=identifier_template, identifier_external=identifier_external,path_hex=path_hex,
        )

        Asset.__init__(self,name = name, description = description, identifier = identifier, source = source, template = template,
        identifier_template = identifier_template, identifier_external = identifier_external, path_hex = path_hex
        )

    @property
    def children(self):
        params = {"size": MAX_GET_SIZE, "parentPath": self.path_hex}
        self.client = set_default_url(self.client, self._service_name)
        try:
            response = self.client.session.get(
                url=f"{self._endpoint}browse", params=params
            )
            response.raise_for_status()
            return [self.client.asset._from_json(child) for  child in ip.filter_assets(response.json()["content"])]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def __json__(self):
        return {}
