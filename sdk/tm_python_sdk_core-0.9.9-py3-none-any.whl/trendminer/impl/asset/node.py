import abc

# from trendminer.impl.access import AccessRuleFactory
# from trendminer.impl.asset.framework import AssetFrameworkFactory
from trendminer.impl.base import Gettable, LazyLoadingClass
from trendminer.impl.constants import SERVICE_NAMES


class Node(Gettable, LazyLoadingClass, abc.ABC):
    """The Node class is the basis for both Assets and Attributes

    Attributes
    ----------
    name : str
        Instance name. The names of assets and attributes make up the path.
    description : str
        Instance description
    source : dict
        A dictionary containing information about the basic details of the asset framework.
        It should contain keys 'name' and 'af_type' representing the name and type of the aseet framework.
        Asset framework type 'af_type' can either be a "CSV" or "DATASOURCE".
    template : str, optional
        The asset/attribute template when defined
    identifier_template : str, optional
        Identifier for the template. For a CSV asset structure, `identifier_template` is equal to `template`, which is a
        simple string of the template name. For other sources, it is the reference within the external source (for PI AF
        it is a UUID).
    identifier_external : str,  optional
        Identifier of the node in the external source. For a CSV asset framework, this is equal to the path of the node
        within the structure.For other sources, it is the reference within the external source (for PI AF
        it is a UUID).
    path_hex : str, optional
        path as a string of hexadecimal identifiers used for internal referencing
    """

    _endpoint = "/af/asset/"
    _service_name = SERVICE_NAMES["assets"]
    _component_type = None
    # source = ByFactory(AssetFrameworkFactory)

    # pylint: disable=too-many-arguments
    def __init__(
        self,
        client,
        name,
        description,
        identifier,
        source,
        template,
        identifier_template,
        identifier_external,
        path_hex,
    ):

        Gettable.__init__(self, client=client, identifier=identifier)

        self.name = name
        self.description = description
        self.source = source
        self.template = template
        self.identifier_template = identifier_template
        self.identifier_external = identifier_external
        self.path_hex = path_hex

        self._path = None
        self._parent = None

    @property
    def parent(self):
        """Direct parent asset of the node

        Returns
        -------
        Asset
            Direct parent asset
        """
        parent_path_hex = (
            ".".join(self.path_hex.split(".")[:-1])
            if self.path_hex is not None
            else None
        )
        if not parent_path_hex:
            return None
        return self.client.asset.get_by_path_hex(parent_path_hex)

    @property
    def path(self):
        """Human-readable path in the asset framework

        Returns
        -------
        str
            Human-readable path, e.g. "my_parent/this_node"
        """
        if self.source is not None and self.source.get('af_type') == "CSV":
            if self.identifier_external is not None:
                return f"{self.source.get('name')}{self.identifier_external}"
            return self.source.get('name')
        # pragma: no cover
        names = [self.name]
        parent = self.parent
        if parent is not None:
            while True:
                names.insert(0, parent.name)
                parent = parent.parent
                if parent is None:
                    break
        return "/".join(names)

    # @property
    # def access(self):
    #     """Interface to retrieving and setting access rights on the current node

    #     Returns
    #     -------
    #     AccessRuleFactory
    #         Interface to retrieving and setting access rights on the current node
    #     """
    #     return AccessRuleFactory(parent=self,
    #                              endpoint=f"{self.endpoint}{self.path_hex}/accessrule",
    #                              option_dict=ASSET_SHARE_OPTIONS,
    #                              derived_option_dict=ASSET_SHARE_DERIVED_OPTIONS)

    # @property
    # def access_inherited(self):
    #     """Interface to retrieving access rights inherited from a parent asset

    #     Returns
    #     -------
    #     AccessRuleFactory
    #         Interface to retrieving access rights inherited from a parent asset
    #     """
    #     return AccessRuleFactory(parent=self,
    #                              endpoint=f"{self.endpoint}{self.path_hex}/accessrule/inherited",
    #                              option_dict=ASSET_SHARE_OPTIONS,
    #                              derived_option_dict=ASSET_SHARE_DERIVED_OPTIONS)

    def _full_instance(self):
        return self.client.asset.get_by_identifier(self.identifier)

    def _json_component(self):
        return {
            "type": self._component_type,
            "reference": self.identifier,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self._repr_lazy('name')} >>"
