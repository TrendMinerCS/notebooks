import abc

import cachetools

from trendminer.impl.base import (Gettable, LazyLoadingClass,
                                  TrendMinerFactory, kwargs_to_class)
from trendminer.impl.constants import (MAX_GET_SIZE, MAX_USER_CACHE,
                                       SERVICE_NAMES)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.services.services import set_default_url
from trendminer.sdk.commons.user import User

from . import _input as ip
from .constants import KEYCLOAK_REALM
from .exceptions import ActionProhibitedError, FromJsonError


class UserClient(abc.ABC):
    """Client holding the UserFactory"""

    @property
    def user(self):
        """Factory for retrieving users"""
        return UserFactory(client=self)


class UserImpl(Gettable, LazyLoadingClass,User):
    """A TrendMiner user

    Attributes
    ----------
    client : TrendMinerClient
        Trendminer client instance for the appliance
    identifier : str, optional
        Unique reference on the appliance
    name : str
        name of the user
    first : str
        first name of the user
    last : str
        last name of the user
    subject_type : str
        subject type of the user
    created : datetime.datetime
        The instance when user was created
    """

    _endpoint = f"/auth/realms/{KEYCLOAK_REALM}/local/users/"  # TODO: probably does not work for SSO users

    def __init__(
        self,
        client,
        identifier,
        subject_type,
        name,
        # admin,
        # mail,
        first,
        last,
        created,
    ):
        
        Gettable.__init__(self, client=client, identifier=identifier)
        User.__init__(self,
                    identifier = identifier,
                    subject_type = subject_type,
                    name = name,
                    first = first,
                    last = last,
                    created = created)
        self.name = name
        self.first = first
        self.last = last
        self.identifier = identifier
        # self.admin = admin
        # self.mail = mail
        self.created = (
            self.client.time.datetime(created) if created is not None else None
        )
        self.subject_type = subject_type

    @property
    def everyone(self):
        return self.identifier == "Everyone"

    @property
    def blueprint(self):
        return {"name": self.name}

    def _full_instance(self):
        if "identifier" in self.lazy:
            return self.client.user.get_by_name(ref=self.name)
        else:
            return self.client.user.get_by_identifier(ref=self.identifier)

    def __json__(self):
        return self.identifier

    def __repr__(self):
        return f"<< User | {self._repr_lazy('name')} >>"


class UserFactory(TrendMinerFactory):
   
    _tm_class = UserImpl
    _service_name = SERVICE_NAMES["keycloak"]

    def __init__(self, client):
        super().__init__(client)

    def everyone(self):
        """Returns the 'Everyone' user needed to give all users permissions/access at once"""
        return self._tm_class(
            client=self.client,
            identifier="Everyone",
            subject_type="EVERYONE",
            name="Everyone",
            # mail=None,
            # admin=False,
            first=None,
            last=None,
            created=None,
        )

    def _query_users(self, params):
        self.client = set_default_url(self.client, self._service_name)
        content = self.client.session.paginated(keys=["_embedded", "content"]).get(
            self._tm_class._endpoint, params=params
        )
        return [self._from_json(data=data) for data in content]

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=MAX_USER_CACHE),
        key=TrendMinerFactory._cache_key_ref,
    )
    def get_by_name(self, ref):
        if self.__has_wildcard(ref):
            raise ActionProhibitedError(ExceptionMessages.ACTION_PROHIBITED)
        if ref.lower() == "everyone":
            return self.everyone()
        params = {"username": ref, "size": 10}
        return ip.object_match_nocase(
            self._query_users(params), attribute="name", value=ref
        )

    def __by_any(self, ref):
        "Searches by username, first name, last name"
        if self.__has_wildcard(ref):
            raise ActionProhibitedError(ExceptionMessages.ACTION_PROHIBITED)
        return self._query_users(params={"search": ref, "size": MAX_GET_SIZE})

    def __has_wildcard(self, ref):
        wildcards = ["*", "?"]

        for char in ref:
            if char in wildcards:
                return True

        return False

    # def all(self):
    #     raise NotImplementedError

    def search(self, *args, **kwargs):
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        results = []
        get_ids = lambda obj: obj.identifier
        search_counter = -1
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    search_counter += 1
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    #For the first iteration skip the comparision of common identifiers
                    if search_counter == 0:
                        results.extend(data)
                        continue
                    data_ids = list(map(get_ids, data))
                    result_ids = list(map(get_ids, results))
                    common_ids = set(data_ids).intersection(result_ids)
                    #Only add the items with matching identifiers
                    results = [obj for obj in data if obj.identifier in common_ids]
        return results

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=10), key=TrendMinerFactory._cache_key_no_args
    )
    def self(self):
        return self.get_by_name(self.client.username)

    def _from_json_everyone(self, data):
        if data.get("subjectType", "").upper() == "EVERYONE":
            return self.everyone()
        else:  # pragma: no cover
            raise FromJsonError(data)

    def _json_to_kwargs_base(self, data):
        return {
            "first": data.get("firstName"),
            "last": data.get("lastName"),
            "subject_type": "USER",
        }

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["userId"],
            "name": data["username"],
            # "admin": ADMIN_ROLE in data["roles"],
            # "mail": data.get("email"),
            "created": data.get("createdDate"),
        }

    @kwargs_to_class
    def _from_json_limited(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["identifier"],
            "name": data["username"],
        }

    @kwargs_to_class
    def _from_json_limited_id(self, data):
        """Used in context filter and work organizer"""
        return {
            "identifier": data["userId"],
            "name": data["userName"],
        }

    @kwargs_to_class
    def _from_json_name_only(self, data):
        """Create lazy instance from only the name"""
        return {"name": data}

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        """Create lazy instance from only the identifier"""
        return {"identifier": data}

    @property
    def _get_methods(self):
        return (self.get_by_name,)

    @property
    def _search_methods(self):
        return (self.__by_any,)
