from copy import deepcopy

from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.constants import SERVICE_NAMES
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import set_default_url
from trendminer.sdk.tag.tag import TagCalculationOptions


def calculate(
    tag, intervals, operation: TagCalculationOptions, key=None, inplace=False, fun=None
):
    """Perform an aggregation operation on a tag for given intervals

    Parameters
    ----------
    tag : Tag
        The tag on which the operation happens
    intervals : list
        Intervals or context items on which to perform the aggregation
    operation : TagCalculationOptions
        operations to perform on the TAG. Calculate operation can be of type TagCalculationOptions
        Supported TagCalculationOptions include
        
       -TagCalculationOptions.MEAN: maximum operation
       -TagCalculationOptions.MINIMUM: minimum operation
       -TagCalculationOptions.MAXIMUM: maximum operation
       -TagCalculationOptions.START: minimum operation
       -TagCalculationOptions.DELTA: delta operation
       -TagCalculationOptions.INTEGRAL: integral operation
       -TagCalculationOptions.STDEV: standart deviation operation
    key : str, optional
        Key under which the calculation result needs to be stored on the interval. Defaults to the given operation.
    inplace : bool, default False
        When True, no value is returned, but the calculation results are added to the input values under the given
        key. Otherwise, copies of the intervals are returned on which the calculations results have been added.
    fun : function, optional
        Function to be applied to calculation results, e.g., `lambda x: x*24` to correct integral calculation units
        (from days to hours)

    Returns
    -------
    list or None
        Returns intervals and/or context items when `inplace=False`, no output if `inplace=True`. For intervals,
        calculations are added under `Interval.data`. When `inplace=True`, for context items the values are added under
        `ContextItem.fields`.
    """
    key = key or operation
    # operation = CALCULATION_OPTIONS[
    #     ip.case_correct(operation, CALCULATION_OPTIONS.keys())
    # ]
    # operationlist=HasOptions(TagCalculationOptions)

    if isinstance(operation, TagCalculationOptions):
        operation = operation.value
    else:
        raise ValueError(
            f"'{operation}' is not a valid member of {str(TagCalculationOptions)} type: Supported Enum members {', '.join(TagCalculationOptions.__dict__['_member_names_'])}"
            # f"'{operation}' is not a valid value of TagCalculationOptions type"
        )

    fun = fun or (lambda v: v)
    intervals = ip.any_list(intervals)
    if len(intervals) == 0:
        if inplace:
            return
        return []
    intervals = [
        (
            tag.client.time.interval(interval)
            if not isinstance(interval, tag.client.context.item._tm_class)
            else interval
        )
        for interval in intervals
    ]

    interval_dict = {f"{key}{i}": interval for i, interval in enumerate(intervals)}

    payload = {
        "searchType": operation,
        "tags": [
            {
                "tagName": tag.name,
                "timePeriods": [
                    (
                        {"key": interval_key, **interval.__json__()}
                        if not isinstance(interval, tag.client.context.item._tm_class)
                        else {"key": interval_key, **interval.interval.__json__()}
                    )
                    for interval_key, interval in interval_dict.items()
                ],
                "shift": int(tag.shift.total_seconds()),
                "interpolationType": tag._interpolation_data,
            }
        ],
        "filters": [],
    }
    tag.client = set_default_url(tag.client, SERVICE_NAMES["compute"])
    try:
        response = tag.client.session.post("/compute/calculate/", json=payload)
        response.raise_for_status()
    except RequestException as excp:
        excp.args = (f"Status: {excp.response.status_code}"), (
            (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
        )
        if excp.response.status_code in [400, 404]:
            raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
        if excp.response.status_code == 403:
            raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_PERMITTED) from excp
        if excp.response.status_code == 401:
            raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
        raise excp

    if tag.isnumeric():
        mapper = lambda v: fun(v)
    else:
        mapper = lambda v: fun(tag._state_dict.get(v))

    value_dict = {
        result["key"]: mapper(result.get("value")) for result in response.json()
    }

    if inplace:
        for interval_key, interval in interval_dict.items():
            interval.update({key: value_dict[interval_key]})

    else:
        output_intervals = []
        for interval_key, interval in interval_dict.items():
            output_interval = deepcopy(interval)
            output_interval.update({key: value_dict[interval_key]})
            output_intervals.append(output_interval)

        return output_intervals
