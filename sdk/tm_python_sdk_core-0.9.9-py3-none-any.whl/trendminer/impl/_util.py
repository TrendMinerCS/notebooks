# pylint: disable=R0201
"""This module contains utility class and methods"""

import base64
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Union

import isodate
from dateutil import parser


class EncryptionUtils:
    """Encryption Utility functions class."""

    def encode(self, string_to_encode: str) -> bytes:
        """Encode input string using Base64.
        Parameters:
        string_to_encode (str):string which needs to be encoded.

        Returns:
        encoded_text (str): encoded text in byte string
        """
        return base64.b64encode(string_to_encode.encode("utf-8"))[::-1]

    def decode(self, string_to_decode: bytes) -> str:
        """Decode the input string using Base64.
        Parameters:
        string_to_encode (str):string which needs to be encoded.

        Returns:
        decoded_text (str): decoded text
        """
        return base64.b64decode(string_to_decode[::-1]).decode("utf-8")


class DateTimeUtils:
    """Encryption Utility functions class."""

    def now(self) -> datetime:
        """now function gives current time in UTC

        Returns:
        current datetime in utc timezone
        """
        return datetime.now(timezone.utc)

    def string_to_datetime(self, time_str: str) -> datetime:
        """string_to_datetime parse the string datetime into datetime.datetime

        Parameters:
        time_str (str):datetime string which needs to be converted

        Returns:
        this return the datetime.datetime object

        """
        date = parser.isoparse(time_str)
        return date

    def string_to_timedelta(self, time_str: str) -> Any:
        """string_to_timedelta parse the string timedelta into datetime.timedelta

        Parameters:
        time_str (str):timedelta string which needs to be converted

        Returns:
        this return the datetime.timedelta object

        """
        try:
            return isodate.parse_duration(time_str)
        except isodate.isoerror.ISO8601Error:
            pass

        time_str = time_str.replace(" ", "")

        negative = False
        if time_str[0] == "-":
            time_str = time_str[1:]
            negative = True

        regex = re.compile(
            r"((?P<years>[.\d]+?)[yY])?((?P<months>[.\d]+?)M)?((?P<weeks>[.\d]+?)[wW])?((?P<days>[.\d]+?)d)"
            r"?((?P<hours>[.\d]+?)h)?((?P<minutes>[.\d]+?)m)?((?P<seconds>[.\d]+?)s)?"
            r"((?P<milliseconds>[.\d]+?)ms)?$"
        )

        parts = regex.match(time_str)

        if (parts := regex.match(time_str)) is None:
            raise ValueError(f'Could not parse any time information from "{time_str}"')

        time_params = {
            name: float(param) for name, param in parts.groupdict().items() if param
        }

        days = time_params["days"] if "days" in time_params else 0
        months = time_params.pop("months") if "months" in time_params else 0
        years = time_params.pop("years") if "years" in time_params else 0

        time_params.update({"days": days + round(365.25 * (years + months / 12))})
        time_delta = timedelta(**time_params)

        if negative:
            time_delta = -time_delta

        return time_delta


class InputUtils:
    """Format the different types of Inputs"""

    def any_list(self, i: Union[list[Any], set[Any], tuple[Any], None]) -> list[Any]:
        """Outputs list by converting tuple, or encapsulating object

        Parameters
        ----------
        i : Any
            To be converted into list

        Returns
        -------
        list
        """
        if i is None:
            return []
        if isinstance(i, list):
            return i
        if isinstance(i, tuple):
            return list(i)
        if isinstance(i, set):
            return list(i)
        return [i]


class DefaultUrlUtils:

    def get_default_url(self, service_name):

        namespace = os.getenv("KERNEL_NAMESPACE", "trendminer-kernels")
        if namespace.endswith("-kernels"):
            namespace = namespace[:-8]
        return f"http://{service_name}.{namespace}.svc.cluster.local"
