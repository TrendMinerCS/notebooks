import abc
import functools
import posixpath

from requests.exceptions import HTTPError, RequestException

from trendminer.impl.authentication import Authenticated
from trendminer.impl.constants import MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound

from .lazy_loading import LazyAttribute


class TrendMinerFactory(Authenticated, abc.ABC):
    """Superclass for all factories instantiating new methods"""

    _tm_class = None

    # TODO: from_identifier and _from_json should not be part of factory
    def __from_identifier(self, ref):
        
        try:
            endpoint = self._endpoint
            if not endpoint:
                raise ResourceNotFound(
                    ExceptionMessages.ACTION_NOT_COMPLETED_VAR.format(ref)
                )
            link = posixpath.join(endpoint, ref)
            response = self.client.session.get(link)
            response.raise_for_status()
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

        return self._from_json(response.json())

    def get_by_identifier(self, ref):
        
        return self.__from_identifier(ref)

    @property
    def _endpoint(self):
        return self._tm_class._endpoint

    def _from_json(self, data):
        
        raise NotImplementedError

    @property
    def _get_methods(self):
        
        return ()

    @property
    def _search_methods(self):
        
        return ()

    @classmethod
    def _correct_class(cls, ref):
        
        return isinstance(ref, cls._tm_class)

    def get(self, ref):
        

        if ref is None:
            return None

        if isinstance(ref, LazyAttribute):
            return ref

        # Ref is already of correct instance, return
        if self._correct_class(ref):
            return ref

        # Try all other implemented methods to return data
        for method in self._get_methods:
            try:
                return method(ref)
            except (ResourceNotFound, AttributeError):
                pass
            except HTTPError as err:
                if err.response.status_code not in [400, 404]:
                    raise err
        raise ResourceNotFound(f"No match for {ref} found")

    
    def list(self, refs):
        
        if isinstance(refs, LazyAttribute):
            return refs
        if isinstance(refs, (str, tuple)) or self._correct_class(refs):
            refs = [refs]
        refs = refs or []
        return [self.get(ref) for ref in refs]

    

    def _cache_key_ref(self, ref):
        

        # Handling for object inputs
        if isinstance(ref, Authenticated):
            ref = hash(ref)

        key = hash(self.client), ref

        return key

    def _cache_key_no_args(self):
        
        return self._cache_key_ref(ref=None)


def kwargs_to_class(method):
    """Decorator function that handles turning keyword arguments into a TrendMiner class instance
    Intended to decorate methods that convert JSON responses to instances on TrendMiner Factory classes. Creates an instance in which attributes not
    provided through the output dict are turned into LazyAttribute instances. This shortens our code as we no longer
    explicitly need to set our lazy attributes. Also allows the addition of a `list` parameter which will iterate
    the base method to turn a list of inputs into a list of instances. Prevents us from having to use list comprehension
    in our methods.

    Parameters
    ----------
    method : callable
        Method turning json input into a dict of kwargs usable for creating a class instances

    Returns
    -------
    callable
    """

    @functools.wraps(method)
    def inner(*args, **kwargs):
        """Decorator inner function. Creates a class instance or list of class instances."""

        self = args[0]
        try:
            data = args[1]
        except IndexError:
            data = kwargs["data"]

        values = method(self, data)

        output = {
            kw: LazyAttribute(name=kw)
            for kw in self._tm_class.__init__.__code__.co_varnames
        }
        output.pop("self")
        output.update({"client": self.client, **values})
        return self._tm_class(**output)

    return inner


class QuerySearchFactory(TrendMinerFactory, abc.ABC):
    """Factory for objects which can search using sql-style queries"""

    def _query_params(self, params):
        """Execute an sql-style query on the TrendMiner appliance
        Parameters
        ----------
        params : dict
            Request parameters. Needs to contain the sql query under the "query" key.
        Returns
        -------
        list
            List of instances matching the given query.
        """
        params.update({"size": MAX_GET_SIZE})
        endpoint = self._endpoint
        if not endpoint:
            raise ResourceNotFound(ExceptionMessages.ACTION_NOT_COMPLETED)
        content = self.client.session.paginated(keys=["content"]).get(
            endpoint + "search", params=params
        )
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        """Sends sql query where we search for a single given key to match a value
        Parameters
        ----------
        ref : str
            The value to match
        search_key : str
            The key which needs to match this value
        Returns
        -------
        list
            List of instances where the given key matches the given value
        """
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _query_in(self, refs, search_key):
        """Sends sql query where we search for a single given key to be any of a number of given values
        Parameters
        ----------
        refs : list of str
            The list of values the key should match one of
        search_key : str
            The key with which to match the value
        Returns
        -------
        list
            List of instances where the given key matches one of the given values
        """
        queries = ",".join([f"'{ref}'" for ref in refs])
        params = {"query": f"{search_key}=in=({queries})"}
        return self._query_params(params)
