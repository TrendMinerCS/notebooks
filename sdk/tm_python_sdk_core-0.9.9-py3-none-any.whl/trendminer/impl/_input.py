from uuid import UUID

from trendminer.impl.base import LazyAttribute
from trendminer.impl.options.vbs_options import (
    _SEARCH_CALCULATION_OPTIONS_DICT, _VALUE_BASED_SEARCH_OPERATORS_DICT,
    LogicalOperators, ValueBasedSearchOperators)
from trendminer.sdk.asset.asset import AssetIncludeOptions
from trendminer.sdk.context.field import ContextFieldOptions
from trendminer.sdk.context.filter import (ContextDateOperators,
                                           ContextFilterModes,
                                           ContextFilterStatesModes,
                                           ContextOperators)
from trendminer.sdk.search.search import SearchCalculationOptions
from trendminer.sdk.tag.tag import (InterpolationTypeOptions,
                                TagCalculationOptions, TagTypeOptions)

from .exceptions import AmbiguousResource, ResourceNotFound


def any_list(i):
    """Outputs list by converting tuple, or encapsulating object

    Parameters
    ----------
    i : Any
        To be converted into list

    Returns
    -------
    list
    """
    if i is None:
        return []
    if isinstance(i, list):
        return i
    if isinstance(i, tuple):
        return list(i)
    if isinstance(i, set):
        return list(i)
    return [i]


def dict_match_nocase(items, key, value):
    """
    Return dict ojbect of which a given key matches given string value.

    Try case-insensitive match when no sensitive match is found.

    Parameters
    ----------
    items : list
        list of dicts
    key : str
        key present in all dicts in the list
    value : str
        string that should match dict[key] (case insenstive)

    Returns
    -------
    data : dict
        dict of which dict[key] matches value
    """

    results = [item for item in items if item[key].lower() == value.lower()]

    if len(results) == 1:
        data = results[0]

    elif len(results) == 0:
        raise ResourceNotFound(f'No match for {key}=="{value}"')

    else:
        case_sensitive = [item for item in results if item[key] == value]
        if len(case_sensitive) == 1:
            data = results[0]
        else:
            raise AmbiguousResource(
                f'Multiple matches for {key}=="{value}": '
                f'{", ".join([item[key] for item in results])}'
            )

    return data


def object_match_nocase(object_list, attribute, value):
    """
    Return single object from list of which a given attribute matches given value.

    Try case insensitive match when no sensitive match is found.

    Parameters
    ----------
    object_list : list
        list of objects
    attribute : str
        string attribute present in all object in the list
    value : str
        the string that object.attribute should match (ignoring case if no exact match is found)

    Returns
    -------
    object
        object of which object.attribute == value
    """

    results = [
        item
        for item in object_list
        if getattr(item, attribute).lower() == value.lower()
    ]

    if len(results) == 1:
        data = results[0]

    elif len(results) == 0:
        raise ResourceNotFound(f'No match for {attribute}=="{value}"')

    else:
        case_sensitive = [item for item in results if getattr(item, attribute) == value]
        if len(case_sensitive) == 1:
            data = results[0]
        else:
            raise AmbiguousResource(
                f'Multiple matches for {attribute}=="{value}": '
                f'{", ".join([getattr(item, attribute) for item in results])}'
            )

    return data


def case_correct(value, value_options):
    """Correct string case by selecting case-insensitive match from list of strings"""
    if value in value_options:
        return value
    
    if value.isdigit():
        value = int(value)
        if 0 <= value < len(value_options):
            return value_options[value]

    case_in_sensitive = [
        i for i in value_options if (i is not None) and (value.lower() == i.lower())
    ]

    if len(case_in_sensitive) == 1:
        return case_in_sensitive[0]

    if len(case_in_sensitive) == 0:
        raise ResourceNotFound(
            f"No list entry matching {value} in [{', '.join(value_options)}]"
        )

    raise AmbiguousResource(
        f'Multiple case-insensitive list entries matching {value}: {", ".join(case_in_sensitive)}'
    )


def is_uuid(ref):
    """Check if input is valid UUID"""

    try:
        UUID(ref, version=4)
    except (ValueError, AttributeError):
        return False
    return True


def unique_by_attribute(items, attribute):
    """Keep only instances of which a given attribute is unique"""
    seen = set()
    return [
        seen.add(getattr(obj, attribute)) or obj
        for obj in items
        if getattr(obj, attribute) not in seen
    ]


def correct_value(value, value_options):
    """Correct the input value base on a fixed selection of possibilities, given as list or dict. Corrects case and can
    map values (if options are given as a dict). Throws a clear error if input value does not match any option.
    """
    if value is None:
        return value
    if isinstance(value, LazyAttribute):
        return value
    try:
        if isinstance(value_options, list):
            return case_correct(value, value_options)
        elif isinstance(value_options, dict):
            value = case_correct(value, value_options.keys())
            return value_options[value]
        elif issubclass(value_options, ValueBasedSearchOperators):
            # if isinstance(value, str):
                # if value.lower() in _VALUE_BASED_SEARCH_OPERATORS_DICT:
                #     return _VALUE_BASED_SEARCH_OPERATORS_DICT[value.lower()].value
            # return ValueBasedSearchOperators[value]
            return value.value
        elif issubclass(value_options, SearchCalculationOptions):
            # if isinstance(value, str):
            #     if value.lower() in _SEARCH_CALCULATION_OPTIONS_DICT:
            #         return _SEARCH_CALCULATION_OPTIONS_DICT[value.lower()].value
            #     return SearchCalculationOptions[value.upper()].value
            return value.value
        elif issubclass(value_options, TagTypeOptions):
            # if isinstance(value, str):
            #     return TagTypeOptions[value.upper()].value
            return value.value
        elif issubclass(value_options, TagCalculationOptions):
            return value.value
        elif issubclass(value_options, InterpolationTypeOptions):
            # if isinstance(value, str):
            #     return InterpolationTypeOptions[value.upper().replace("-", "_")].value
            return value.value
        elif issubclass(value_options, AssetIncludeOptions):
            # if isinstance(value, str):
            #     return AssetIncludeOptions[value.upper()].value
            return value.value
        elif issubclass(value_options, LogicalOperators):
            # if isinstance(value, str):
            #     return LogicalOperators[value.upper()].value
            return value.value
        elif issubclass(value_options, ContextOperators):
            # if isinstance(value, str):
            #     if value.lower() in _VALUE_BASED_SEARCH_OPERATORS_DICT:
            #         return _VALUE_BASED_SEARCH_OPERATORS_DICT[value.lower()].value
            #     return ContextOperators[value]
            return value.value
        elif issubclass(value_options, ContextFilterModes):
            return value.value
        elif issubclass(value_options, ContextFilterStatesModes):
            return value.value
        elif issubclass(value_options, ContextFieldOptions):
            return value.value
        elif issubclass(value_options, ContextDateOperators):
            return value.value
        else:  # pragma: no cover
            raise TypeError
    except ResourceNotFound:
        if isinstance(value_options, dict):
            main_options = set(value_options.values())
            alternative_options = [
                v for v in value_options.keys() if v not in main_options
            ]
            error_str = f"""
            No list entry matching '{value}'
                Options: [{', '.join(main_options)}]
                Alternative options: [{', '.join(alternative_options)}]
            """
        else:
            error_str = (
                f"'{value}' is not a valid member of: {', '.join(value_options)}"
            )
        raise ValueError(error_str)
    except KeyError:
        if isinstance(value, (list, dict)):
            error_str = f"'{value}' is not a valid member of: {str(value_options)}: Supported Enum members {', '.join(value_options)} "
        else:
            error_str = f"'{value}' is not a valid member of {str(value_options)}: Supported Enum members {', '.join(value_options.__dict__['_member_names_'])}"
        raise ValueError(error_str)
    except AttributeError:
        error_str = f"'{value}' is not a valid member of {str(value_options)}: Supported Enum members {', '.join(value_options.__dict__['_member_names_'])}"
        raise ValueError(error_str)



def options(value_options):
    """Method decorator for checking/correcting input values using the correct_value function"""

    def fun(f):
        def wrapper(self, value):
            return f(self, correct_value(value, value_options))

        return wrapper

    return fun

def filter_assets(value_options : list[dict], permission : str = None) -> list[dict]:
    """Filter the assset/attribute dictionary based on permissions provided to the user
    Parameters
    ----------
    value_options : list[dict]
        list of asset/attribute response dictionary
    permission : str,optional
        filter propert for specific permission

    Returns
    -------
    nodes : list[dict]
        list of dictionary with valid permission
    """
    nodes = []
    if permission is not None:
        for node in value_options:
            if 'permissions' in node and permission in node['permissions']:
                nodes.append(node)
    else:
        for node in value_options:
             if 'permissions' in node and  "ASSET_NO_PERMISSIONS" not in node['permissions']:
                nodes.append(node)
    return nodes

