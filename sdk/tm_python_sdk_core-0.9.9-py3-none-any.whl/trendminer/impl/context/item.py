from collections.abc import MutableMapping

from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.asset import AssetImpl, AttributeImpl
from trendminer.impl.base import ByFactory, Savable, TrendMinerFactory
from trendminer.impl.component_factory import ComponentFactory
from trendminer.impl.constants import MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _context_service
from trendminer.impl.tag import TagImpl
from trendminer.impl.user import UserFactory
from trendminer.sdk.context import ContextItem, ContextItemAPI

from .event import EventFactory
from .field import ContextField
from .type import ContextTypeFactory

# from .attachment import AttachmentFactory


search_field_keys = ["tm_monitor_id", "tm_search_id", "tm_search_type"]


class ContextItemImpl(Savable, MutableMapping, ContextItem):
    # endpoint = "context/item/"

    created_by = ByFactory(UserFactory)
    context_type = ByFactory(ContextTypeFactory)
    components = ByFactory(ComponentFactory, "list")

    def __init__(
        self,
        client,
        key,
        context_type,
        components,
        events,
        description,
        fields = None,
        identifier = None,
        created_by = None,
        search_fields = None,
        sync_time = None,
    ):
        components = self.__filter_components(components)
        Savable.__init__(self, client=client, identifier=identifier)
        ContextItem.__init__(self, identifier=identifier, context_type=context_type, 
        key=key, components = components, fields=fields,
        description = description, created_by = created_by, search_fields = search_fields,
        sync_time = sync_time)
        self.sync_time = sync_time
        self.context_type = context_type
        self.components = components
        self.events = events
        self.fields = fields
        # self.keywords = keywords
        self.description = description or ""
        self.identifier = identifier
        self.key = key
        self.created_by = created_by
        self.search_fields = search_fields or {}

    @property
    def events(self):
        return self._events

    @events.setter
    def events(self, events):
        # Setting events requires knowledge of the workflow
        self._events = EventFactory(
            client=self.client, workflow=self.context_type.workflow
        ).list(events)

    @property
    def fields(self):
        return self._fields

    @fields.setter
    def fields(self, fields):
        fields = fields or {}
        fields = {
            field.key if isinstance(field, ContextField) else field: value
            for field, value in fields.items()
        }
        self._fields = fields

    # @property
    # def keywords(self):
    #     """Keywords attached to the item

    #     Keywords in TrendMiner are always lowercase.

    #     Returns
    #     -------
    #     keywords : list of str
    #         List of keywords attached to the context item
    #     """
    #     return self._keywords

    # @keywords.setter
    # def keywords(self, keywords):
    #     self._keywords = [kw.lower() for kw in ip.any_list(keywords)]

    @property
    def interval(self):
        if not self.events:
            return None

        start_event = self.events[0]
        end_event = self.events[-1]

        if self.context_type.workflow is not None:
            is_open = end_event.state != self.context_type.workflow.states[-1]
        else:
            is_open = False

        if is_open:
            end_time = self.sync_time or self.client.time.now()
        else:
            end_time = end_event.timestamp

        return self.client.time.interval(
            start_event.timestamp, end_time, data=self.fields, is_open=is_open
        )
    
    def __filter_components(self, components):
        filtered_components = []
        for component in components:
            if isinstance(component , AssetImpl):
                filtered_components.append(component.identifier)
            elif isinstance(component , AttributeImpl):
                filtered_components.append(component.identifier)
            else:
                filtered_components.append(component)
        return filtered_components

    def __json__(self):
        # ignore None values as they throw errors
        fields = {
            **self.search_fields,
            **{key: value for key, value in self.fields.items() if value is not None},
        }
        return {
            "identifier": self.identifier,
            "description": self.description,
            # "keywords": self.keywords,
            "type": self.context_type,
            "components": [
                component._json_component() for component in self.components
            ],
            "fields": fields,  # {**self.fields, **self.search_fields},
            "events": self.events,
        }

    def _post_updates(self, response):
        self.key = response.json()["shortKey"]
        self.identifier = response.json()["identifier"]
        self.created_by = UserFactory(client=self.client)._from_json_limited(
            response.json()["userDetails"]
        )
        self.events = [
            EventFactory(
                client=self.client, workflow=self.context_type.workflow
            )._from_json(event)
            for event in response.json()["events"]
        ]

    def _put_updates(self, response):
        self._sync_time = self.client.time.now()

    def approve(self):
        """Add user approval to this context item"""
        try:
            # response = self.client.session.post(f"/context/data/{self.identifier}/approval")
            response = _context_service(self.client).approve_context_item(
                self.identifier
            )
            response.raise_for_status()
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def remove_approval(self):
        try:
            # response = self.client.session.delete(f"/context/data/{self.identifier}/approval")
            response = _context_service(self.client).revoke_approval(self.identifier)
            response.raise_for_status()
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def history(self):
        params = {"size": MAX_GET_SIZE, "sort": "desc"}
        try:
            # response = self.client.session.get(f"/context/history/{self.identifier}", params=params)
            response = _context_service(self.client).get_audit_trail(
                self.identifier, **params
            )
            response.raise_for_status()
            return response.json().get('content', [])
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(self.identifier)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    # @property
    # def attachments(self):
    #     """Context item attachment facotry"""
    #     return AttachmentFactory(parent=self)

    # def delete(self):
    #     """Remove this instance from the appliance"""
    #     try:
    #         response = _context_service(self.client).delete_context_item(
    #             self.identifier
    #         )
    #         response.raise_for_status()
    #         # return response
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(
    #                 ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
    #             ) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    # def post(self):
    #     """Creates this instance on the TrendMiner appliance"""
    #     self.__json__()  # asserts object is no longer lazy
    #     self.identifier = None  # reset identifier to avoid overwriting
    #     try:
    #         response = _context_service(self.client).create_context_item(self)
    #         response.raise_for_status()
    #         self._post_updates(response)
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    # def put(self):
    #     """Updates the appliance object to match this instance"""
    #     try:
    #         response = _context_service(self.client).update_context_item(
    #             self, self.identifier
    #         )
    #         response.raise_for_status()
    #         self._put_updates(response)
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(
    #                 ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
    #             ) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    #Should not be added as part of abstract layer
    @property
    def blueprint(self):
        return {
            "context_type": self.context_type.key,
            "components": [
                c.name if isinstance(c, TagImpl) else c.path for c in self.components
            ],
            "events": self.events,
            "fields": self.fields,
            # "keywords": self.keywords,
            "description": self.description,
        }

    def __repr__(self):
        if self.interval is not None:
            return f"<< ContextItem | {self.context_type.key} | {self.interval.duration} >>"
        return f"<< ContextItem | {self.context_type.key} >>"

    def __getitem__(self, item):
        return self.fields.__getitem__(item)

    def __setitem__(self, key, value):
        self.fields.__setitem__(key, value)

    def __delitem__(self, key):
        self.fields.__delitem__(key)

    def __iter__(self):
        return self.fields.__iter__()

    def __len__(self):
        return self.fields.__len__()


class ContextItemFactory(TrendMinerFactory, ContextItemAPI):

    _tm_class = ContextItemImpl

    def __call__(
        self,
        context_type,
        components,
        events=None,
        description="",
        fields=None,
        # keywords=None,
    ):
        return self._tm_class(
            client=self.client,
            identifier=None,
            key=None,
            context_type=context_type,
            components=components,
            events=events,
            description=description,
            fields=fields,
            #  keywords=keywords,
            created_by=None,
            search_fields=None,
            sync_time=None,
        )

    # def bulk_post(self, items, per=MAX_POST_SIZE):
    #     """Post multiple context items to the appliance at once

    #     Creating multiple items at once in one (large) POST request is much more efficient than creating items
    #     individually in a loop. We can thus initialize all items we want to create, and then create them in one go
    #     using this method.

    #     Parameters
    #     ----------
    #     items : list of ContextItem
    #         The context items that we want to post to the appliance
    #     per : int, optional
    #         How many items we want to create in one go. An appropriate default value is selected, but this parameter
    #         allows customization for when requests time out on slow setups.
    #     """
    #     payloads = [item.__json__() for item in self.list(items)]
    #     for i in range(0, len(items), per):
    #         self.client.session.post("/context/item/batch", json=payloads[i:i+per])

    def _from_json(self, data):
        fields = data["fields"]

        search_fields = {}
        for key in search_field_keys:
            if key in fields:
                search_fields.update({key: fields.pop(key)})

        if "userDetails" in data:
            user = UserFactory(client=self.client)._from_json_limited(
                data["userDetails"]
            )
        else:
            user = None  # Deleted user

        context_type = ContextTypeFactory(client=self.client)._from_json(data["type"])

        events = [
            EventFactory(client=self.client, workflow=context_type.workflow)._from_json(
                event
            )
            for event in data["events"]
        ]

        return self._tm_class(
            client=self.client,
            identifier=data["identifier"],
            key=data["shortKey"],
            context_type=context_type,
            components=[
                ComponentFactory(client=self.client)._from_json_context_item(component)
                for component in data["components"]
            ],
            events=events,
            fields=fields,
            # keywords=data["keywords"],
            description=data.get("description"),
            created_by=user,
            search_fields=search_fields,
            sync_time=self.client.time.now(),
        )

    def _from_json_monitor(self, data):
        return self._tm_class(
            client=self.client,
            identifier=None,
            key=None,
            context_type=data["type"],
            components=[data["componentReference"]],
            events=None,
            fields=data["fields"],
            # keywords=data["keywords"],
            description=data.get("description"),
            created_by=None,
            search_fields={},
            sync_time=None,
        )

    def get_by_identifier(self, ref):
        if not ip.is_uuid(ref):  # saves us a request when using a name as ref
            raise ResourceNotFound(ExceptionMessages.INVALID_UUID.format(ref))
        try:
            response = _context_service(self.client).get_context_item(ref)
            response.raise_for_status()
            respone_json = self._from_json(response.json())
            return respone_json
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    @property
    def _get_methods(self):
        return (self.get_by_identifier,)
