from .gantt import gantt_settings_dummy
from .grid import grid_settings_dummy
from .scatter import scatter_settings_dummy
