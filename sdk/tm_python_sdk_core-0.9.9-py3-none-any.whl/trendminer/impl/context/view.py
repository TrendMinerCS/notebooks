from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.base import ByFactory, HasOptions, kwargs_to_class
from trendminer.impl.constants import (CONTEXT_VIEW_OPTIONS,
                                       MAX_CONTEXT_ITEM_GET_SIZE,
                                       SERVICE_NAMES)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _context_service, set_default_url
from trendminer.impl.times import time_json
from trendminer.impl.work import WorkOrganizerFactory, WorkOrganizerObject
from trendminer.sdk.context import ContextHubView, ContextHubViewAPI

from .filter import ContextFilterFactory
from .view_configuration import (gantt_settings_dummy, grid_settings_dummy,
                                 scatter_settings_dummy)


class ContextHubViewImpl(WorkOrganizerObject, ContextHubView):

    content_type = "CONTEXT_LOGBOOK_VIEW"
    filters = ByFactory(ContextFilterFactory, "list")
    view_type = HasOptions(CONTEXT_VIEW_OPTIONS)
    _service_name = SERVICE_NAMES["context"]

    def __init__(
        self,
        client,
        name,
        description,
        folder,
        view_type,
        identifier = None,
        owner = None,
        last_modified = None,
        filters = None,
        grid_settings = None,
        gantt_settings =  None,
        scatter_settings = None,
    ):
        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )
        ContextHubView.__init__(self, name = name,
                                description=description,
                                folder=folder,
                                view_type=view_type,
                                identifier=identifier,
                                owner=owner,
                                last_modified=last_modified,
                                filters = filters,
                                grid_settings = grid_settings,
                                gantt_settings = gantt_settings,
                                scatter_settings=scatter_settings)

    def _full_instance(self):
        return self.client.context.view.get_by_identifier(self.identifier)

    def _json_search(self):
        return {
            "filters": self.filters,
            "sortProperties": ["startEventDate"],
            "sortDirection": "asc",
            "fetchSize": MAX_CONTEXT_ITEM_GET_SIZE,
        }

    def _json_delete(self):
        return {
            **self._json_search(),
            "createdBefore": time_json(self.client.time.now()),
        }

    def _json_data(self):
        return {
            "gridSettings": self.grid_settings,
            "ganttSettings": self.gantt_settings,
            "scatterSettings": self.scatter_settings,
            "viewType": self.view_type,
            **self._json_search(),
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def search_items(self):
        self.client = set_default_url(self.client, self._service_name)
        content = self.client.session.continuation(keys=["content"]).post(
            url="/context/v2/item/search",
            json=self._json_search(),
        )

        return [self.client.context.item._from_json(item) for item in content]
    
    def __repr__(self):
        return "<< ContextHubView >>"

    # def delete_items(self):
    #     """Delete all context items matching the view filters"""
    #     self.client.session.delete(
    #         "/context/item/batch/filters", json=self._json_delete()
    #     )


class ContextHubViewFactory(WorkOrganizerFactory, ContextHubViewAPI):

    _tm_class = ContextHubViewImpl

    def __call__(
        self,
        filters,
        name="New View",
        description="",
        folder=None,
        view_type="grid",
    ) -> ContextHubView:
        return self._tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            filters=filters,
            view_type=view_type,
            grid_settings=grid_settings_dummy,
            scatter_settings=scatter_settings_dummy,
            gantt_settings=gantt_settings_dummy,
        )

    # def __from_identifier(self, ref):
    #     link = posixpath.join("/context/view", ref, "enriched")
    #     response = self.client.session.get(link)
    #     return self._from_json(response.json())

    def get_by_identifier(self, ref) -> ContextHubView:
        if not ip.is_uuid(ref):
            raise ResourceNotFound(ExceptionMessages.INVALID_UUID.format(ref))
        try:
            response = _context_service(self.client).enrich_view(ref)
            response.raise_for_status()
            respone_json = self._from_json(response.json())
            return respone_json
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "filters": [
                ContextFilterFactory(client=self.client)._from_json(cfilter)
                for cfilter in data["data"]["filters"]
            ],
            "view_type": data["data"]["viewType"],
            "grid_settings": data["data"]["gridSettings"],
            "scatter_settings": data["data"]["scatterSettings"],
            "gantt_settings": data["data"]["ganttSettings"],
        }
