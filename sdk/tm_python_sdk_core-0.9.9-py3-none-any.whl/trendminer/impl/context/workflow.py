import json

from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.base import QuerySearchFactory, Savable
from trendminer.impl.constants import DEFAULT_ENCODING, MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _context_service
from trendminer.sdk.context import ContextWorkflow, ContextWorkflowAPI


class ContextWorkflowImpl(ContextWorkflow, Savable):

    # endpoint = "context/workflow/"

    def __init__(self, client, identifier, name, states):
        Savable.__init__(self, client=client, identifier=identifier)
        ContextWorkflow.__init__(self, identifier = identifier, name = name, states =states)
        self.name = name
        self.states = states

    def __json__(self):
        return {
            "identifier": self.identifier,
            "name": self.name,
            "states": self.states,
            "startState": self.states[0],
            "endState": self.states[-1],
        }

    # def delete(self):
    #     """Remove this instance from the appliance"""
    #     try:
    #         response = _context_service(self.client).delete_workflow(self.identifier)
    #         response.raise_for_status()
    #         # return response
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    @property
    def blueprint(self):
        return {
            "name": self.name,
            "states": self.states,
        }

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"<< ContextWorkflow | {self.name} >>"


class ContextWorkflowFactory(QuerySearchFactory, ContextWorkflowAPI):

    _tm_class = ContextWorkflowImpl

    def __call__(self, name, states, start_state=None, end_state=None) -> ContextWorkflow:
        return self._tm_class(
            client=self.client,
            identifier=None,
            name=name,
            states=states,
        )

    def __by_name(self, ref):
        return self._query_search(ref=ref, search_key="name")

    def __from_name(self, ref):
        return ip.object_match_nocase(self.__by_name(ref), attribute="name", value=ref)

    def get_by_name(self, ref):
        return self.__from_name(ref)

    def _from_json(self, data):
        # make sure start and end states are in the correct order
        states = data["states"]
        start_state = data["startState"]
        end_state = data["endState"]
        states = (
            [start_state]
            + [state for state in states if state not in [start_state, end_state]]
            + [end_state]
        )

        return self._tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            states=states,
        )

    def get_by_identifier(self, ref) -> ContextWorkflow:
        if not ip.is_uuid(ref):  # saves us a request when using a name as ref
            raise ResourceNotFound(ExceptionMessages.INVALID_UUID.format(ref))
        try:
            response = _context_service(self.client).get_workflow(ref)
            response.raise_for_status()
            respone_json = self._from_json(response.json())
            return respone_json
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    @property
    def _search_methods(self):
        return (self.__by_name,)

    @property
    def _get_methods(self):
        return self.get_by_identifier, self.get_by_name

    def _query_params(self, params):
        params.update({"size": MAX_GET_SIZE})
        # content = self.client.session.paginated(keys=["content"]).get("context/fields/" + "search", params=params)
        # return [self._from_json(data) for data in content]
        method = _context_service(self.client).search_workflow
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def all(self):
        params = {"size": MAX_GET_SIZE}
        method = _context_service(self.client).get_all_workflows
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

        # content = self.client.session.paginated(keys=["content"]).get(self._endpoint, params=params)

    def search(self, *args, **kwargs):
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        results = []
        get_ids = lambda obj: obj.identifier
        search_counter = -1
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    search_counter += 1
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    #For the first iteration skip the comparision of common identifiers
                    if search_counter == 0:
                        results.extend(data)
                        continue
                    data_ids = list(map(get_ids, data))
                    result_ids = list(map(get_ids, results))
                    common_ids = set(data_ids).intersection(result_ids)
                    #Only add the items with matching identifiers
                    results = [obj for obj in data if obj.identifier in common_ids]
        return results

    def _extract_content(self, keys, data):
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = []
            response = method(**kwargs["params"])
            response.raise_for_status()
            total_pages = self._prepare_response(response)["page"]["totalPages"]
            responses.append(response)
            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
