import json

from requests.exceptions import RequestException

import trendminer.impl._input as ip
from trendminer.impl.base import (ByFactory, LazyLoadingClass,
                                  QuerySearchFactory, Savable, kwargs_to_class)
from trendminer.impl.constants import DEFAULT_ENCODING, MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _context_service
from trendminer.impl.visuals.color import ColoredObject
from trendminer.sdk.context import ContextType, ContextTypeAPI

from .field import ContextFieldFactory
from .workflow import ContextWorkflowFactory


class ContextTypeImpl(Savable, LazyLoadingClass, ColoredObject, ContextType):

    # endpoint = "context/type/"
    workflow = ByFactory(ContextWorkflowFactory)
    fields = ByFactory(ContextFieldFactory, "list")

    def __init__(
        self,
        client,
        key,
        name,
        workflow,
        fields,
        icon,
        color,
        approvals_enabled,
        audit_trail_enabled,
    ):
        Savable.__init__(self, client=client, identifier=key)
        ColoredObject.__init__(self, color=color)
        ContextType.__init__(self, key, name, workflow,
        fields, icon, color, approvals_enabled, audit_trail_enabled)
        self.key = key
        self.name = name
        self.workflow = workflow
        self.fields = fields
        self.icon = icon  # TODO: give options and add to documentation
        self.approvals_enabled = approvals_enabled
        self.audit_trail_enabled = audit_trail_enabled

    def _full_instance(self):
        return self.client.context.type.get_by_key(self.key)

    def __json__(self):
        payload = {
            "identifier": self.key,
            "name": self.name,
            "fields": self.fields,
            "icon": self.icon,
            "color": self._api_color_ch,
            "approvalsEnabled": self.approvals_enabled,
            "auditTrailEnabled": self.audit_trail_enabled,
        }

        if self.workflow is not None:
            payload.update({"workflow": self.workflow})

        return payload

    #Property should not be documented and not part of abstract layer
    @property
    def blueprint(self):
        return {
            "key": self.key,
            "workflow": self.workflow.name if self.workflow is not None else None,
            "fields": [field.key for field in self.fields],
            "name": self.name,
            "color": self.color.get_hex(),
            "icon": self.icon,
            "approvals_enabled": self.approvals_enabled,
            "audit_trail_enabled": self.audit_trail_enabled,
        }

    # def delete(self):
    #     """Remove this instance from the appliance"""
    #     try:
    #         response = _context_service(self.client).delete_context_data_type(
    #             self.identifier
    #         )
    #         response.raise_for_status()
    #         # return response
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(
    #                 ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
    #             ) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    # def _put_updates(self, response):
    #     """Update some instance attributes from a put response"""

    # def _post_updates(self, response):
    #     """Update instance attributes from a post response"""
    #     self.identifier = response.json()["identifier"]

    # def post(self):
    #     """Creates this instance on the TrendMiner appliance"""
    #     self.__json__()  # asserts object is no longer lazy
    #     self.identifier = None  # reset identifier to avoid overwriting
    #     try:
    #         response = _context_service(self.client).create_context_data_type(self)
    #         response.raise_for_status()
    #         self._post_updates(response)
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    # def put(self):
    #     """Updates the appliance object to match this instance"""
    #     try:
    #         response = _context_service(self.client).update_context_data_type(
    #             self, self.identifier
    #         )
    #         response.raise_for_status()
    #         self._put_updates(response)
    #     except RequestException as excp:
    #         excp.args = (f"Status: {excp.response.status_code}"), (
    #             (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
    #         )
    #         if excp.response.status_code in [400, 404]:
    #             raise ResourceNotFound(
    #                 ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(self.identifier)
    #             ) from excp
    #         if excp.response.status_code == 403:
    #             raise ResourceNotFound(ExceptionMessages.ACTION_NOT_PERMITTED) from excp
    #         if excp.response.status_code == 401:
    #             raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
    #         raise excp

    def __str__(self):
        return self.key

    def __repr__(self):
        return f"<< ContextType | {self._repr_lazy('key')} >>"


class ContextTypeFactory(QuerySearchFactory, ContextTypeAPI):

    _tm_class = ContextTypeImpl

    def __call__(
        self,
        key,
        name,
        workflow=None,
        fields=None,
        icon="information",
        color=None,
        approvals_enabled=False,
        audit_trail_enabled=False,
    ) -> ContextType:
        return self._tm_class(
            client=self.client,
            key=key,
            name=name,
            workflow=workflow,
            fields=fields,
            icon=icon,
            color=color,
            approvals_enabled=approvals_enabled,
            audit_trail_enabled=audit_trail_enabled,
        )

    def __from_key(self, ref):
        return self.get_by_identifier(ref)

    def get_by_identifier(self, ref : str) -> ContextType:
        try:
            response = _context_service(self.client).get_context_data_type(ref)
            response.raise_for_status()
            respone_json = self._from_json(response.json())
            return respone_json
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def get_by_key(self, ref : str) -> ContextType:
        return self.__from_key(ref)

    def __from_name(self, ref):
        return ip.object_match_nocase(self.__by_name(ref), attribute="name", value=ref)

    def get_by_name(self, ref : str) -> ContextType:
        return self.__from_name(ref)

    def __by_name(self, ref):
        return self._query_search(ref=ref, search_key="name")

    def __by_key(self, ref):
        return self._query_search(ref=ref, search_key="identifier")

    def search(self, *args, **kwargs):
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        results = []
        get_ids = lambda obj: obj.identifier
        search_counter = -1
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    search_counter += 1
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    #For the first iteration skip the comparision of common identifiers
                    if search_counter == 0:
                        results.extend(data)
                        continue
                    data_ids = list(map(get_ids, data))
                    result_ids = list(map(get_ids, results))
                    common_ids = set(data_ids).intersection(result_ids)
                    #Only add the items with matching identifiers
                    results = [obj for obj in data if obj.identifier in common_ids]
        return results

    def _json_to_kwargs_base(self, data):
        return {
            "key": data["identifier"],
            "name": data["name"],
            "color": "#" + data["color"],
            "icon": data["icon"],
            "approvals_enabled": data["approvalsEnabled"],
            "audit_trail_enabled": data["auditTrailEnabled"],
        }

    @kwargs_to_class
    def _from_json(self, data):
        workflow = data.get("workflow")
        if workflow:
            workflow = ContextWorkflowFactory(client=self.client)._from_json(workflow)

        return {
            **self._json_to_kwargs_base(data),
            "workflow": workflow,
            "fields": [
                ContextFieldFactory(client=self.client)._from_json(field)
                for field in data["fields"]
            ],
        }

    @kwargs_to_class
    def _from_json_context_filter(self, data):
        return self._json_to_kwargs_base(data)

    @property
    def _get_methods(self):
        return self.get_by_key, self.get_by_name

    @property
    def _search_methods(self):
        return (
            self.__by_key,
            self.__by_name,
        )

    def _query_params(self, params):
        params.update({"size": MAX_GET_SIZE})
        # content = self.client.session.paginated(keys=["content"]).get("context/fields/" + "search", params=params)
        # return [self._from_json(data) for data in content]
        method = _context_service(self.client).search_context_data_type
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = []
            response = method(**kwargs["params"])
            response.raise_for_status()
            total_pages = self._prepare_response(response)["page"]["totalPages"]
            responses.append(response)

            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
