import json

from requests.exceptions import RequestException

from trendminer.impl import _input as ip
from trendminer.impl.base import HasOptions, QuerySearchFactory, Savable
from trendminer.impl.constants import DEFAULT_ENCODING, MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.options.context_options import _CONTEXT_FIELD_OPTIONS
from trendminer.impl.services.services import _context_service
from trendminer.sdk.context import (ContextField, ContextFieldAPI,
                                    ContextFieldOptions)


class ContextFieldImpl(ContextField, Savable):
    # endpoint = "context/fields/"
    field_type = HasOptions(ContextFieldOptions)

    def __init__(self, client, identifier, field_type:ContextFieldOptions, name, key, placeholder, options):
        Savable.__init__(self, client, identifier=identifier)
        ContextField.__init__(self, name=name, identifier=identifier, key=key, field_type=field_type, placeholder=placeholder, options=options)
        self.name = name
        self.key = key
        self.field_type = field_type
        self.placeholder = placeholder
        self.options = options

    @property
    def options(self):
        return self._options

    @options.setter
    def options(self, options):
        options = options or []
        if not (self.field_type == "ENUMERATION") and options != []:
            raise ValueError(
                f"Context field of type {self.field_type} does not accept options"
            )
        self._options = [str(i) for i in options]

    # @property
    # def blueprint(self):
    #     return {
    #         "key": self.key,
    #         "name": self.name,
    #         "field_type": self.field_type,
    #         "placeholder": self.placeholder,
    #         "options": self.options,
    #     }

    def __json__(self):
        """post/put request payload for saving context field"""
        payload = {
            "identifier": self.identifier,
            "propertyKey": self.key,
            "name": self.name,
            "type": self.field_type,
            "placeholder": self.placeholder,
        }
        if self.field_type == "ENUMERATION":
            payload.update({"options": self.options})
        return payload

    def __str__(self):
        return self.key

    def __repr__(self):
        return f"<< ContextField | {self.key} >>"


class ContextFieldFactory(QuerySearchFactory, ContextFieldAPI):

    _tm_class = ContextFieldImpl

    def __call__(self, key, name, field_type=ContextFieldOptions.STRING, placeholder="", options=None) -> ContextField:
        return self._tm_class(
            client=self.client,
            identifier=None,
            field_type=field_type,
            name=name,
            key=key,
            placeholder=placeholder,
            options=options,
        )

    def _from_json(self, data):
        return self._tm_class(
            client=self.client,
            identifier=data["identifier"],
            field_type=_CONTEXT_FIELD_OPTIONS[data["type"]],
            name=data["name"],
            key=data["propertyKey"],
            placeholder=data.get("placeholder"),
            options=data.get("options"),
        )

    def __from_key(self, ref):
        return ip.object_match_nocase(self.__by_key(ref), attribute="key", value=ref)

    def get_by_key(self, ref : str) -> ContextFieldAPI:
        return self.__from_key(ref)

    def __from_name(self, ref):
        return ip.object_match_nocase(self.__by_name(ref), attribute="name", value=ref)

    def get_by_name(self, ref : str) -> ContextFieldAPI:
        return self.__from_name(ref)

    def __by_key(self, ref):
        return self._query_search(ref=ref, search_key="propertyKey")

    def __by_name(self, ref):
        return self._query_search(ref=ref, search_key="name")

    def all(self):
        params = {"size": MAX_GET_SIZE}
        method = _context_service(self.client).get_all_fields
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

    def get_by_identifier(self, ref : str) -> ContextFieldAPI:
        if not ip.is_uuid(ref):  # saves us a request when using a name as ref
            raise ResourceNotFound(ExceptionMessages.INVALID_UUID.format(ref))
        try:
            response = _context_service(self.client).get_field(ref)
            response.raise_for_status()
            respone_json = self._from_json(response.json())
            return respone_json
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_FOUND_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED_VAR.format(ref)
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp

    def search(self, *args, **kwargs):
        keys = [
            key
            for key in kwargs
            for method in self._search_methods
            if key in method.__name__
        ]
        results = []
        get_ids = lambda obj: obj.identifier
        search_counter = -1
        for method in self._search_methods:
            method_name = method.__name__
            for key, val in kwargs.items():
                if key in method_name:
                    search_counter += 1
                    data = method(
                        val, *args, **{k: v for k, v in kwargs.items() if k not in keys}
                    )
                    #For the first iteration skip the comparision of common identifiers
                    if search_counter == 0:
                        results.extend(data)
                        continue
                    data_ids = list(map(get_ids, data))
                    result_ids = list(map(get_ids, results))
                    common_ids = set(data_ids).intersection(result_ids)
                    #Only add the items with matching identifiers
                    results = [obj for obj in data if obj.identifier in common_ids]
        return results

    @property
    def _get_methods(self):
        return self.get_by_identifier, self.get_by_key, self.get_by_name

    @property
    def _search_methods(self):
        return self.__by_name, self.__by_key

    def _query_params(self, params):
        params.update({"size": MAX_GET_SIZE})
        # content = self.client.session.paginated(keys=["content"]).get("context/fields/" + "search", params=params)
        # return [self._from_json(data) for data in content]
        method = _context_service(self.client).search_field
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = []
            response = method(**kwargs["params"])
            response.raise_for_status()
            total_pages = self._prepare_response(response)["page"]["totalPages"]
            responses.append(response)
            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
