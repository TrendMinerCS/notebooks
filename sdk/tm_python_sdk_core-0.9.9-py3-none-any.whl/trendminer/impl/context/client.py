from trendminer.impl.authentication import Authenticated
from trendminer.sdk.context import (ContextFieldAPI, ContextFilterAPI,
                                    ContextHubViewAPI, ContextItemAPI,
                                    ContextTypeAPI, ContextWorkflowAPI)

from .field import ContextFieldFactory
from .filter import ContextFilterFactory
from .item import ContextItemFactory
from .type import ContextTypeFactory
from .view import ContextHubViewFactory
from .workflow import ContextWorkflowFactory


class ContextFactory(Authenticated):
    """Factory for objects related to ContextHub and context items"""

    @property
    def field(self) -> ContextFieldAPI:
        return ContextFieldFactory(client=self.client)

    @property
    def workflow(self) -> ContextWorkflowAPI:
        return ContextWorkflowFactory(client=self.client)

    @property
    def type(self) -> ContextTypeAPI:
        return ContextTypeFactory(client=self.client)

    @property
    def item(self) -> ContextItemAPI:
        return ContextItemFactory(client=self.client)

    @property
    def view(self) -> ContextHubViewAPI:
        return ContextHubViewFactory(client=self.client)

    @property
    def filter(self) -> ContextFilterAPI:
        return ContextFilterFactory(client=self.client)
