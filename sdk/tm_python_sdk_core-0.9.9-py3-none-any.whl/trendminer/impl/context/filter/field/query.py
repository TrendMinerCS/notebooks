from trendminer.impl.context.filter.base import (ContextQuery,
                                                 ContextQueryFactory)
from trendminer.sdk.context import NumericQuery


class NumericQueryImpl(ContextQuery, NumericQuery):

    def __init__(self, client, operator, value):
        ContextQuery.__init__(self, client=client, operator=operator, value=value)
        NumericQuery.__init__(self, operator=operator, value=value)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = float(value)

    def __json__(self):
        operator = self.operator if self.operator else self.operator_str
        return {
            "operator": operator,
            "value": self.value,
        }


class NumericQueryFactory(ContextQueryFactory):
    _tm_class = NumericQueryImpl
