import abc

from trendminer.impl.base import ByFactory
from trendminer.impl.context.field import ContextFieldFactory
from trendminer.impl.context.filter.base import ContextFilterWithMode


class FieldFilter(ContextFilterWithMode, abc.ABC):
    """Superclass for filtering on a context field

    Attributes
    ----------
    field : ContextField
        The context field on which to filter
    """

    field = ByFactory(ContextFieldFactory)

    def __init__(self, client, field, mode):
        super().__init__(client=client, mode=mode)
        self.field = field
