from trendminer.impl import _input as ip
from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import HasOptions
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import _CONTEXT_FILTER_MODES_EMPTY
from trendminer.sdk.context import ContextFilterModes, StringFieldFilter

from .base import FieldFilter


class StringFieldFilterImpl(FieldFilter, StringFieldFilter):

    filter_type = "STRING_FIELD_FILTER"
    mode = HasOptions(ContextFilterModes)

    def __init__(self, client, field, values, mode = None):
        super().__init__(client=client, field=field, mode=mode)
        if mode is not None:
            if values is not None:
                raise ActionProhibitedError(ExceptionMessages.DESCRIPTION_FIELD_VALIDATION_FAILED)
            values = None
        self.values = values

    @property
    def values(self):
        return self._values

    @values.setter
    def values(self, values):
        if values is None:
            self._values = None
        else:
            self._values = ip.any_list(values)

    def __json__(self):
        return {
            **super().__json__(),
            "field": self.field.key,
            "fieldIdentifier": self.field.identifier,
            "values": self.values if self.values else None,  # empty list gives error
        }
    
    def __repr__(self):
        return "<< StringFieldFilter >>"


class StringFieldFilterFactory(Authenticated):
    _tm_class = StringFieldFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_EMPTY[mode]
            return self._tm_class(
                client=self.client,
                field=data.get("field", data.get("customField")),
                values=None,
                mode=_mode,
            )
        return self._tm_class(
            client=self.client,
            field=data.get("field", data.get("customField")),
            values=data.get("values"),
            mode=None,
        )

    def __call__(self, field, values=None, mode=None) -> StringFieldFilter:
        return self._tm_class(client=self.client, field=field, values=values, mode=mode)
