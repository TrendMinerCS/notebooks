from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory, HasOptions
from trendminer.impl.context.filter.base import (_validate_conditions,
                                                 interpret_query)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import (
    _CONTEXT_FILTER_MODES_EMPTY, _CONTEXT_OPERATORS)
from trendminer.sdk.context import (ContextFilterModes, ContextOperators,
                                    NumericFieldFilter)
from trendminer.sdk.context.filter import ContextFilterModes, ContextOperators

from .base import FieldFilter
from .query import NumericQueryFactory


class NumericFieldFilterImpl(FieldFilter, NumericFieldFilter):
    filter_type = "NUMERIC_FIELD_FILTER"
    mode = HasOptions(ContextFilterModes)
    values = ByFactory(NumericQueryFactory, "list")

    def __init__(self, client, field, values, mode = None):
        FieldFilter.__init__(self, client=client, field=field, mode=mode)
        NumericFieldFilter.__init__(self, field=field, values=values, mode=mode)
        if mode is not None:
            if values is not None:
                raise ActionProhibitedError(ExceptionMessages.DESCRIPTION_FIELD_VALIDATION_FAILED)
            self.values = None
        else:
            _validate_conditions(values, ContextOperators)
            self.values = values

    def __json__(self):
        return {
            **super().__json__(),
            "field": self.field.key,
            "fieldIdentifier": self.field.identifier,
            "conditions": (
                self.values if self.values else None
            ),  # empty list gives error
        }
    
    def __repr__(self):
        return "<< NumericFieldFilter >>"


class NumericFieldFilterFactory(Authenticated):

    _tm_class = NumericFieldFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_EMPTY[mode]
            return self._tm_class(
                client=self.client,
                field=data.get("field", data.get("customField")),
                values=None,
                mode=_mode,
            )
        conditions=data["conditions"]
        for condition in conditions:
            parameter, operator, value = interpret_query(condition)
            if 'operator' in condition:
                condition['operator'] = _CONTEXT_OPERATORS[operator]
        return self._tm_class(
            client=self.client,
            field=data.get("field", data.get("customField")),
            values=conditions,
            mode=None
        )

    def __call__(self, field, values=None, mode=None) -> NumericFieldFilter:
        return self._tm_class(client=self.client, field=field, values=values, mode=mode)
