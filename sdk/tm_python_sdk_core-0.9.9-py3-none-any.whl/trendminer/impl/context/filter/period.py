from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base.filter import ContextFilter
from trendminer.impl.times import PeriodFactory
from trendminer.sdk.context import PeriodFilter


class PeriodFilterImpl(ContextFilter, PeriodFilter):
    filter_type = "PERIOD_FILTER"
    period = ByFactory(PeriodFactory, "__call__")

    def __init__(self, client, period, live):
        ContextFilter.__init__(self, client=client)
        PeriodFilter.__init__(self, period=period, live=live)
        self.period = period
        self.live = live

    def __json__(self):
        return {
            "live": self.live,
            "type": self.filter_type,
            **self.period.__json__(),
        }
    
    def __repr__(self):
        return "<< PeriodFilter >>"


class PeriodFilterFactory(Authenticated):

    _tm_class = PeriodFilterImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client, period=data["period"], live=data["live"]
        )

    def __call__(self, period="8h", live=False) -> PeriodFilter:
        return self._tm_class(client=self.client, period=period, live=live)
