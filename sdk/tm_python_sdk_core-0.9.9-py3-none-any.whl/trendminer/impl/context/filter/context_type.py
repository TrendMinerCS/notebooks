from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base.filter import ContextFilter
from trendminer.impl.context.type import ContextTypeFactory
from trendminer.sdk.context import TypeFilter


class TypeFilterImpl(ContextFilter, TypeFilter):
    filter_type = "TYPE_FILTER"
    context_types = ByFactory(ContextTypeFactory, "list")

    def __init__(self, client, context_types):
        ContextFilter.__init__(self, client=client)
        TypeFilter.__init__(self, context_types=context_types)
        self.context_types = context_types

    def __json__(self):
        return {
            **super().__json__(),
            "types": [context_type.key for context_type in self.context_types],
        }

    def __repr__(self):
        return "<< TypeFilter >>"


class TypeFilterFactory(Authenticated):

    _tm_class = TypeFilterImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client,
            context_types=[
                ContextTypeFactory(client=self.client)._from_json_context_filter(
                    context_type
                )
                for context_type in data["typeResources"]
            ],
        )

    def __call__(self, context_types : list[str]) -> TypeFilter:
        return self._tm_class(client=self.client, context_types=context_types)
