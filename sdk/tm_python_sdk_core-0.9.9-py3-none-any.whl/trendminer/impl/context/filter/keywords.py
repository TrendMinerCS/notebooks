from trendminer.impl import _input as ip
from trendminer.impl.authentication import Authenticated
from trendminer.impl.context.filter.base import ContextFilterWithMode
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import _CONTEXT_FILTER_MODES_EMPTY
from trendminer.sdk.context import ContextFilterModes, KeywordFilter


class KeywordFilterImpl(ContextFilterWithMode, KeywordFilter):

    filter_type = "KEYWORD_FILTER"

    def __init__(self, client, keywords, mode = None):
        ContextFilterWithMode.__init__(self, client=client, mode=mode)
        KeywordFilter.__init__(self, keywords=keywords, mode=mode)
        self.keywords = keywords

    @property
    def keywords(self):
        return self._keywords

    @keywords.setter
    def keywords(self, keywords):
        if self.mode is not None:
            if keywords is not None:
                raise ActionProhibitedError(ExceptionMessages.KEYWORD_FIELD_VALIDATION_FAILED)
            self._keywords = None
        else:
            self._keywords = [kw.lower() for kw in ip.any_list(keywords)]

    def __json__(self):
        return {
            **super().__json__(),
            "keywords": self.keywords,
        }
    
    def __repr__(self):
        return "<< KeywordFilter >>"


class KeywordFilterFactory(Authenticated):

    _tm_class = KeywordFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_EMPTY[mode]
            return self._tm_class(
                client=self.client, keywords=None, mode=_mode
                )
        return self._tm_class(
            client=self.client, keywords=data.get("keywords"), mode=None
            )

    def __call__(self, keywords=None, mode=None) -> KeywordFilter:
        return self._tm_class(client=self.client, keywords=keywords, mode=mode)
