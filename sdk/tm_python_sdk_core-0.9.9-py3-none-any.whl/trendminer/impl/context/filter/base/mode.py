import abc

from trendminer.impl.base import HasOptions
from trendminer.sdk.context.filter import ContextFilterModes

from .filter import ContextFilter


class ContextFilterWithMode(ContextFilter, abc.ABC):
    """Some context filters allow 'modes' to search for special conditions, rather than for an explicit value

    The default mode is to search for when a value is (not) empty

    Attributes
    ----------
    mode : ContextFilterModes
        EMPTY or NON_EMPTY
    """

    mode = HasOptions(ContextFilterModes)

    def __init__(self, client, mode):
        super().__init__(client=client)
        self.mode = mode

    def __json__(self):
        return {
            **super().__json__(),
            "mode": self.mode,
        }
