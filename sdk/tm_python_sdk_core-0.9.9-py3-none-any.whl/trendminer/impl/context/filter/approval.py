from trendminer.impl.authentication import Authenticated
from trendminer.impl.context.filter.base.filter import ContextFilter
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.sdk.context import ApprovalFilter


class ApprovalFilterImpl(ContextFilter, ApprovalFilter):
    filter_type = "APPROVAL_FILTER"

    def __init__(self, client, approved: bool):
        ContextFilter.__init__(self, client=client)
        ApprovalFilter.__init__(self, approved=approved)
        if not isinstance(approved, bool):
            raise ValueError(ExceptionMessages.FIELD_APPROVAL_TYPE_ERROR)
        self.approved = approved

    def __json__(self):
        return {**super().__json__(), "withApprovals": self.approved}

    def __repr__(self):
        return "<< ApprovalFilter >>"


class ApprovalFilterFactory(Authenticated):

    _tm_class = ApprovalFilterImpl

    def _from_json(self, data):
        return self._tm_class(client=self.client, approved=data["withApprovals"])

    def __call__(self, approved: bool) -> ApprovalFilter:
        return self._tm_class(client=self.client, approved=approved)
