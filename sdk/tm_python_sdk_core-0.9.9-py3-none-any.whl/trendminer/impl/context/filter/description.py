from trendminer.impl import _input as ip
from trendminer.impl.authentication import Authenticated
from trendminer.impl.context.filter.base import ContextFilterWithMode
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import _CONTEXT_FILTER_MODES_EMPTY
from trendminer.sdk.context import ContextFilterModes, DescriptionFilter


class DescriptionFilterImpl(ContextFilterWithMode, DescriptionFilter):

    filter_type = "DESCRIPTION_FILTER"

    def __init__(self, client, values, mode = None):
        ContextFilterWithMode.__init__(self, client=client, mode=mode)
        DescriptionFilter.__init__(self, values=values, mode = mode)
        self.values = values

    @property
    def values(self):
        return self._values

    @values.setter
    def values(self, values):
        if self.mode is not None:
            if values is not None:
                raise ActionProhibitedError(ExceptionMessages.DESCRIPTION_FIELD_VALIDATION_FAILED)
            self._values = None
        else:
            self._values = ip.any_list(values)

    def __json__(self):
        return {
            **super().__json__(),
            "values": self.values,
        }
    
    def __repr__(self):
        return "<< DescriptionFilter >>"


class DescriptionFilterFactory(Authenticated):

    _tm_class = DescriptionFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_EMPTY[mode]
            return self._tm_class(
                client=self.client, values=None, mode=_mode
                )
        return self._tm_class(
            client=self.client, values=data.get("values"), mode=None
        )

    def __call__(self, values=None, mode=None) -> DescriptionFilter:
        return self._tm_class(client=self.client, values=values, mode=mode)
