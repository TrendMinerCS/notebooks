from trendminer.impl import _input as ip
from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import HasOptions
from trendminer.impl.context.filter.base import ContextFilterWithMode
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import \
    _CONTEXT_FILTER_MODES_STATES
# from trendminer.impl.constants import CONTEXT_FILTER_MODES_STATES
from trendminer.sdk.context import ContextFilterStatesModes, CurrentStateFilter


class CurrentStateFilterImpl(ContextFilterWithMode, CurrentStateFilter):

    filter_type = "CURRENT_STATE_FILTER"
    mode = HasOptions(ContextFilterStatesModes)

    def __init__(self, client, states, mode = None):
        ContextFilterWithMode.__init__(self, client=client, mode=mode)
        CurrentStateFilter.__init__(self, states=states, mode = mode)
        self.states = states

    @property
    def states(self):
        return self._states

    @states.setter
    def states(self, states):
        if self.mode is not None:
            if states is not None:
                raise ActionProhibitedError(ExceptionMessages.STATES_FIELD_VALIDATION_FAILED)
            self._states = None
        else:
            self._states = ip.any_list(states)
        

    def __json__(self):
        return {
            **super().__json__(),
            "states": self.states,
        }
    
    def __repr__(self):
        return "<< CurrentStateFilter >>"


class CurrentStateFilterFactory(Authenticated):

    _tm_class = CurrentStateFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_STATES[mode]
            return self._tm_class(
                client=self.client, states=None, mode=_mode
                )
        return self._tm_class(
            client=self.client, states=data.get("states"), mode=None
            )

    def __call__(self, states=None, mode=None) -> CurrentStateFilter:
        return self._tm_class(client=self.client, states=states, mode=mode)
