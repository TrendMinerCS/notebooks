from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base.filter import ContextFilter
from trendminer.impl.times import IntervalFactory, time_json
from trendminer.sdk.context import IntervalFilter


class IntervalFilterImpl(ContextFilter, IntervalFilter):
    filter_type = "INTERVAL_FILTER"
    interval = ByFactory(IntervalFactory, "__call__")

    def __init__(self, client, interval, created_date):
        ContextFilter.__init__(self, client=client)
        IntervalFilter.__init__(self, interval, created_date)
        self.interval = interval
        self.created_date = created_date

    def __json__(self):
        data = {
            "startDate": time_json(self.interval.start),
            "endDate": time_json(self.interval.end),
            "type": self.filter_type,
        }

        if self.created_date:
            data.update({"intervalType": "CREATED_DATE"})

        return data
    
    def __repr__(self):
        return "<< IntervalFilter >>"


class IntervalFilterFactory(Authenticated):

    _tm_class = IntervalFilterImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client,
            interval=self.client.time.interval(data),
            created_date=data.get("intervalType") == "CREATED_DATE",
        )

    def __call__(self, interval, created_date=False) -> IntervalFilter:
        return self._tm_class(
            client=self.client, interval=interval, created_date=created_date
        )
