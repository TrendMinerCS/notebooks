from trendminer.impl.asset import Node
from trendminer.impl.base import (ByFactory, HasOptions, Serializable,
                                  TrendMinerFactory)
from trendminer.impl.component_factory import ComponentFactory
from trendminer.sdk.asset.asset import AssetIncludeOptions
from trendminer.sdk.asset.asset import AssetIncludeOptions
from trendminer.sdk.context import ComponentQuery


class ComponentQueryImpl(Serializable, ComponentQuery):

    component = ByFactory(ComponentFactory)
    include = HasOptions(AssetIncludeOptions)

    def __init__(self, client, component, include):
        Serializable.__init__(self, client=client)
        ComponentQuery.__init__(self, component = component, include = include)
        self.component = component
        self.include = include

    def __json__(self):
        if isinstance(self.component, Node):
            node_payload = {
                "include": self.include or AssetIncludeOptions.SELF,
                "path": self.component.path_hex,
            }
        else:
            node_payload = {}

        return {
            "type": self.component._component_type,
            "identifier": self.component.identifier,
            **node_payload,
        }


class ComponentQueryFactory(TrendMinerFactory):
    """Factory for creating component queries"""

    _tm_class = ComponentQueryImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client,
            component=ComponentFactory(client=self.client)._from_json_context_item(
                data
            ),
            include=AssetIncludeOptions(data.get("include"))
        )

    def from_query(self, query):
        if isinstance(query, tuple):
            try:
                include = query[1]
            except IndexError:
                include = None
            return self._tm_class(
                client=self.client, component=query[0], include=include
            )

        return self._tm_class(client=self.client, component=query, include=AssetIncludeOptions.SELF)

    @property
    def _get_methods(self):
        return (self.from_query,)
