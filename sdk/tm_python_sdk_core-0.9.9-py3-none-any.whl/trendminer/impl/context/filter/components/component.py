from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base import ContextFilterWithMode
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import _CONTEXT_FILTER_MODES_EMPTY
from trendminer.sdk.context import ComponentFilter

from .query import ComponentQueryFactory


class ComponentFilterImpl(ContextFilterWithMode, ComponentFilter):

    filter_type = "COMPONENT_FILTER"
    component_queries = ByFactory(ComponentQueryFactory, "list")

    def __init__(self, client, components, mode = None):
        ContextFilterWithMode.__init__(self, client=client, mode=mode)
        ComponentFilter.__init__(self, components=components, mode=mode)
        if mode is not None:
            if components is not None:
                raise ActionProhibitedError(ExceptionMessages.COMPONENT_FIELD_VALIDATION_FAILED)
            self.component_queries = None
        else:
            self.component_queries = components

    def __json__(self):
        return {
            **super().__json__(),
            "components": self.component_queries,
        }

    def __repr__(self):
        return "<< ComponentFilter >>"


class ComponentFilterFactory(Authenticated):

    _tm_class = ComponentFilterImpl

    def _from_json(self, data):
        mode = data.get("mode")
        if mode is not None:
            _mode=_CONTEXT_FILTER_MODES_EMPTY[mode]
            return self._tm_class(
                client=self.client,
                components=None,
                mode=_mode
            )
        return self._tm_class(
            client=self.client,
            components=[
                ComponentQueryFactory(client=self.client)._from_json(component)
                for component in data.get("componentResources", [])
            ],
            mode=None,
        )

    def __call__(self, components=None, mode=None) -> ComponentFilter:
        return self._tm_class(
            client=self.client,
            components=components,
            mode=mode,
        )
