from trendminer.impl import _input as ip
from trendminer.impl.authentication import Authenticated
from trendminer.impl.context.filter.base import ContextFilter
from trendminer.sdk.context import PropertyFieldFilter


class PropertyFieldFilterImpl(ContextFilter, PropertyFieldFilter):
    filter_type = "PROPERTY_FIELD_FILTER"

    def __init__(self, client, key, values):
        ContextFilter.__init__(self, client=client)
        PropertyFieldFilter.__init__(self, key=key, values=values)
        self.key = key
        self.values = values

    @property
    def values(self):
        return self._values

    @values.setter
    def values(self, values):
        self._values = ip.any_list(values)

    def __json__(self):
        return {
            **super().__json__(),
            "key": self.key,
            "values": self.values,
        }
    
    def __repr__(self):
        return "<< PropertyFieldFilter >>"


class PropertyFieldFilterFactory(Authenticated):

    _tm_class = PropertyFieldFilterImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client, key=data["key"], values=data["values"]
        )

    def __call__(self, key, values) -> PropertyFieldFilter:
        return self._tm_class(client=self.client, key=key, values=values)
