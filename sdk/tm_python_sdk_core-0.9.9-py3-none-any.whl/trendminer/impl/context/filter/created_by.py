from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base.filter import ContextFilter
from trendminer.impl.user import UserFactory
from trendminer.sdk.context import CreatedByFilter


class CreatedByFilterImpl(ContextFilter, CreatedByFilter):
    filter_type = "CREATED_BY_FILTER"
    users = ByFactory(UserFactory, "list")

    def __init__(self, client, users):
        ContextFilter.__init__(self, client=client)
        CreatedByFilter.__init__(self, users=users)
        self.users = users

    def __json__(self):
        return {
            **super().__json__(),
            "users": self.users,
        }
    
    def __repr__(self):
        return "<< CreatedByFilter >>"


class CreatedByFilterFactory(Authenticated):

    _tm_class = CreatedByFilterImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client,
            users=[
                UserFactory(client=self.client)._from_json_limited_id(user)
                for user in data["userDetails"]
            ],
        )

    def __call__(self, users : list[str]) -> CreatedByFilter:
        return self._tm_class(client=self.client, users=users)
