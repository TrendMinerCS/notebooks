from trendminer.impl.base import TrendMinerFactory
from trendminer.sdk.context import ContextFilterAPI

from .approval import ApprovalFilterFactory
from .base import ContextFilter
from .components import ComponentFilterFactory
from .context_type import TypeFilterFactory
from .created_by import CreatedByFilterFactory
from .created_date import CreatedDateFilterFactory
from .description import DescriptionFilterFactory
from .duration import DurationFilterFactory
from .field import (EnumerationFieldFilterFactory, FieldFilterFactory,
                    NumericFieldFilterFactory, StringFieldFilterFactory)
from .interval import IntervalFilterFactory
from .keywords import KeywordFilterFactory
from .period import PeriodFilterFactory
from .property import PropertyFieldFilterFactory
from .states import CurrentStateFilterFactory

filter_factory_dict = {
    factory._tm_class.filter_type: factory
    for factory in [
        ApprovalFilterFactory,
        TypeFilterFactory,
        CreatedByFilterFactory,
        ComponentFilterFactory,
        PeriodFilterFactory,
        IntervalFilterFactory,
        KeywordFilterFactory,
        DescriptionFilterFactory,
        CurrentStateFilterFactory,
        NumericFieldFilterFactory,
        StringFieldFilterFactory,
        EnumerationFieldFilterFactory,
        PropertyFieldFilterFactory,
        CreatedDateFilterFactory,
        DurationFilterFactory,
    ]
}


# TODO: can be MultiFactory
class ContextFilterFactory(TrendMinerFactory, ContextFilterAPI):

    _tm_class = ContextFilter

    @property
    def approval(self):
        return ApprovalFilterFactory(client=self.client)

    @property
    def context_types(self):
        return TypeFilterFactory(client=self.client)

    @property
    def users(self):
        return CreatedByFilterFactory(client=self.client)

    @property
    def duration(self):
        return DurationFilterFactory(client=self.client)

    @property
    def components(self):
        return ComponentFilterFactory(client=self.client)

    @property
    def period(self):
        return PeriodFilterFactory(client=self.client)

    @property
    def interval(self):
        return IntervalFilterFactory(client=self.client)

    @property
    def keywords(self):
        return KeywordFilterFactory(client=self.client)

    @property
    def description(self):
        return DescriptionFilterFactory(client=self.client)

    @property
    def states(self):
        return CurrentStateFilterFactory(client=self.client)

    @property
    def field(self):
        return FieldFilterFactory(client=self.client)

    @property
    def created_date(self):
        return CreatedDateFilterFactory(client=self.client)

    @property
    def property(self):
        return PropertyFieldFilterFactory(client=self.client)

    def _from_json(self, data):
        filter_type = data["type"]
        try:
            factory = filter_factory_dict[filter_type](client=self.client)
        except (KeyError, TypeError):
            raise NotImplementedError(f"No handling for filter type {filter_type}")
        return factory._from_json(data)
