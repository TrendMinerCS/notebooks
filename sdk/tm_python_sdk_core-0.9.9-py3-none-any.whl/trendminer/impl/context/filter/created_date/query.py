from trendminer.impl.base import ByFactory, HasOptions
from trendminer.impl.context.filter.base import (ContextDateQuery,
                                                 ContextDateQueryFactory,
                                                 ContextFilter, ContextQuery,
                                                 ContextQueryFactory,
                                                 _validate_operator)
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ActionProhibitedError
from trendminer.impl.options.context_options import _CONTEXT_DATE_OPERATORS
from trendminer.impl.times import DatetimeFactory, time_json
from trendminer.sdk.context import ContextDateOperators, CreatedDateQuery
from trendminer.sdk.context.filter import ContextDateOperators


class CreatedDateQueryImpl(ContextDateQuery, CreatedDateQuery):
    value = ByFactory(DatetimeFactory, "__call__")

    def __init__(self, client, operator, value):
        ContextDateQuery.__init__(self, client=client, operator=operator, value=value)
        CreatedDateQuery.__init__(self, operator=operator, value=value)
        _validate_operator(operator, ContextDateOperators)

    def __json__(self):
        return {
            "operator": self.operator_str,
            "createdDate": time_json(self.value),
        }


class DateQueryFactory(ContextDateQueryFactory):

    _tm_class = CreatedDateQueryImpl

    def _from_json(self, data):
        return self._tm_class(
            client=self.client, operator=data["operator"], value=data["createdDate"]
        )
