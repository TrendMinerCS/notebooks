from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base import ContextFilter
from trendminer.impl.options.context_options import _CONTEXT_DATE_OPERATORS
from trendminer.sdk.context import CreatedDateFilter

from .query import DateQueryFactory


class CreatedDateFilterImpl(ContextFilter, CreatedDateFilter):
    filter_type = "CREATED_DATE_FILTER"
    condition = ByFactory(DateQueryFactory)

    def __init__(self, client, condition):
        ContextFilter.__init__(self, client=client)
        CreatedDateFilter.__init__(self, condition =  condition)
        self.condition = condition

    def __json__(self):
        return {
            **super().__json__(),
            **self.condition.__json__(),
        }
    
    def __repr__(self):
        return "<< CreatedDateFilter >>"


class CreatedDateFilterFactory(Authenticated):
    _tm_class = CreatedDateFilterImpl
    def _from_json(self, data):
        if 'operator' in data:
            operator = data['operator']
            data['operator'] = _CONTEXT_DATE_OPERATORS[operator]
        return self._tm_class(
            client=self.client,
            condition=DateQueryFactory(client=self.client)._from_json(data),
        )

    def __call__(self, condition) -> CreatedDateFilter:
        return self._tm_class(client=self.client, condition=condition)
