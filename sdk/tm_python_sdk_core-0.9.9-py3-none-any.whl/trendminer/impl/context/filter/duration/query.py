from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base import (ContextQuery,
                                                 ContextQueryFactory)
from trendminer.impl.times import TimedeltaFactory, time_json
from trendminer.sdk.context import DurationQuery


class DurationQueryImpl(ContextQuery, DurationQuery):
    value = ByFactory(TimedeltaFactory, "__call__")

    def __init__(self, client, operator, value):
        ContextQuery.__init__(self, client=client, operator=operator, value=value)
        DurationQuery.__init__(self, operator = operator, value = value)
    def __json__(self):
        operator = self.operator if self.operator else self.operator_str
        return {

            "operator": operator,
            "value": time_json(self.value),
        }


class DurationQueryFactory(ContextQueryFactory):
    _tm_class = DurationQueryImpl
