from trendminer.impl.authentication import Authenticated
from trendminer.impl.base import ByFactory
from trendminer.impl.context.filter.base import (ContextFilter,
                                                 _validate_conditions,
                                                 interpret_query)
from trendminer.impl.options.context_options import _CONTEXT_OPERATORS
from trendminer.sdk.context import ContextOperators, DurationFilter
from trendminer.sdk.context.filter import ContextOperators

from .query import DurationQueryFactory


class DurationFilterImpl(ContextFilter, DurationFilter):
    """Filter on context item duration

    Attributes
    ----------
    conditions : list of DurationQuery
        Duration-based queries on which to filter
    """

    filter_type = "DURATION_FILTER"
    conditions = ByFactory(DurationQueryFactory, "list")

    def __init__(self, client, conditions):
        ContextFilter.__init__(self, client=client)
        DurationFilter.__init__(self, conditions=conditions)
        _validate_conditions(conditions, ContextOperators)
        self.conditions = conditions

    def __json__(self):
        return {
            **super().__json__(),
            "conditions": self.conditions,
        }
    
    def __repr__(self):
        return "<< DurationFilter >>"


class DurationFilterFactory(Authenticated):

    _tm_class = DurationFilterImpl

    def _from_json(self, data):
        conditions = data["conditions"]
        for condition in conditions:
            parameter, operator, value = interpret_query(condition)
            if 'operator' in condition:
                condition['operator'] = _CONTEXT_OPERATORS[operator]
        return self._tm_class(client=self.client, conditions=conditions)

    def __call__(self, conditions) -> DurationFilter: 
        return self._tm_class(client=self.client, conditions=conditions)
