import abc
import json
from datetime import timedelta

import cachetools
from requests.exceptions import RequestException

from trendminer.impl.constants import DEFAULT_ENCODING, MAX_GET_SIZE
from trendminer.impl.exception_messages import ExceptionMessages
from trendminer.impl.exceptions import ResourceNotFound
from trendminer.impl.services.services import _datasource_service

from . import _input as ip
from .base import (Gettable, LazyLoadingClass, TrendMinerFactory,
                   kwargs_to_class)
from .constants import MAX_DATASOURCE_CACHE


class DatasourceClient(abc.ABC):
    """Client for datasource factory"""

    @property
    def datasource(self):
        """Datasource factory

        Returns
        -------
        DatasourceFactory
        """
        return DatasourceFactory(client=self)


class Datasource(Gettable, LazyLoadingClass):
    """Tag datasource

    Attributes
    ----------
    name : str
        Datasource name
    description : str
        Datasource description
    capabilities : list of str
        capabiblity types, e.g. "TIME_SERIES"
    raw : bool
        Whether the datasource only supports raw values (plots index points only, even when zooming in).
    granularity : timedelta
        Chunk size for historic indexing
    connector_id : str or None
        Identifier of the connector containing the datasource. `None` for built-in datasources.
    source_type : str
        Datasource type
    created_on : datetime
        Data the datsource was created
    synced_on : datetime
        Last synced date for the datasource
    provider_properties : list of str
        Provider type properties
    builtin : bool
        Whether the datasource is one of the fixed applicance datasources (e.g., Formula tags)
    """

    # endpoint = "/ds/datasources/"

    def __init__(
        self,
        client,
        identifier,
        name,
        capabilities,
        description,
        raw,
        granularity,
        connector_id,
        source_type,
        created_on,
        synced_on,
        provider_properties,
        builtin,
    ):

        super().__init__(client=client, identifier=identifier)

        self.name = name
        self.description = description
        self.capabilities = capabilities
        self.raw = raw
        self.granularity = granularity
        self.connector_id = connector_id
        self.source_type = source_type
        self.created_on = created_on
        self.synced_on = synced_on
        self.provider_properties = provider_properties
        self.builtin = builtin

    def _full_instance(self):
        return DatasourceFactory(client=self.client).get_by_identifier(self.identifier)

    def __json__(self):
        return self.identifier

    def __repr__(self):
        return f"<< Datasource | {self._repr_lazy('name')} | {self._repr_lazy('source_type')} >>"


class DatasourceFactory(TrendMinerFactory):
    """Factory for datasources"""

    _tm_class = Datasource

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Datasource
        """
        return self._tm_class(
            client=self.client,
            identifier=data["datasourceId"],
            name=data["name"],
            capabilities=data["capabilityTypes"],
            description=data["description"],
            raw=data["onlySupportsRawValues"],
            granularity=timedelta(days=float(data["indexingGranularity"])),
            connector_id=data["connectorId"],
            source_type=data["type"],
            created_on=self.client.time.datetime(data["createOn"]),
            synced_on=self.client.time.datetime(data["syncedOn"]),
            provider_properties=data["providerTypeProperties"],
            builtin=data["builtin"],
        )

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        """Datasource where all attributes except the identifier are lazy
        Allows creating a datasource from its identifier only, avoiding a call to retrieve the datasource info when
        not needed.
        Parameters
        ----------
        data : str
            Datasource identifier
        Returns
        -------
        Datasource
        """
        return {"identifier": data}

    def get_by_name(self, ref):
        """Retrieve a datasource by its name

        Parameters
        ----------
        ref : str
            Datasource name

        Returns
        -------
        Datasource
        """
        self.__from_name(ref)

    def __from_name(self, ref):
        """Retrieve a datasource by its name
        Parameters
        ----------
        ref : str
            Datasource name
        Returns
        -------
        Datasource
        """
        return ip.object_match_nocase(self.all(), attribute="name", value=ref)

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=MAX_DATASOURCE_CACHE),
        key=TrendMinerFactory._cache_key_ref,
    )
    def get_by_identifier(self, ref):
        """Retrieve a datasource by its identifier

        Parameters
        ----------
        ref : str
            Datasource identifier

        Returns
        -------
        Datasource
        """
        return self.__from_identifier(ref)

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=MAX_DATASOURCE_CACHE),
        key=TrendMinerFactory._cache_key_ref,
    )
    def __from_identifier(self, ref):
        """Retrieve a datasource by its identifier
        Parameters
        ----------
        ref : str
            Datasource identifier
        Returns
        -------
        Datasource
        """
        response = _datasource_service(self.client).get_datasource_by_id(ref)
        respone_json = self._from_json(response.json())
        return respone_json

    @cachetools.cached(
        cache=cachetools.LRUCache(maxsize=10), key=TrendMinerFactory._cache_key_no_args
    )
    def all(self):
        """Retrieve all datasources

        Returns
        -------
        list of Datasource
        """
        params = {"size": MAX_GET_SIZE}
        method = _datasource_service(self.client).get_datasources
        content = self._prepare_paged_response(method, keys=["content"], params=params)
        return [self._from_json(data) for data in content]

    @property
    def _get_methods(self):
        return self.get_by_identifier, self.get_by_name

    def _extract_content(self, keys, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _prepare_response(self, raw_response):
        response_raw_data = raw_response.content
        return json.loads(response_raw_data.decode(DEFAULT_ENCODING))

    def _prepare_paged_response(self, method, keys, **kwargs):
        setter_key = "params"
        kwargs.setdefault(setter_key, {"page": 0})
        kwargs[setter_key].update({"page": 0})
        keys = ip.any_list(keys)
        try:
            responses = [method(**kwargs["params"])]
            responses[0].raise_for_status()
            total_pages = self._prepare_response(responses[0])["page"]["totalPages"]

            if total_pages > 1:
                for page in range(1, total_pages):
                    kwargs[setter_key].update({"page": page})
                    responses.append(method(**kwargs["params"]))
            return [
                item
                for r in responses
                for item in self._extract_content(keys, self._prepare_response(r))
            ]
        except RequestException as excp:
            excp.args = (f"Status: {excp.response.status_code}"), (
                (f"{excp.response.text}") if len(excp.args) > 0 else excp.args
            )
            if excp.response.status_code in [400, 404]:
                raise ResourceNotFound(ExceptionMessages.RESOURCE_NOT_FOUND) from excp
            if excp.response.status_code == 403:
                raise ResourceNotFound(
                    ExceptionMessages.RESOURCE_NOT_PERMITTED
                ) from excp
            if excp.response.status_code == 401:
                raise ResourceNotFound(ExceptionMessages.UNAUTHORIZED) from excp
            raise excp
