"""This file contains BaseAPIClient class implementation"""

import abc


class BaseAPIClient(abc.ABC):
    """BaseAPIClient Class
    This class should be implemented by any request client class"""

    @abc.abstractmethod
    def call_api(
        self,
        resource_path,
        method,
        path_params=None,
        query_params=None,
        header_params=None,
        body=None,
        post_params=None,
        files=None,
        response_type=None,
        auth_settings=None,
        async_req=None,
        _return_http_data_only=None,
        collection_formats=None,
        _preload_content=True,
        _request_timeout=None,
    ):
        """call_api method"""
        raise NotImplementedError()


class BaseService(abc.ABC):
    """BaseService Class"""

    def __init__(self, api_client: BaseAPIClient):
        self._api_client: BaseAPIClient = api_client
