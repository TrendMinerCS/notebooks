"""This file contains Services class implementation"""

from trendminer.impl._util import DefaultUrlUtils
from trendminer.impl.constants import CLUSTER_LOCAL_NAME, SERVICE_NAMES

from .api_client import RequestsAPIClient
from .assets import AssetsService
from .base import BaseAPIClient
from .compute import ComputeService
from .context import ContextService
from .datasource import DatasourceService
from .timeseries import TimeseriesService
from .work import WorkService


def set_default_url(client, servicename):
    if client.session.base_url is not None:
        if CLUSTER_LOCAL_NAME in client.session.base_url:
            client.session.base_url = DefaultUrlUtils().get_default_url(servicename)
    elif client.session.base_url is None:
        client.session.base_url = DefaultUrlUtils().get_default_url(servicename)
    return client


def _datasource_service(client) -> DatasourceService:
    """Returns Datasource Service Class object"""
    service_name = SERVICE_NAMES["datasource"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return DatasourceService(api_client=api_client)


def _assets_service(client) -> AssetsService:
    """Returns Assets Service Class object"""
    service_name = SERVICE_NAMES["assets"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return AssetsService(api_client=api_client)


def _compute_service(client) -> ComputeService:
    """Returns Compute Service Class object"""
    service_name = SERVICE_NAMES["compute"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return ComputeService(api_client=api_client)


def _context_service(client) -> ContextService:
    """Returns Context Service Class object"""
    service_name = SERVICE_NAMES["context"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return ContextService(api_client=api_client)


def _timeseries_service(client) -> TimeseriesService:
    """Returns Timeseries Service Class object"""
    service_name = SERVICE_NAMES["ts"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return TimeseriesService(api_client=api_client)


def _work_service(client) -> WorkService:
    """Returns WorkOrg Service Class object"""
    service_name = SERVICE_NAMES["work"]
    client = set_default_url(client, service_name)
    api_client: BaseAPIClient = RequestsAPIClient(auth_client=client, url=None)
    return WorkService(api_client=api_client)
