from .client import Authenticated, BaseClient
from .session import TrendMinerSession
