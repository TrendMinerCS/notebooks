import abc

from .history import responses_to_df


class BaseClient(abc.ABC):
    """Handles all authentication for the client. Stores the session."""

    def __init__(
        self,
        url,
        token,
        keep_history,
        session_type,
    ):

        self.session = session_type(base_url=url, keep_history=keep_history)
        self.session.login(
            token=token,
        )

    # def logout(self):
    #     """Explicit session logout. Invalidates token."""
    #     self.session.logout()

    #Rename this property as we are unable to assign some properties in Client Constructor
    @property
    def base_url(self):
        """TrendMiner appliance url"""
        return self.session.base_url

    @property
    def history(self):
        """List of historic requests by the client. Empty if ``keep_history=False``"""
        return self.session.history

    @property
    def history_df(self):
        """DataFrame summarizing historic requests by the client. Empty if ``keep_history=False``"""
        return responses_to_df(self.history)

    def __repr__(self):
        return (
            f"<< {self.__class__.__name__}"
            # f" | {self.url}"
            f" | {self.session.token_decoded['preferred_username']} >>"
        )


class Authenticated(abc.ABC):
    """Instances which requre authentication to the TrendMiner server

    Parameters
    ----------
    client: TrendMinerClient
        Client providing link to the appliance
    """

    def __init__(self, client):
        self.client = client

    def __repr__(self):
        return f"<< {self.__class__.__name__} >>"
