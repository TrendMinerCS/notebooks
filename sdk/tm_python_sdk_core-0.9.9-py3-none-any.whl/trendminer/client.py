from typing import Optional
from pytz import BaseTzInfo, utc
from trendminer.impl.client import ClientImpl
from trendminer.sdk.client import Client

class TrendMinerClient:
        
    """TrendminerClient handles requests to the Trendminer Services. User needs to provide token
    and basic configuration in order to retrieve a :class:`~.Client` instance.
    """
    
    @staticmethod
    def from_token(token: str, url: Optional[str] = None, tz : Optional[BaseTzInfo] = utc) -> Client:
        """Returns the TrendMiner client instance.

        Parameters
        ----------

        token : str
            Token of a authenticated user

        url : str, optional
            Url of the trendminer instance, default None

        tz : str or BaseTzInfo, optional
            Timezone of the client, default utc

        Returns
        -------
        Client
            Client instance for navigating functionalities of the Trendminer SDK

        Example
        -------

        .. code-block:: python

            from trendminer import TrendMinerClient

            #When user is working from a TrendMiner environment
            client = TrendMinerClient.from_token('<oauth2_token>')

            #When user is working from an external environment, pass the URL
            client = TrendMinerClient.from_token(url='https://trendminer.yourcompany.com',token='<oauth2_token>')
        """

        return ClientImpl(token = token, url = url, tz = tz)
