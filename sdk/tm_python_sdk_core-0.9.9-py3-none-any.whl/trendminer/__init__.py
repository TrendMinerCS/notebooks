from .client import TrendMinerClient

"""
The TrendMiner Python SDK allows you to interact with TrendMiner via a high-level API from any Python runtime, e.g. from
a Python notebook embedded within TrendMiner. Most boilerplate code has been written for you, so you can focus on what
is important: get valuable insights from your time series data.
"""

__version__ = "0.9.9"

