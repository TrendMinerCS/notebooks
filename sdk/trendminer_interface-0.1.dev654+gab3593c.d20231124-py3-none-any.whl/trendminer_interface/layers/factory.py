import uuid
from trendminer_interface.base import TrendMinerFactory
from .layer import Layer


class LayerFactory(TrendMinerFactory):
    """Factory class for creating new layers

    As a layer is always attached to a TrenHub view, and cannot exist as independent object, this class is only intended
    for internal use. It is called from the TrendHubView instance.

    Attributes
    ----------
    parent : TrendHubView
        TrendHub view to which the created layers will belong
    """
    tm_class = Layer

    def __init__(self, parent):
        super().__init__(client=parent.client)
        self.parent = parent

    def __call__(self, interval, base=True, name="", visible=True, line_style="SOLID"):
        """Instantiate a new layer

        Parameters
        ----------
        interval : Interval
            The layer interval
        base : bool, default True
            Whether the layer is a base layer
        visible : bool, default True
            Whether the layer is visible
        line_style : str, default "SOLID"
            Layer line style
        """
        return self.tm_class(
            client=self.client,
            parent=self.parent,
            name=name,
            display_timespan=interval,
            timespan=interval,
            base=base,
            visible=visible,
            line_style="SOLID",
            hidden_references=[],
            identifier=str(uuid.uuid4()),  # random identifier needs to be assigned
            shift=0,
            source={"type": "MANUAL"},
        )

    def from_interval(self, interval):
        """Create a Layer from a given Interval

        Intended to convert list of intervals into layers when the user creates a view.
        Layer will not be base by default, and have the "DASHED" linestyle.

        Parameters
        ----------
        interval : Interval or Any
            Interval to be turned into a layer
        """
        return self.__call__(
            interval=interval,
            base=False,
            line_style='DASHED'
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Layer
        """
        return self.tm_class(
            client=self.client,
            parent=self.parent,
            name=data["name"],
            display_timespan=data["displayTimeSpan"],
            timespan=data["timeSpan"],
            base=data["baseLayer"],
            visible=data["options"]["visible"],
            line_style=data["options"]["lineStyle"],
            hidden_references=data["options"]["hiddenDataReferences"],
            identifier=data["id"],
            shift=data["options"]["shift"]/1000,
            source=data["source"],
        )

    @property
    def _get_methods(self):
        return self.from_interval,