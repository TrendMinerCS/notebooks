import abc
from trendminer_interface.base import LazyAttribute
from .factory import LayerFactory


class LayersObject(abc.ABC):
    """Base class for objects which have layers"""
    def __int__(self, layers):
        self.layers = layers

    @property
    def layers(self):
        """View layers

        When setting, a single layers can be configured as the base layer by setting the `base` attribute to `True`. If
        none of the layers is explicitly set as base layer, it is assumed the first layer is the base layer.

        The layers can be set by passing Layer instances, but Interval instances work too. These are turned into layers
        with default configuration.

        Returns
        -------
        list of Layer
        """
        return self._layers

    @layers.setter
    def layers(self, layers):
        if not isinstance(layers, LazyAttribute):
            layers = LayerFactory(parent=self).list(layers)
            if not any([layer.base for layer in layers]):
                layers[0].base = True
        self._layers = layers


    @property
    def base_layer(self):
        """The base layer

        Returns
        -------
        Layer
        """
        return [layer for layer in self.layers if layer.base][0]

    def get_data(self, form="interpolated", resolution=None, fill=False):
        """Retrieve timeseries data for underlying tags and layers

        Parameters
        ----------
        form : {'interpolated', 'chart', 'index'}
            - **interpolated:** points at fixed intervals. These datapoints are obtained from interpolating the index
              data. Setting the resolution higher will retrieve more points, but always through interpolation of index
              data. A request is never passed on to the historian to get more real points. Type of the interpolation
              naturally depends on the tag type.
            - **chart**: performs a plot call, returning plot-optimized points. For resolutions lower or equal to index
              resolution, this call returns index data for the tag. When resolution is higher and the tag datasource is
              not a 'raw' datasource, the request is passed on to the original datasource, in the same way that if you
              zoom in to a plot in the UX, the request is passed on to the datasource to get higher resolution data
            - **index:** similar to 'chart', in that plot optimized real datapoints are returned. The difference is that
              no data will be retrieved that is not stored in the index. No matter how high we set the resolution, the
              request is never passed on to the datasource.
        resolution : datetime.timedelta or str or float, optional
            Resolution setting for retrieving data. String values are interpreted to timedelta. Floats are assumed to
            be in seconds.
        fill : bool, default False,
            For chart and index data, tag points timestamps typically do not match. When setting `fill=True`, tags are
            interpolated (in accordance with their interpolation type) so that all tags have values associated with
            every timestamp. When `fill=False`, NaN values will occur in the dataframes for the timestamps at which
            there are points for other tags, but not that tag.

        Returns
        -------
        list of DataFrame
            A dataframe with DatetimeIndex and tagnames as columns for every layer in the view
        """
        return [layer.get_data(form=form, resolution=resolution, fill=fill) for layer in self.layers]


class LayerBase:
    pass  # TODO: base class for TrendHub and Fingerprint layers
