from trendminer_interface.base import Savable, TrendMinerFactory, kwargs_to_class
from trendminer_interface.search import SearchFactory
from trendminer_interface.base import LazyLoadingClass, LazyAttribute, ByFactory
from trendminer_interface.times import time_json, DatetimeFactory
from trendminer_interface import _input as ip

from .notification import WebhookNotification, EmailNotification, ContextItemNotification

# TODO: once Fingerprint is added, will need MultiFactory over SearchFactory and FingerprintFactory


class Monitor(Savable, LazyLoadingClass):
    """Search-based monitor"""
    endpoint = '/hps/api/monitoring/'

    created = ByFactory(DatetimeFactory, "__call__")
    last_modified = ByFactory(DatetimeFactory, "__call__")

    def __init__(
            self,
            client,
            identifier,
            enabled,
            created,
            last_modified,
            search,
            state,
            monitor_dependency,  # is this monitor a trigger for another monitor (fingerprint deviation)
            webhook,
            email,
            context,
    ):
        Savable.__init__(self=self, client=client, identifier=identifier)

        self.enabled = enabled
        self.search = search
        self.created = created
        self.last_modified = last_modified
        self.state = state
        self.monitor_dependency = monitor_dependency
        self.webhook = webhook
        self.email = email
        self.context = context

    @property
    def identifier(self):
        """Monitor identifier

        Not a UUID, just simple sequential numbering. Converted to string for compatibility.

        Returns
        -------
        identifier : str
        """
        return self._identifier

    @identifier.setter
    def identifier(self, identifier):
        if identifier not in [None, LazyAttribute]:
            identifier = str(identifier)
        self._identifier = identifier

    @property
    def name(self):
        """Monitor name

        Identical to the name of the underlying search

        Returns
        -------
        name : str
            Monitor name
        """
        return self.search.name

    def post(self):
        """UNAVAILABLE

        Monitors are automatically created from searches. They cannot be created by POST
        """
        raise NotImplementedError("Monitors are automatically created from searches. They cannot be created by POST")

    def put(self):
        """Update existing search with the current configuration"""
        super().put()
        if self.enabled:
            self.client.session.post(f"/hps/api/monitoring/status/{self.identifier}")
        else:
            self.delete()

    def delete(self):
        """Disables the monitor

        Monitor cannot be truly deleted. They exist as long as their underlyiing search exists. A delete requests
        only disables the monitor but does not remove the object
        """
        self.client.session.delete(f"/hps/api/monitoring/status/{self.identifier}")
        self.enabled = False

    def _full_instance(self):
        if "search" not in self.lazy:
            return MonitorFactory(client=self.client).from_search(self.search)
        else:
            return MonitorFactory(client=self.client).from_identifier(self.identifier)

    def _put_updates(self, response):
        self.last_modified = LazyAttribute()
        self.webhook = LazyAttribute()
        self.email = LazyAttribute()
        self.context = LazyAttribute()

    # TODO: implement getting most recent monitor results
    # def get_results(self, limit=50):
    #     pass

    def blueprint(self):
        raise NotImplementedError

    def __json__(self):
        return {
            "contextItemNotification": self.context,
            "created": time_json(self.created),
            "emailNotification": self.email,
            "enabled": self.enabled,
            "id": int(self.identifier),
            "isMonitoringPatternDependency": self.monitor_dependency,
            "lastUpdatedDate": time_json(self.client.time.now()),
            "name": self.name,
            "searchId": self.search.identifier_monitor,
            "state": self.state,
            "type": self.search.search_type,
            "username": self.search.owner.name,
            "webhookNotification": self.webhook,
            # "tags" also given from UX put request, but is filled automatically when not provided
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self._repr_lazy('identifier')} >>"


class MonitorFactory(TrendMinerFactory):
    """Factory for retrieving monitors"""
    tm_class = Monitor

    def _json_to_kwargs_base(self, data):
        return {
            "identifier": data["id"],
            "enabled": data["enabled"],
            "created": data["created"],
            "last_modified": data["lastUpdatedDate"],
            "state": data["state"],
        }

    def _json_to_kwargs_notifications(self, data):
        return {
            "webhook": WebhookNotification._from_json(
                monitor=self,
                data=data.get("webhookNotification", {"enabled": False, "url": ""})
            ),
            "email": EmailNotification._from_json(
                monitor=self,
                data=data["emailNotification"]
            ),
            "context": ContextItemNotification._from_json(
                monitor=self, data=data["contextItemNotification"]
            ),
        }

    @kwargs_to_class
    def _from_json_full(self, data):
        """Getting data from search ID gives full overview"""
        return {
            **self._json_to_kwargs_base(data),
            **self._json_to_kwargs_notifications(data),
            "search": SearchFactory(client=self.client)._from_json_monitor(data),
            "monitor_dependency": data["isMonitoringPatternDependency"],
        }

    @kwargs_to_class
    def _from_json_all(self, data):
        """from structure when requesting overview of all monitors"""
        return {
            **self._json_to_kwargs_base(data),
            "search": SearchFactory(client=self.client)._from_json_monitor(data),
        }

    @kwargs_to_class
    def _from_json(self, data):
        """from structure when getting monitor directly from identifier"""
        return {
            **self._json_to_kwargs_base(data),
            **self._json_to_kwargs_notifications(data),
            "search": SearchFactory(client=self.client)._from_json_monitor_nameless(data),
        }

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        """create instance from only the identifier"""
        return {"identifier": data}

    def from_search(self, search):
        """Retrieve monitor from a search

        Attributes
        ----------
        search : Any
            Any (reference to an) existing search
        """
        search = self.client.search.get(search)
        response = self.client.session.get(f"hps/api/monitoring/bySearchId/{search.identifier_monitor}")
        monitor = self._from_json_full(response.json())
        monitor.search = search
        return monitor

    def overview(self, since):
        """Number of triggers for the active monitors

        Parameters
        ----------
        since : datetime or Any
            The start date from when to count the number of triggers (up to the current date)

        Returns
        -------
        dict of (Any: int)
            Search objects as keys, number of hits as values
        """
        params = {
            "since": time_json(self.client.time.datetime(since))
        }
        response = self.client.session.get("/hps/api/monitoring/overview", params=params)
        active_monitors = self.all(active_only=True)
        return {
            ip.object_match_nocase(active_monitors, "identifier", str(entry["id"])): entry["numberOfResults"]
            for entry in response.json()["overview"]
        }

    def from_identifier(self, ref):
        """Retrieve monitor from identifier

        Parameters
        ----------
        ref : str or int
            Monitor identifier

        Returns
        -------
        Monitor
        """
        ref = str(ref)
        return super().from_identifier(ref)

    def all(self, active_only=True):
        """Retrieve all monitors

        Parameters
        ----------
        active_only : bool, default True
            Whether only the currently active monitors need to be retrieved, otherwise a monitor is retrieved for every
            search that is implemented in the SDK.
        """
        params = {
            "filterOnlyActiveMonitors": active_only,
            "doNotRetrieveTags": True,
        }
        response = self.client.session.get(self.tm_class.endpoint, params=params)
        return [
            self._from_json_all(data)
            for data in response.json()
            if data["type"] in SearchFactory.factories  # only load monitors for search types we support
        ]

    def from_name(self, ref):
        """Retrieve monitor from its name

        Returns
        -------
        Monitor
        """
        return ip.object_match_nocase(self.all(active_only=False), "name", ref)

    @property
    def _get_methods(self):
        return self.from_search, self.from_identifier, self.from_name
