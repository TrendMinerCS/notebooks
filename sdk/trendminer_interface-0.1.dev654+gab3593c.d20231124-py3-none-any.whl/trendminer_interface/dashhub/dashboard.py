from trendminer_interface.base import ByFactory, kwargs_to_class
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory

from .tile import (TileFactory, TrendHubViewTileFactory,
                   CounterTileFactory, TableTileFactory,
                   GanttTileFactory, MonitorTileFactory,
                   ExternalContentTileFactory, CurrentValueTileFactory)


class Dashboard(WorkOrganizerObject):
    """TrendMiner dashboard (DashHub view)

    Attributes
    ----------
    live : bool
        Whether the dashboard is updating live
    scrollable : bool
        Whether the dashboard is scrollable
    tiles : list
        Tiles that are on the dashboard
    """
    content_type = "DASHBOARD"
    tiles = ByFactory(TileFactory, "list")

    # pylint: disable=too-many-arguments
    def __init__(
            self,
            client,
            identifier,
            name,
            description,
            folder,
            owner,
            last_modified,
            tiles,
            live,
            scrollable,
    ):

        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.live = live
        self.scrollable = scrollable
        self.tiles = tiles

    def _json_data(self):
        return {
            "autoRefreshEnabled": self.live,
            "scrollable": self.scrollable,
            "tiles": self.tiles,
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return self.client.dashboard.from_identifier(self.identifier)


class DashboardFactory(WorkOrganizerFactory):
    """Factory for initializing and retrieving dashboards"""
    tm_class = Dashboard

    def __call__(self,
                 tiles,
                 name='New Dashboard',
                 description='',
                 folder=None,
                 live=False,
                 scrollable=False,
                 ):
        """Initialize a new dashboard

        Parameters
        ----------
        tiles : list
            Tiles to add to the dashboard
        name : str, default "New Dashboard"
            Name of the dashboard
        description : str, optional
            Dashboard description
        folder : Folder or str
            Folder in which the dashboard needs to be saved
        live : bool
            Whether the dashboard will be updated live
        scrollable : bool
            Whether the dashboard needs to be scrollable

        Returns
        -------
        Dashboard
        """

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            tiles=tiles,
            live=live,
            scrollable=scrollable,
        )

    @kwargs_to_class
    def _from_json(self, data):
        """Enriched response json to dashboard

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        Dashboard
        """
        return {
            **self._json_to_kwargs_base(data),
            "live": data["data"]["autoRefreshEnabled"],
            "tiles": [
                TileFactory(client=self.client)._from_json(tile)
                for tile in data["data"]["tiles"]
            ],
            "scrollable": data["data"]["scrollable"],
        }

    @property
    def trend(self):
        """TrendHub view tile factory

        Returns
        -------
        TrendHubViewTileFactory
        """
        return TrendHubViewTileFactory(client=self.client)

    @property
    def count(self):
        """ContextHub view counter tile factory

        Returns
        -------
        CounterTileFactory
        """
        return CounterTileFactory(client=self.client)

    @property
    def table(self):
        """ContextHub view table tile factory

        Returns
        -------
        TableTileFactory
        """
        return TableTileFactory(client=self.client)

    @property
    def gantt(self):
        """ContextHub view gantt tile factory

        Returns
        -------
        GanttTileFactory
        """
        return GanttTileFactory(client=self.client)

    @property
    def monitor(self):
        """Monitor tile factory

        Returns
        -------
        MonitorTileFactory
        """
        return MonitorTileFactory(client=self.client)

    @property
    def external(self):
        """External content tile factory

        Returns
        -------
        ExternalContentTileFactory
        """
        return ExternalContentTileFactory(client=self.client)

    @property
    def values(self):
        """Current value tile factory

        Returns
        -------
        CurrentValueTileFactory
        """
        return CurrentValueTileFactory(client=self.client)
