import numpy as np

from datetime import datetime, timedelta

from trendminer_interface.authentication import Authenticated

from .interval import Interval, IntervalFactory
from .period import PeriodFactory
from .datetime_factory import DatetimeFactory
from .timedelta_factory import TimedeltaFactory


class TimeFactory(Authenticated):
    """Factory with some time-related methods, also serving as parentto other time-related factories

    All outcomes are given in the client timezone
    """

    def now(self):
        """Current time

        Returns
        -------
        now : datetime
            The current time
        """
        return datetime.now(tz=self.client.tz)

    @property
    def datetime(self):
        """Datetime factory for easily generating datetime objects

        Can be called directly to generate a datetime

        Returns
        -------
        DatetimeFactory
        """
        return DatetimeFactory(client=self.client)

    @property
    def timedelta(self):
        """Timedelta factory for easily generating timedeltas

        Can be called directly to generate a timedelta.

        Returns
        -------
        TimedeltaFactory
        """
        return TimedeltaFactory(client=self.client)

    def slice(self, *args, is_open=False):
        """Creates a slice from variable inputs

        The slice factory generates either a period or an interval, depending on the input. This factory can be used
        when user inputs can be both periods or an interval.

        It is first attempted to generate a Period instance. When that fails an Interval is generated.

        Parameters
        ----------
        args : Any
            Variable inputs from which either a Period or an Interval can be generated
        is_open : bool, default False
            Whether the slice is open-ended (e.g., a currently ongoing search result)

        Returns
        -------
        slice : Period or Interval
            Output as either a Period or an Interval
        """
        try:
            return self.period(duration=args[0])
        except ValueError:
            return self.interval(*args, is_open=is_open)

    @property
    def period(self):
        """Period factory for generating periods

        Can be called directly to generate a period

        Returns
        -------
        PeriodFactory
        """
        return PeriodFactory(client=self.client)

    @property
    def interval(self):
        """Interval factory for generating intervals

        Returns
        -------
        IntervalFactory
        """
        return IntervalFactory(client=self.client)

    def all(self):
        """Retrieve the full interval from the appliance index horizon until now

        Returns
        -------
        Interval
            The full interval available on the appliance
        """
        return Interval(client=self.client, start=self.client.index_horizon, end=self.now(), is_open=False)

    def _round(self, time, resolution, fun):
        for getter in [self.datetime, self.timedelta, self.interval]:
            try:
                time = getter(time)
                break
            except (ValueError, AttributeError):
                pass

        resolution = self.timedelta(resolution) or self.client.resolution

        if isinstance(time, datetime):
            ts = fun((time.timestamp()+time.utcoffset().total_seconds())/resolution.total_seconds())*resolution.total_seconds()
            return datetime.fromtimestamp(ts, tz=time.tzinfo) - time.utcoffset()

        elif isinstance(time, timedelta):
            seconds = fun(time.total_seconds()/resolution.total_seconds())*resolution.total_seconds()
            return timedelta(seconds=seconds)

        elif isinstance(time, Interval):
            start = self._round(time.start, resolution=resolution, fun=fun)
            end = self._round(time.end, resolution=resolution, fun=fun)
            return self.interval(start, end)

        raise ValueError(time)

    def round(self, time, resolution=None):
        """Round a time-based object to a certain resolution

        For intervals, both the start and end time will be rounded independently.

        Parameters
        ----------
        time : datetime or timedelta or interval
            Time object to be rounded
        resolution : timedelta or Any, optional
            The resolution to round to. Defaults to appliance index resolution.

        Returns
        -------
        time : datetime or timedelta or interval
            Rounded time object
        """
        return self._round(time, resolution, round)

    def ceil(self, time, resolution=None):
        """Round a time-based object up to a certain resolution

        For intervals, both the start and end time will be rounded up independently.

        Parameters
        ----------
        time : datetime or timedelta or interval
            Time object to be rounded
        resolution : timedelta or Any, optional
            The resolution to round to. Defaults to appliance index resolution.

        Returns
        -------
        time : datetime or timedelta or interval
            Ceiled time object
        """
        return self._round(time, resolution, np.ceil)

    def floor(self, time, resolution=None):
        """Round a time-based object down to a certain resolution

        For intervals, both the start and end time will be rounded down independently.

        Parameters
        ----------
        time : datetime or timedelta or interval
            Time object to be rounded down
        resolution : timedelta or Any, optional
            The resolution to round to. Defaults to appliance index resolution.

        Returns
        -------
        time : datetime or timedelta or interval
            Floored time object
        """
        return self._round(time, resolution, np.floor)
