import abc

import pytz
from .factory import TimeFactory


class TimeClient(abc.ABC):
    """Client for time factory. Stores the timezone.

    Attributes
    ----------
    tz : timezone
    """
    def __init__(self, tz):
        self.tz = pytz.timezone(tz) if isinstance(tz, str) else tz

    @property
    def time(self):
        """Parent factory for time-related objects

        Returns
        -------
        TimeFactory
        """
        return TimeFactory(client=self)
