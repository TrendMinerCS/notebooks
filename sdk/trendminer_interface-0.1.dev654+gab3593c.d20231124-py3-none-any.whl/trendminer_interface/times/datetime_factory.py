import pandas as pd

from datetime import datetime

from trendminer_interface.base import LazyAttribute
from trendminer_interface.times.parsers import string_to_datetime
from trendminer_interface.authentication import Authenticated
from trendminer_interface import _input as ip


class DatetimeFactory(Authenticated):
    """Factory for creating datetimes"""
    tm_class = datetime

    def __call__(self, t):
        """Convert input into datetime

        None and lazy values are returned without conversion.

        Parameters
        ----------
        t : Any
            Input to be converted into datetime

        Returns
        -------
        datetime or None or LazyAttribute
        """
        if t is None or isinstance(t, LazyAttribute):
            return t

        if isinstance(t, str):
            t = string_to_datetime(t)

        if isinstance(t, (int, float)):
            t = datetime.fromtimestamp(t)

        if isinstance(t, pd.Timestamp):
            t = t.to_pydatetime()

        if t.tzinfo is None:
            t = self.client.tz.localize(t)
        else:
            t = t.astimezone(self.client.tz)

        return t

    def list(self, times):
        """

        Parameters
        ----------
        times : Any
            Input to be converted into list of timestamps. If input is a list (or similar), every item is converted.
            A single input is wrapped to become a list

        Returns
        -------
        list of datetime
        """
        times = ip.any_list(times)
        return [self.__call__(t) for t in times]

