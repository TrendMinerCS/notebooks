from datetime import timedelta

from trendminer_interface.times.parsers import string_to_timedelta
from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import LazyAttribute
from trendminer_interface import _input as ip


class TimedeltaFactory(Authenticated):
    tm_class = timedelta

    @staticmethod
    def __call__(t):

        if isinstance(t, LazyAttribute):
            return t

        t = t or 0

        if isinstance(t, timedelta):
            return t

        if isinstance(t, (int, float)):
            return timedelta(seconds=t)

        if isinstance(t, str):
            return string_to_timedelta(t)

        raise ValueError(f'Unexpected input of type "{type(t)}" for timedelta')

    def list(self, times):
        times = ip.any_list(times)
        return [self.__call__(t) for t in times]

