from trendminer_interface.constants import MAX_GET_SIZE
from .node import Node


class Asset(Node):
    """An asset is a node in the asset framework that can be parent to attributes or other assets
    """
    component_type = "ASSET"

    def __init__(
            self,
            client,
            name,
            description,
            identifier,
            source,
            template,
            identifier_template,
            identifier_external,
            path_hex
    ):
        super().__init__(
            client=client,
            name=name,
            description=description,
            identifier=identifier,
            source=source,
            template=template,
            identifier_template=identifier_template,
            identifier_external=identifier_external,
            path_hex=path_hex
        )

    @property
    def children(self):
        """Direct children of the asset in the asset framework.

        Children can be attributes other assets.

        Returns
        -------
        List[Union[Asset, Attribute]]
            Direct children of the current asset, which can be assets or attributes.
        """
        params = {
            "size": MAX_GET_SIZE,
            "parentPath": self.path_hex
        }
        response = self.client.session.get(url=f"{self.endpoint}browse", params=params)

        return [self.client.asset._from_json(child) for child in response.json()["content"]]

    def __json__(self):
        return {}


# TODO: get rid of root asset
class RootAsset(Asset):
    """Artificial root asset instance. Has roots of Asset Frameworks as children."""
    def __init__(self, client):
        super().__init__(
            client=client,
            name="ROOT",
            description="Asset framework root. Artificial instance.",
            identifier=None,
            source=None,
            template=None,
            identifier_template=None,
            identifier_external=None,
            path_hex=None,
        )
