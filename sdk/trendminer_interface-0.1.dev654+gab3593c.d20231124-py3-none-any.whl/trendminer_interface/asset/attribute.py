from .node import Node
from trendminer_interface.visuals import Shiftable
from trendminer_interface.base import ByFactory
from trendminer_interface.tag import TagFactory


class Attribute(Node, Shiftable):
    # pylint: disable=too-many-arguments
    """Attributes are the end nodes of an asset framework, linking to a tag

    Attributes can be included in a TrendHub view directly.

    Attributes
    ----------
    tag : Tag
        The tag underlying the Attribute
    """
    component_type = "ATTRIBUTE"
    tag = ByFactory(TagFactory)

    def __init__(
            self,
            client,
            name,
            description,
            identifier,
            source,
            template,
            identifier_template,
            identifier_external,
            path_hex,
            tag,
            color,
            scale,
            shift,
            visible,
    ):
        Node.__init__(
            self=self,
            client=client,
            name=name,
            description=description,
            identifier=identifier,
            source=source,
            template=template,
            identifier_template=identifier_template,
            identifier_external=identifier_external,
            path_hex=path_hex,
        )

        Shiftable.__init__(
            self=self,
            color=color,
            scale=scale,
            shift=shift,
            visible=visible,
        )

        self.tag = tag

    @property
    def interpolation(self):
        """Underlying tag interpolation type

        Returns
        -------
        str
            "LINEAR" or "STEPPED"
        """
        return self.tag.interpolation

    def isnumeric(self):
        """Checks if the underlying tag is numeric (i.e., analog or discrete, rather than digital/string)

        Returns
        -------
        bool
            Whether the underlying tag is numeric
        """
        return self.tag.isnumeric()

    def __json__(self):
        return {
            "dataReference": {
                **Shiftable.__json__(self),
                "description": self.description,
                "id": self.identifier,
                "name": self.name,
                "path": self.path_hex,
                "type": self.component_type,
            },
            "type": "DATA_REFERENCE"
        }
