import abc
from .factory import AssetFactory


class AssetClient(abc.ABC):
    """Asset client"""
    @property
    def asset(self):
        """Factory for retrieving assets and attributes

        Returns
        -------
        AssetFactory
        """
        return AssetFactory(client=self)

