import abc
import posixpath

from trendminer_interface.base import TrendMinerFactory, LazyAttribute, MultiFactory, to_subfactory, kwargs_to_class
from trendminer_interface import _input as ip
from trendminer_interface.constants import MAX_GET_SIZE
from trendminer_interface.exceptions import AmbiguousResource, ResourceNotFound, FromJsonError
from trendminer_interface.tag import TagFactory
from trendminer_interface.visuals import default_shiftable_config

from .node import Node
from .asset import Asset, RootAsset
from .attribute import Attribute
from .framework import AssetFrameworkFactory


class NodeFactoryBase(TrendMinerFactory, abc.ABC):

    @kwargs_to_class
    def _from_json(self, data):
        if data.get("deleted", False) is True:
            return self._json_to_kwargs_deleted(data)
        else:
            return self._json_to_kwargs(data)

    def _json_to_kwargs(self, data):
        return {
                "name": data["name"],
                "description": data.get("description"),
                "identifier": data["identifier"],
                "source": AssetFrameworkFactory(client=self.client)._from_json(data["source"]),
                "template": data.get("template"),
                "identifier_template": data.get("templateId"),  # TODO: perhaps create template class?
                "identifier_external": data.get("externalId"),  # TODO: UPGRADE; no longer present in 2023.R1. Affects path
                "path_hex": data["paths"][0],
        }

    def _json_to_kwargs_deleted(self, data):
        return {
            "name": data["name"],
            "description": data.get("description"),
            "identifier": data["identifier"],
            "source": None,
            "template": data.get("template"),
            "identifier_template": data.get("templateId"),
            "identifier_external": data.get("externalId"),
            "path_hex": None,
        }

    def _json_to_kwargs_context_item(self, data):
        return {
                "name": data["name"],
                "description": data.get("description", ""),
                "identifier": data["reference"],
            }


class AssetFactoryBase(NodeFactoryBase):
    tm_class = Asset
    
    def _json_to_kwargs(self, data):
        if "ASSET_NO_PERMISSIONS" in data["permissions"]:
            return {
                "name": data["name"],
                "identifier": data["identifier"],
            }
        else:
            return super()._json_to_kwargs(data)

    @kwargs_to_class
    def _from_json_context_item(self, data):
        return self._json_to_kwargs_context_item(data)


class AttributeFactoryBase(NodeFactoryBase):
    tm_class = Attribute

    def _json_to_kwargs(self, data):
        super_kwargs = super()._json_to_kwargs(data)

        if super_kwargs["source"].af_type == "CSV":
            tag = TagFactory(client=self.client)._from_json(data["timeSeriesDefinition"])
        else:  # pragma: no cover
            # for PI AF, only name given
            tag = TagFactory(client=self.client)._from_json_name_only(data["data"])

        return {
            **super_kwargs,
            **default_shiftable_config,
            "tag": tag,
        }

    def _json_to_kwargs_deleted(self, data):
        return {
            **super()._json_to_kwargs_deleted(data),
            **default_shiftable_config,
            "tag": data.get("timeSeriesDefinition")
        }

    def _json_to_kwargs_datareference(self, data):
        return {
            "name": data["name"],
            "description": data.get("description"),
            "identifier": data["id"],
            "path_hex": data["path"],
            "color": data["options"]["color"],
            "scale": data["options"]["scale"],
            "shift": data["options"]["shift"]/1000,
            "visible": data["options"]["visible"]
        }

    @kwargs_to_class
    def _from_json_trendhub_group(self, data):
        return self._json_to_kwargs_datareference(data)

    @kwargs_to_class
    def _from_json_trendhub(self, data):
        return self._json_to_kwargs_datareference(data["dataReference"])

    @kwargs_to_class
    def _from_json_fingerprint(self, data):
        # TODO: we have information on the interpolation type that we are not using -> additional requests when calling __json__ to get the interpolation type that we are ignoring here
        return {
            "identifier": data["identifier"],
            "path_hex": data["properties"]["path"],
            "color": None,
            "scale": None,
            "shift": data["properties"]["shift"],
            "visible": data["properties"]["visible"],
        }

    @kwargs_to_class
    def _from_json_context_item(self, data):
        return {
            **super()._json_to_kwargs_context_item(data),
            **default_shiftable_config,
        }

    @kwargs_to_class
    def _from_json_current_value_tile(self, data):
        return {
            "identifier": data["componentIdentifier"],
            "path_hex": data["path"],
            **default_shiftable_config
        }

    # TODO: better way of implementing. Implementation on (another) base class?
    def from_path(self, ref):
        """Return Attribute from path"""
        attribute = AssetFactory(client=self.client).from_path(ref)
        if not isinstance(attribute, self.tm_class):
            raise TypeError
        return attribute

    def from_path_hex(self, ref):
        """Return Attribute from hex path"""
        attribute = AssetFactory(client=self.client).from_path_hex(ref)
        if not isinstance(attribute, self.tm_class):
            raise TypeError
        return attribute


# TODO: rename to NodeFactory. Then we can use AssetFactory and AttributeFactory
class AssetFactory(MultiFactory):
    """Implements methods for Asset and Attribute retrieval

    ``client.asset`` returns an AssetFactory instance
     """
    factories = {
        "ASSET": AssetFactoryBase,
        "ATTRIBUTE": AttributeFactoryBase,
    }

    @property
    def framework(self):
        """Interface to factory for retrieving and creating asset frameworks

        Returns
        -------
        AssetFrameworkFactory
            Factory for retrieving retrieving and creating asset frameworks
        """
        return AssetFrameworkFactory(client=self.client)

    @to_subfactory
    def _from_json(self, data):
        if "type" in data:
            return data["type"]
        elif "ASSET_NO_PERMISSIONS" in data["permissions"]:
            return "ASSET"  # only assets can have no permissions
        else:  # pragma: no cover
            raise ValueError

    def root(self):
        """Artificial root instance

        Returns
        -------
        RootAsset
        """
        return RootAsset(client=self.client)

    def from_identifier(self, ref):
        response = self.client.session.get(posixpath.join(Node.endpoint, ref))
        return self._from_json(response.json())

    # TODO: investigate if we can query path directly via rsql
    def from_path(self, ref):
        """Returns Asset or Attribute from path

        Parameters
        ----------
        ref : str
            Human readable path as text, e.g. "my_asset/my_subasset/my_attribute"

        Returns
        -------
        Asset or Attribute
            The asset or attribute at the given path
        """
        asset_name_list = [name for name in ref.split("/") if name != ""]
        asset = self.root()
        for asset_name in asset_name_list:
            asset = ip.object_match_nocase(asset.children, attribute="name", value=asset_name)
        return asset

    def from_path_hex(self, ref):
        """Returns Asset or Attribute from path with hex values

        Used for internal retrieval of Assets or Attributes

        Parameters
        ----------
        ref : str
            Hexagonal path as string, e.g. "0000025e.0000025f.00000260"

        Returns
        -------
        Asset or Attribute
            The asset or attribute at the given path
        """
        params = {"path": ref}
        response = self.client.session.get(Node.endpoint, params=params)
        content = response.json()["content"]
        if len(content) > 1:  # pragma: no cover
            raise AmbiguousResource(ref)
        if len(content) == 0:  # pragma: no cover
            raise ResourceNotFound(ref)
        return self._from_json(content[0])

    def by_rsql(self, query):
        """Executes RSQL query to the assets database

        Used by other functions to retrieve assets, though use cases could exist where a custom query is input directly.

        Parameters
        ----------
        query: str
            RSQL query, e.g. "name==my_asset"

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        data = {
            "query": query,
            "size": MAX_GET_SIZE
        }

        paginator = self.client.session.paginated(keys=["content"], json_params=True)
        content = paginator.post(
            url=f"{Node.endpoint}search",
            json=data,
        )
        return [self._from_json(data) for data in content]

    def _query_rsql(self, key, ref, frameworks):
        """Boilerplate for executing RSQL search method. Mainly adds filters on the asset frameworks to search."""
        query = f"{key}=='{ref}'"
        if frameworks is not None:
            frameworks = self.client.asset.framework.list(frameworks)
            identifier_str = ",".join([source.identifier for source in frameworks])
            query = query + f";source.identifier=in=('{identifier_str}')"
        return self.by_rsql(query=query)

    def by_template(self, ref, frameworks=None):
        """Search assets by a given template

        Parameters
        ---------
        ref : str
            Full template or template substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="template", ref=ref, frameworks=frameworks)

    def by_name(self, ref, frameworks=None):
        """Search assets by a given name

        Parameters
        ---------
        ref : str
            Full name or name substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="name", ref=ref, frameworks=frameworks)

    def by_description(self, ref, frameworks=None):
        """Search assets by a given description

        Parameters
        ---------
        ref : str
            Full description of description substring
        frameworks : list, optional
            Asset frameworks in which to search. By default, all accessible frameworks are searched.

        Returns
        -------
        List[Union[Asset, Attribute]]
            List of assets and attributes found by the query
        """
        return self._query_rsql(key="description", ref=ref, frameworks=frameworks)

    @property
    def _get_methods(self):
        return (
            self._subfactory("ATTRIBUTE").from_identifier,
            self._subfactory("ASSET").from_identifier,
            self.from_path_hex,
            self.from_path
        )

    @property
    def _search_methods(self):
        return self.by_name, self.by_description