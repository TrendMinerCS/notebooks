import abc
import posixpath
import functools

from requests.exceptions import HTTPError

from trendminer_interface import _input as ip
from trendminer_interface.authentication import Authenticated
from trendminer_interface.exceptions import ResourceNotFound, FromJsonError
from trendminer_interface.constants import MAX_GET_SIZE
from .lazy_loading import LazyAttribute


class TrendMinerFactory(Authenticated, abc.ABC):
    """Superclass for all factories instantiating new methods"""
    tm_class = None

    # TODO: from_identifier and _from_json should not be part of factory
    def from_identifier(self, ref):
        """Load an instance directly from its unique identifier

        Parameters
        ----------
        ref : str
            Unique identifier to the object on the appliance

        Returns
        -------
        Any
            The appliance object with the given unique identifier
        """
        try:
            link = posixpath.join(self._endpoint, ref)
        except TypeError:
            raise ResourceNotFound(ref)
        response = self.client.session.get(link)
        return self._from_json(response.json())

    @property
    def _endpoint(self):
        return self.tm_class.endpoint

    def _from_json(self, data):
        """Main from_json method

        Parameters
        ----------
        data : dict
            json structure returned from appliance

        Returns
        -------
        Any
            The assembled instance
        """
        raise NotImplementedError

    @property
    def _get_methods(self):
        """Methods to try to retrieve an instance from the appliance

        get methods always have the following syntax: `from_*`
        """
        return ()

    @property
    def _search_methods(self):
        """Methods by which to search instances on the appliance

        search methods always have the following syntax: `by_*`
        """
        return ()

    @classmethod
    def _correct_class(cls, ref):
        """Check if input is already of the correct class"""
        return isinstance(ref, cls.tm_class)

    def get(self, ref):
        """Get instance from any possible reference type

        Tries all methods in `_get_methods` in order to retrieve an instance from the appliance.

        The given input is simply returned if:
        - It is already an instance of the correct type
        - It is None
        - It is a LazyAttribute

        Parameters
        ----------
        ref : Any
            Reference by which a unique instance can be retrieved from the appliance

        Returns
        -------
        Any
            The instance pointed to by the given reference
        """

        if ref is None:
            return None

        if isinstance(ref, LazyAttribute):
            return ref

        # Ref is already of correct instance, return
        if self._correct_class(ref):
            return ref

        # Try all other implemented methods to return data
        for method in self._get_methods:
            try:
                return method(ref)
            except (ResourceNotFound, AttributeError):
                pass
            except HTTPError as err:
                if err.response.status_code not in [400, 404]:
                    raise err

        raise ResourceNotFound(f"No match for {ref} found")

    def search(self, ref, *args, **kwargs):
        """Search instances by any possible reference type

        Can execute multiple search methods as given by the `_search_methods` property, and return the collection of all
        results (without duplicates when multiple methods return overlapping instances).

        Parameters
        ----------
        ref : str
            String reference by which to call the search methods

        Returns
        -------
        list
            List of instances meeting the search criteria
        """
        results = [result for method in self._search_methods for result in method(ref, *args, **kwargs)]
        return ip.unique_by_attribute(results, attribute="identifier")

    def list(self, refs):
        """Retrieves instances from list of references

        Uses the `get` method on every item in the given list.

        Parameters
        ----------
        refs : list or Any
            list of references representing unique instances on the appliance. A single input is converted into a list
            of length 1.

        Returns
        -------
        list
            List of instances retrieved from given references
        """
        if isinstance(refs, LazyAttribute):
            return refs
        if isinstance(refs, (str, tuple)) or self._correct_class(refs):
            refs = [refs]
        refs = refs or []
        return [self.get(ref) for ref in refs]

    def all(self):
        """Retrieve all instances from the appliance

        Returns
        -------
        list
            List of all instances retrieved from the appliance
        """
        params = {"size": MAX_GET_SIZE}
        content = self.client.session.paginated(keys=["content"]).get(self._endpoint, params=params)
        return [self._from_json(data) for data in content]

    def _cache_key_ref(self, ref):
        """Cachetools key for methods with ref argument

        Caching factory methods conventionally has no effect as new factory classes are created on the fly. The key
        is thus set based on the client and the name of factory method (as well as the input, of course). This key
        function can be used for caching methods where ref is the only input.

        Cache decorator should follow this syntax:
        @cachetools.cached(key=TrendMinerFactory._cache_get)

        Parameters
        ----------
        ref : Any
            Input to the cached method

        Returns
        -------
        key: tuple
            Cache key
        """

        # Handling for object inputs
        if isinstance(ref, Authenticated):
            ref = hash(ref)

        key = hash(self.client), self.__class__.__name__, ref

        return key

    def _cache_key_no_args(self):
        """Cachetools key for methods without arguments"""
        return self._cache_key_ref(ref=None)


def kwargs_to_class(method):
    """Decorator function that handles turning keyword arguments into a TrendMiner class instance

    Intended to decorate _from_json* methods on TrendMiner Factory classes. Creates an instance in which attributes not
    provided through the output dict are turned into LazyAttribute instances. This shortens our code as we no longer
    explicitly need to set our lazy attributes. Also allows the addition of a `from_list` parameter which will iterate
    the base method to turn a list of inputs into a list of instances. Prevents us from having to use list comprehension
    in our methods.

    Parameters
    ----------
    method : callable
        Method turning json input into a dict of kwargs usable for creating a class instances

    Returns
    -------
    callable
    """

    @functools.wraps(method)
    def inner(*args, **kwargs):
        """Decorator inner function. Creates a class instance or list of class instances."""

        self = args[0]
        try:
            data = args[1]
        except IndexError:
            data = kwargs["data"]

        values = method(self, data)

        output = {
            kw: LazyAttribute(name=kw)
            for kw in self.tm_class.__init__.__code__.co_varnames
        }
        output.pop("self")
        output.update({"client": self.client, **values})
        return self.tm_class(**output)
    return inner


class QuerySearchFactory(TrendMinerFactory, abc.ABC):
    """Factory for objects which can search using sql-style queries"""

    def _query_params(self, params):
        """Execute an sql-style query on the TrendMiner appliance

        Parameters
        ----------
        params : dict
            Request parameters. Needs to contain the sql query under the "query" key.

        Returns
        -------
        list
            List of instances matching the given query.
        """
        params.update({"size": MAX_GET_SIZE})
        content = self.client.session.paginated(keys=["content"]).get(self._endpoint + "search", params=params)
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        """Sends sql query where we search for a single given key to match a value

        Parameters
        ----------
        ref : str
            The value to match
        search_key : str
            The key which needs to match this value

        Returns
        -------
        list
            List of instances where the given key matches the given value
        """
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _query_in(self, refs, search_key):
        """Sends sql query where we search for a single given key to be any of a number of given values

        Parameters
        ----------
        refs : list of str
            The list of values the key should match one of
        search_key : str
            The key with which to match the value

        Returns
        -------
        list
            List of instances where the given key matches one of the given values
        """
        queries = ",".join([f"'{ref}'" for ref in refs])
        params = {"query": f"{search_key}=in=({queries})"}
        return self._query_params(params)
