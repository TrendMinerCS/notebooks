import abc
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory


class TagBuilderTag(WorkOrganizerObject, abc.ABC):
    """Base class for tag builder tags"""

    def delete(self):
        """Delete the formula tag

        Tag is automatically renamed before (soft) deletion to keep the original name available for new tags.
        """
        # Rename before deleting to free the name
        self.name = "api_delete_" + self.client.time.now().isoformat()
        self.put()
        super().delete()

    @property
    def tag(self):
        """The tag made by the formula

        Returns
        -------
        Tag
        """
        return self.client.tag.from_name(self.name)
