from trendminer_interface.base import MultiFactory, to_subfactory
from trendminer_interface.tag import TagFactory
from trendminer_interface.asset import AssetFactoryBase, AttributeFactoryBase, AssetFactory


class ComponentFactory(MultiFactory):
    """Factory for retrieving ContextHub componenets"""
    factories = {
        "TAG": TagFactory,
        "ASSET": AssetFactoryBase,
        "ATTRIBUTE": AttributeFactoryBase,
    }

    @property
    def _get_methods(self):
        return (
            self._subfactory("TAG").from_identifier,
            AssetFactory(client=self.client).from_identifier,  # general; works for asset and attribute
            self._subfactory("TAG").from_name,
            AssetFactory(client=self.client).from_path_hex,  # general; works for asset and attribute
            AssetFactory(client=self.client).from_path,  # general; works for asset and attribute
        )

    @to_subfactory
    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]

    @to_subfactory
    def _from_json_context_item(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]

    @to_subfactory
    def _from_json_current_value_tile(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data["type"]
