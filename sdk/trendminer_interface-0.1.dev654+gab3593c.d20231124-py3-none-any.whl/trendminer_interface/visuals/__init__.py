from .color import ColoredObject
from .scalable import Scalable
from .shiftable import Shiftable, default_shiftable_config
