import abc
from copy import deepcopy

from trendminer_interface.times import TimedeltaFactory
from trendminer_interface.base import ByFactory

from .scalable import Scalable


class Shiftable(Scalable, abc.ABC):
    """An object that can be shifted and hidden on a chart

    Parameters
    ----------
    shift: timedelta, optional
        Object shift, impacts all data operations
    visible: bool, optional
        Whether object visible on the chart or hidden
    """

    shift = ByFactory(TimedeltaFactory, "__call__")

    def __init__(self, color, scale, shift, visible):
        Scalable.__init__(self=self, color=color, scale=scale)
        self.shift = shift
        self.visible = visible

    def shift_by(self, shift):
        """Returns shifted copy of instance"""
        instance = deepcopy(self)
        instance.shift = self.shift + TimedeltaFactory(client=self.client)(shift)
        return instance

    @property
    @abc.abstractmethod
    def interpolation(self):
        pass

    @property
    def shift_ms(self):
        return int(self.shift.total_seconds()*1000)

    def __json__(self):
        payload = Scalable.__json__(self=self)
        payload["options"] = {
            **payload["options"],
            "shift": self.shift_ms,
            "visible": self.visible,
            "interpolation": self.interpolation,
        }
        return payload


# Default configuration for _from_json methods where no info is present
default_shiftable_config = {
    "color": None,
    "scale": None,
    "shift": 0,
    "visible": True,
}
