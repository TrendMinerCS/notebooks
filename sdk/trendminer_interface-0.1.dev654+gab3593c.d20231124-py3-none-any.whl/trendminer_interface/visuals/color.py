import abc

from trendminer_interface.base import AsColor


class ColoredObject(abc.ABC):
    """An object that can have a color

    Parameters
    ----------
    color: Color or str, optional
        Chart display color. If no color is chosen, a random color is selected from a list of distinguishable
        colors.
    """

    color = AsColor(choose=True)

    def __init__(self, color=None):
        self.color = color

    @property
    def api_color_ch(self):
        """Color string as used in ContextHub requests

        This representation does not contain a leading '#'

        Returns
        -------
        str
        """
        return self.color.hex_l[1:].upper()

    @property
    def api_color(self):
        """Color string as used in requests

        Returns
        -------
        str
        """
        return self.color.hex_l.upper()
