from trendminer_interface.base import Serializable, TrendMinerFactory, ByFactory
from .data_reference_factory import DataReferenceFactory
from trendminer_interface.visuals.scalable import Scalable
from trendminer_interface.tag import Tag


class EntryGroup(Serializable, Scalable):
    """A grouping of two or more tags and/or attributes in TrendHub

    Grouped tags and attributes are displayed together, on the same scale

    Attributes
    ----------
    entries : list
        List of Tag and Attribute instances in the group.
    name : str
        Name of the group. Displayed in TrendHub.
    """
    entries = ByFactory(DataReferenceFactory, "list")

    def __init__(self, client, entries, name, scale=None, color=None):
        Serializable.__init__(self, client=client)
        Scalable.__init__(self, color=color, scale=scale)
        self.entries = entries
        self.name = name

    @property
    def tags(self):
        """Get all underlying tags.

        For attribute entries, the underlying tag is given, while tag entries are simply returned as is

        Returns
        -------
        list of Tag
        """
        return [entry if isinstance(entry, Tag) else entry.tag for entry in self.entries]

    def __json__(self):
        return {
            "group": {
                "dataReferences": [entry.__json__()["dataReference"] for entry in self.entries],
                "name": self.name,
                **Scalable.__json__(self),
            },
            "type": "GROUP",
        }

    def __repr__(self):
        return f"<< GROUP | {self.name} >>"


class EntryGroupFactory(TrendMinerFactory):
    tm_class = EntryGroup

    def __call__(self, entries, name="New Group", scale=None, color=None):
        """
        Create a new TrendHub group of tags and attributes

        Parameters
        ----------
        entries : list
            Tags and/or attributes
        name : str, default "New Group"
            Name of the group, as displayed in TrendHub.
        scale : list of float, optional
            [min, max] scale on the chart. Autoscaled when no value is provided.
        color : Color or str, optional
            Color of the group. This value does not have any effect at this point, as the entries in the group have
            their own colors.

        Returns
        -------
        EntryGroup
        """
        return self.tm_class(
            client=self.client,
            entries=entries,
            name=name,
            scale=scale,
            color=color,
        )

    def _from_json_trendhub(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        EntryGroup
        """
        data = data["group"]
        return self.tm_class(
            client=self.client,
            entries=[
                DataReferenceFactory(client=self.client)._from_json_trendhub_group(entry)
                for entry in data["dataReferences"]
            ],
            name=data["name"],
            scale=data["options"]["scale"],
            color=data["options"]["color"],
        )

    @property
    def _get_methods(self):
        return ()
