from trendminer_interface.base import LazyAttribute, ByFactory, HasOptions, kwargs_to_class
from trendminer_interface.search.base import Search, SearchBaseFactory
from trendminer_interface.search.calculation import SearchCalculationFactory
from trendminer_interface.times import TimedeltaFactory

from trendminer_interface import _input as ip

from .query import SearchQueryFactory


class ValueBasedSearch(Search):
    content_type = "VALUE_BASED_SEARCH"
    search_type = "valuebased"

    queries = ByFactory(SearchQueryFactory, "list")
    duration = ByFactory(TimedeltaFactory, "__call__")
    operator = HasOptions(["AND", "OR"])

    def __init__(self,
                 client,
                 identifier,
                 identifier_monitor,
                 name,
                 description,
                 folder,
                 owner,
                 last_modified,
                 queries,
                 calculations,
                 duration,
                 operator,
                 ):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=description,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified,
                         calculations=calculations,
                         identifier_monitor=identifier_monitor
                         )

        self.queries = queries
        self.duration = duration
        self.operator = operator

    @property
    def tags(self):
        return [query.tag for query in self.queries]

    def _full_instance(self):
        # Search from monitor info, which does not have the search identifier
        if "identifier" in self.lazy:
            if "name" in self.lazy:
                matches = self.client.search.value.all()
            else:
                matches = self.client.search.value.by_name(self.name)
            return ip.object_match_nocase(matches, "identifier_monitor", self.identifier_monitor)

        else:
            return self.client.search.value.from_identifier(self.identifier)

    @property
    def _content_blueprint(self):
        raise NotImplementedError

    def _json_definition(self):
        return {
            **super()._json_definition(),
            "queries": self.queries,
            "parameters": {
                "minimumDuration": int(self.duration.total_seconds()),
                "operator": self.operator,
            },
        }

    def _json_data_queries(self):
        query_data = []

        for query in self.queries:
            value = query.values_numeric
            operator = query.condition
            if operator.lower() == "constant":
                value = ""
            elif query.tag.isnumeric():
                value = value[0]
                if value == int(value):
                    value = int(value) # converting to int when possible avoids phantom 'unsaved changes' in ux
                value = str(value)
            elif operator == "=":
                operator = "In set"

            query_data.append(
                {
                    "interpolationType": query.tag.interpolation_data,
                    "operator": operator,
                    "shift": int(query.tag.shift.total_seconds()),
                    "tagName": query.tag.name,
                    "value": value
                }
            )

        return query_data

    def _json_data(self):
        return {
            "calculations": self.calculations,
            "minimumIntervalLength": str(int(self.duration.total_seconds())),
            "operator": self.operator,
            "queries": self._json_data_queries(),
        }


class ValueBasedSearchFactory(SearchBaseFactory):
    tm_class = ValueBasedSearch

    def __call__(
            self,
            queries,
            name="New Search",
            description="",
            folder=None,
            duration=None,
            calculations=None,
            operator="AND",
    ):
        duration = duration or 2*self.client.resolution.total_seconds()

        return self.tm_class(
            client=self.client,
            identifier=None,
            identifier_monitor=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            queries=queries,
            duration=duration,
            calculations=calculations,
            operator=operator,
        )

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier_monitor": data["data"]["id"],
            "calculations": [
                SearchCalculationFactory(client=self.client)._from_json(calc) for calc in data["data"]["calculations"]
            ],
            "duration": float(data["data"]["minimumIntervalLength"]),
            "operator": data["data"]["operator"],
            "queries": [
                SearchQueryFactory(client=self.client)._from_json(query)
                for query in data["data"]["queries"]
                ],
        }
