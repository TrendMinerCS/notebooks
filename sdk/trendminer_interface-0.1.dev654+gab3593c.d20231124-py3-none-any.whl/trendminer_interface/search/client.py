import abc

from trendminer_interface.base import MultiFactory, to_subfactory
from .value import ValueBasedSearchFactory
from .similarity import SimilaritySearchFactory


class SearchClient(abc.ABC):
    """Search client"""
    @property
    def search(self):
        """Parent factory for all search types"""
        return SearchFactory(client=self)


search_factories = [ValueBasedSearchFactory, SimilaritySearchFactory]


class SearchFactory(MultiFactory):
    """Parent factory for all search types"""

    factories = {
        factory.tm_class.search_type: factory
        for factory in [
            ValueBasedSearchFactory,
            SimilaritySearchFactory,
        ]
    }

    @property
    def value(self):
        """Factory for value-based searches

        Returns
        -------
        ValueBasedSearchFactory
        """
        return ValueBasedSearchFactory(client=self.client)

    @property
    def similarity(self):
        """Factory for similarity searches

        Returns
        -------
        SimilaritySearchFactory
        """
        return SimilaritySearchFactory(client=self.client)

    @to_subfactory
    def _from_json_monitor(self, data):
        return data["type"]

    @to_subfactory
    def _from_json_monitor_nameless(self, data):
        return data["type"]
