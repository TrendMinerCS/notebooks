import abc
import time

from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.constants import SEARCH_REFRESH_SLEEP, MAX_GET_SIZE
from trendminer_interface.times import IntervalFactory
from trendminer_interface.base import ByFactory, kwargs_to_class

from .calculation import SearchCalculationFactory


class Search(WorkOrganizerObject, abc.ABC):
    """Base class for searches

    Attributes
    ----------
    search_request_identifier : str
        UUID of the latest search request, required to extract the search results. Automatically added/updated when
        executing the search.
    calculations : list of SearchCalculation
        Calculations added to the search
    identifier_monitor : int
        Identifier of the monitor matching the search. Added when the search is saved.
    """
    search_type = None
    refresh_sleep = SEARCH_REFRESH_SLEEP

    interval = ByFactory(IntervalFactory, "__call__")
    calculations = ByFactory(SearchCalculationFactory, "list")

    def __init__(
            self,
            client,
            identifier,
            identifier_monitor,
            name,
            description,
            folder,
            owner,
            last_modified,
            calculations,
    ):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=description,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified
                         )

        self.search_request_identifier = None
        self.calculations = calculations
        self.identifier_monitor = identifier_monitor

    @abc.abstractmethod
    def _full_instance(self):
        return super()._full_instance()

    @property
    @abc.abstractmethod
    def tags(self):
        """Tags used in the search"""
        pass

    def _post_updates(self, response):
        super()._post_updates(response)
        self.identifier_monitor = response.json()["data"]["id"]

    def _json_definition(self):
        return {
            "calculations": self.calculations,
            "type": self.content_type,
        }

    def execute(self, interval='6M', excluded_intervals=None):
        """Execute the search on the server

        Does not retrieve the results. Only retrieves the `search_request_identifier` attribute, allowing the results
        can be extracted with the `extract_results` method.

        Parameters
        ----------
        interval : Interval or Any, default '6M'
            Interval to search in
        excluded_intervals : list of Interval or Any
            Intervals to filter out while searching
        """
        interval = self.client.time.interval(interval)
        excluded_intervals = self.client.time.interval.list(excluded_intervals)
        json_search = {
            "contextTimePeriod": interval,
            "definition": self._json_definition(),
            "exclusionPeriods": excluded_intervals,
        }
        response = self.client.session.post("/compute/search-requests", json=json_search)
        self.search_request_identifier = response.json()["id"]

    def extract_results(self):
        """Extract the results of the latest search execution

        Uses the `search_request_identifier` attribute to extract the results. Search must have been executed first
        using the `execute` method, and execution must have finished. Readyness can be checked with the `ready` method.

        Returns
        -------
        list of Interval
            Search results, including calculations
        """
        content = self.client.session.paginated(keys=["content"]).get(
            f"/compute/search-requests/{self.search_request_identifier}/results",
            params={"size": MAX_GET_SIZE},
        )

        results = [self.client.time.interval._from_json_search_result(data) for data in content]
        results = sorted(results, key=lambda x: x.start)  # oldest result first

        # null results not part of json result, set them manually
        # convert digital tag results
        for calculation in self.calculations:
            numeric = calculation.tag.isnumeric()
            if not numeric:
                states = calculation.tag.state_dict
            for result in results:
                result.data.setdefault(calculation.key)
                if not numeric and isinstance(result.data[calculation.key], int):
                    result.data[calculation.key] = states.get(result.data[calculation.key])

        return results

    def ready(self):
        """Checks wether the latest search execution has finished

        Results can only be retrieved after execution has finished on the server.

        Returns
        -------
        ready : bool
            Wether the latest search execution has finished
        """
        response = self.client.session.get(
            f"/compute/search-requests/{self.search_request_identifier}",
        )
        return response.json()["status"].upper() != "IN_PROGRESS"

    def get_results(self, interval="6M", excluded_intervals=None):
        """Executes search and extracts results from the server

        Convenience method for the user. Combines the `execute` and `extract_results` methods. Waits before execution
        has finished (checked in a loop) before the extraction to avoid errors. Downside is that code execution is
        halted (from doing things not requiring the search results) while search execution on the appliance is ongoing.

        Parameters
        ----------
        interval : Interval or Any, default '6M'
            Interval to search in
        excluded_intervals : list of Interval or Any
            Intervals to filter out while searching

        Returns
        -------
        list of Interval
            Search results, including calculations and potentially similarity score (interval["score"]). Sorted always
            from oldest to newest.
        """
        self.execute(interval=interval, excluded_intervals=excluded_intervals)
        time.sleep(self.refresh_sleep)
        while not self.ready():
            time.sleep(self.refresh_sleep)
        return self.extract_results()


class SearchBaseFactory(WorkOrganizerFactory, abc.ABC):
    """Base factory for searches"""

    def _json_to_kwargs_monitor(self, data):
        username = data.get("username", self.client.username)
        owner = self.client.user._from_json_name_only(username)
        return {
            "identifier_monitor": data["searchId"],
            "owner": owner,
        }

    @kwargs_to_class
    def _from_json_monitor(self, data):
        """Construct search from monitor json (/bySearchId)"""
        return {
            **self._json_to_kwargs_monitor(data),
            "name": data["name"],
        }

    @kwargs_to_class
    def _from_json_monitor_nameless(self, data):
        """Construct search from direct call to monitor ID. Does not retrieve monitor name."""
        return self._json_to_kwargs_monitor(data)
