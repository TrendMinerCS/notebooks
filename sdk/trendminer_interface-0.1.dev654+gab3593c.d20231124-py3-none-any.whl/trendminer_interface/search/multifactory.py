from trendminer_interface.base import MultiFactory, to_subfactory

from .similarity import SimilaritySearchFactory
from .value import ValueBasedSearchFactory


class MonitorSearchFactory(MultiFactory):
    """Factory for instantiating any type of search from a monitor"""

    factories = {
        factory.tm_class.search_type: factory
        for factory in [
            ValueBasedSearchFactory,
            SimilaritySearchFactory,
        ]
    }

    @to_subfactory
    def _from_json_monitor(self, data):
        return data["type"]

    @to_subfactory
    def _from_json_monitor_nameless(self, data):
        return data["type"]
