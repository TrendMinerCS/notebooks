from trendminer_interface.base import LazyAttribute, ByFactory
from trendminer_interface.search.base import Search, SearchBaseFactory, kwargs_to_class
from trendminer_interface.search.calculation import SearchCalculationFactory
from trendminer_interface.times import IntervalFactory, time_json
from trendminer_interface import _input as ip

from .query import SimilaritySearchQueryFactory


class SimilaritySearch(Search):
    """Similarity search

    Similarity score of search result intervals are given under interval["score"]

    Attributes
    ----------
    queries : list of SimilaritySearchQuery
        Similarity search queries
    interval : Interval
        Focus chart interval used for the search
    threshold : float
        Similarity cutoff value (0-100)
    """
    content_type = "SIMILARITY_SEARCH"
    search_type = "similarity"
    interval = ByFactory(IntervalFactory, "__call__")
    queries = ByFactory(SimilaritySearchQueryFactory, "list")

    def __init__(self,
                 client,
                 identifier,
                 identifier_monitor,
                 name,
                 description,
                 folder,
                 owner,
                 last_modified,
                 interval,
                 threshold,
                 queries,
                 calculations,
                 ):
        super().__init__(client=client,
                         identifier=identifier,
                         name=name,
                         description=description,
                         folder=folder,
                         owner=owner,
                         last_modified=last_modified,
                         calculations=calculations,
                         identifier_monitor=identifier_monitor
                         )

        self.interval = interval
        self.queries = queries
        self.threshold = threshold

    @property
    def tags(self):
        return [query.source for query in self.queries]

    def _full_instance(self):
        # Search from monitor info, which does not have the search identifier
        if "identifier" in self.lazy and self.identifier_monitor:
            if "name" in self.lazy:
                matches = self.client.search.similarity.all()
            else:
                matches = self.client.search.similarity.by_name(self.name)
            return ip.object_match_nocase(matches, "identifier_monitor", self.identifier_monitor)

        else:
            return self.client.search.similarity.from_identifier(self.identifier)

    @property
    def _content_blueprint(self):
        raise NotImplementedError

    def _json_definition(self):
        return {
            **super()._json_definition(),
            "queries": [query._json_search(self.interval) for query in self.queries],
            "parameters": {
                "detectionThreshold": self.threshold,
                "focusTimePeriod": self.interval.__json__(),
            },
        }

    def _json_data(self):
        return {
            "calculations": self.calculations,
            "cutOffPercentage": self.threshold,
            "originalEndDate": time_json(self.interval.end),
            "originalStartDate": time_json(self.interval.start),
            "tags": [query._json_save(self.interval) for query in self._queries]
        }


class SimilaritySearchFactory(SearchBaseFactory):
    """Factory for generating and retrieving similarity searches"""
    tm_class = SimilaritySearch

    def __call__(
            self,
            queries,
            interval,
            threshold=70,
            name="New Search",
            description="",
            folder=None,
            calculations=None,
    ):
        """Instantiate a new similarity search

        Parameters
        ----------
        queries : list of SimilaritySearchQuery or list of Any
            Similarity search queries
        interval : Interval or Any
            Focus chart interval used for the search
        threshold : float
            Similarity cutoff value (0-100)
        name : str
            Name of the search; only relevant when saving
        description : str
            Description of the search; only relevant when saving
        folder : Folder or Any
            Folder to save the search in
        calculations : list of SearchCalculation or Any
            Calculations to perform on the search

        Returns
        -------
        SimilaritySearch
        """
        return self.tm_class(
                 client=self.client,
                 identifier=None,
                 identifier_monitor=None,
                 name=name,
                 description=description,
                 folder=folder,
                 owner=None,
                 last_modified=None,
                 interval=interval,
                 threshold=threshold,
                 queries=queries,
                 calculations=calculations,
                 )

    @property
    def query(self):
        """Factory for similarity search queries"""
        return SimilaritySearchQueryFactory(client=self.client)

    @kwargs_to_class
    def _from_json(self, data):
        """From json with full info"""
        return {
            **self._json_to_kwargs_base(data),
            "identifier_monitor": data["data"]["id"],
            "calculations": [
                SearchCalculationFactory(client=self.client)._from_json(calc)
                for calc in data["data"]["calculations"]
            ],
            "queries": [
                SimilaritySearchQueryFactory(client=self.client)._from_json(tag)
                for tag in data["data"]["tags"]
            ],
            "threshold": data["data"]["cutOffPercentage"],
            "interval": IntervalFactory(client=self.client)(
                data["data"]["originalStartDate"],
                data["data"]["originalEndDate"]
            ),
        }
