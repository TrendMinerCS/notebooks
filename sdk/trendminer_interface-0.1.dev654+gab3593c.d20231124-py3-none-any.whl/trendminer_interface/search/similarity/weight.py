import math

from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import Serializable, ByFactory, TrendMinerFactory, LazyAttribute
from trendminer_interface.times import IntervalFactory, time_json


class SimilaritySearchWeight(Serializable):
    """Weighted periods used in similarity searches

    Attributes
    ----------
    interval : Interval
        The weighted interval
    weight : int
        The weight (1-5) assigned to the interval
    """
    interval = ByFactory(IntervalFactory, method="__call__")

    def __init__(self, client, interval, weight):
        """"""
        super().__init__(client=client)
        self.interval = interval
        self.weight = weight

    def _json_search(self):
        return {
            "start": time_json(self.interval.start),
            "end": time_json(self.interval.end),
            "weight": round(3**self.weight)
        }

    def __json__(self):
        return {
            **self.interval.__json__(),
            "weight": round(3**self.weight)
        }


class SimilaritySearchWeightFactory(TrendMinerFactory):
    """Factory for creating similarity search weights"""
    tm_class = SimilaritySearchWeight

    def __call__(self, interval, weight):
        """Create a new similarity search weight

        Parameters
        ----------
        interval : Interval or Any
            Interval for which the weight is assigned
        weight : int
            Value from 1 to 5 giving the additional weight to this interval

        Returns
        -------
        SimilaritySearchWeight
        """
        return self.tm_class(
            client=self.client,
            interval=interval,
            weight=weight,
        )

    def from_identifier(self, ref):
        raise NotImplementedError

    def from_tuple(self, ref):
        """Generate list of weights from a list of tuples

        Parameters
        ----------
        ref : tuple
            (Interval, int) input.

        Returns
        -------
        SimilaritySearchWeight
        """
        return self.__call__(interval=ref[0], weight=ref[1])

    # def list(self, refs):
    #     """Retrieve list of similarity search weights
    #
    #     Parameters
    #     ----------
    #     refs : Any
    #         List or dictionary convertible to list of weights
    #
    #     Returns
    #     -------
    #     list of SimilaritySearchWeight
    #     """
    #     if refs is None:
    #         return []
    #
    #     elif isinstance(refs, LazyAttribute):
    #         return refs
    #
    #     elif isinstance(refs, dict):
    #         return self.from_tuples(refs)
    #
    #     else:
    #         if isinstance(refs, (str, self.tm_class, tuple)):
    #             refs = [refs]
    #
    #         for ref in refs:
    #             assert isinstance(ref, SimilaritySearchWeight)
    #
    #         return refs

    def _from_json(self, data):
        """Get weight from json structure

        Parameters
        ----------
        data : dict
            Similarity searh weight in json format

        Returns
        -------
        SimilaritySearchWeight
        """
        return self.tm_class(
            client=self.client,
            interval=IntervalFactory(client=self.client)._from_json(data),
            weight=round(math.log(data["weight"], 3))
        )

    @ property
    def _get_methods(self):
        return self.from_tuple,
