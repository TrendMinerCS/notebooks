import abc


class Component(abc.ABC):
    """Superclass for ContextHub components"""
    component_type = None
