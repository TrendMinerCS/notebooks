import abc

from trendminer_interface.base import LazyAttribute, ByFactory
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.fingerprint.entry import FingerprintEntryFactory
from trendminer_interface.fingerprint.layer import FingerprintLayerFactory


class FingerprintClient(abc.ABC):
    """Client for fingerprint factory"""
    @property
    def fingerprint(self):
        return FingerprintFactory(client=self)

class Fingerprint(WorkOrganizerObject):
    """TrendMiner fingerprint; To be completed"""
    # FIXME
    content_type = "FINGERPRINT"
    entries = ByFactory(FingerprintEntryFactory, "list")

    def __init__(
            self,
            client,
            name,
            description,
            identifier,
            folder,
            owner,
            last_modified,
            entries,
            layers,
            data_identifier,
            data_type,

    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )
        self.data_identifier = data_identifier
        self.layers = layers
        self.data_type = data_type
        self.entries = entries


    @property
    def layers(self):
        return self._layers

    @layers.setter
    def layers(self, layers):
        if not isinstance(layers, LazyAttribute):
            layers = FingerprintLayerFactory(client=self.client).list(layers)
            print(layers)
            if not any([layer.base for layer in layers]):
                layers[0].base = True
        self._layers = layers

    def _content_blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return self.client.fingerprint.from_identifier(self.identifier)


    def _json_data(self):
        return {
            "identifier": self.data_identifier,
            "layers": self.layers,
            "type": self.data_type,
            "dataReferences": self.entries
        }

    def __json__(self):
        return{
            "identifier": self.identifier,
            "name": self.name,
            "type": self.content_type,
            "description": self.description,
            "data": self._json_data()
        }





# TODO: add methods for creating new fingerprint
class FingerprintFactory(WorkOrganizerFactory):
    """Factory for creating and retrieving fingerprints"""
    tm_class = Fingerprint
    def __call__(
            self,
            entries,
            layers,
            name="New Fingerprint",
            description="",
            folder=None,
            type=None,
            data_type= 'LAYER_BASED'
    ):
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            entries=entries,
            layers=layers,
            data_identifier=None,
            data_type=data_type,
        )
    @property
    def _from_json_methods(self):
        return self.from_json_enriched

    def _from_json(self, data):
        """Full enriched payload"""
        return self.tm_class(
            client=self.client,
            name=data["name"],
            description=data["description"],
            identifier=data["identifier"],
            folder=self.client.folder._from_json_identifier_only(data["parentId"]) if "parentId" in data else self.client.folder.root(),
            owner=self.client.user._from_json_name_only(data["owner"]),
            last_modified=data["lastModifiedDate"],
            entries=[FingerprintEntryFactory(client=self.client)._from_json(entry)
                     for entry in data["data"]["dataReferences"]],
            layers=[FingerprintLayerFactory(client=self.client)._from_json(layer)
                    for layer in data["data"]["layers"]],
            data_identifier=data["data"]["identifier"],
            data_type=data["data"]["type"],
        )
