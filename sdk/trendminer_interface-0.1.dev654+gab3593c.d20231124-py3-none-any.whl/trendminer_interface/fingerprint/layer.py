from trendminer_interface.base import TrendMinerFactory, Serializable, ByFactory
from trendminer_interface.times import time_json, IntervalFactory
from trendminer_interface import _input as ip
from trendminer_interface.constants import LINE_STYLES


class FingerprintLayer(Serializable):
    interval = ByFactory(IntervalFactory, "__call__")

    def __init__(
            self,
            client,
            base,
            interval,
            name,
            line_style,
            hidden_references,
    ):
        super().__init__(client=client)
        self.base = base,
        self.interval = interval
        self.name = name
        self.line_style = line_style
        self.hidden_references = hidden_references

    @property
    def line_style(self):
        if self.base:
            return "SOLID"
        return self._line_style if self._line_style != "SOLID" else "DASHED"

    @line_style.setter
    @ip.options(LINE_STYLES)
    def line_style(self, line_style):
        self._line_style = line_style

    def __json__(self):
        return {
            "base": self.base,
            "name": self.name,
            "properties": {
                "lineStyle": self.line_style,
                "hiddenDataReferences": self.hidden_references,
            },
            "timePeriodStart": time_json(self.interval.start),
            "timePeriodEnd": time_json(self.interval.end),
        }


# TODO: implement method for creating new layers
class FingerprintLayerFactory(TrendMinerFactory):
    tm_class = FingerprintLayer

    def from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        FingerprintLayer
        """
        return self.tm_class(
            client=self.client,
            base=data["base"],
            interval=(data["timePeriodStart"], data["timePeriodEnd"]),
            name=data["name"],
            line_style=data["properties"]["lineStyle"],
            hidden_references=data["properties"]["hiddenDataReferences"],
        )
