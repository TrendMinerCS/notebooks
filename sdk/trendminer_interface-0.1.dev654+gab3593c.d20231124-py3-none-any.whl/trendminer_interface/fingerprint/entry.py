from trendminer_interface.base import TrendMinerFactory, Serializable


class FingerprintEntryFactory(TrendMinerFactory):
    """Factory for generating entries to a fingerprint

    Fingerprint entries can be tags or attributes
    """
    tm_class = Serializable

    def __init__(self, client):
        super().__init__(client=client)

    def from_tag(self, ref):
        """Get tag from a reference

        Parameters
        ----------
        ref : Any
            Tag reference

        Returns
        -------
        Tag
        """
        return self.client.tag.get(ref)

    def from_attribute(self, ref):
        """Get attribute from a reference

        Parameters
        ----------
        ref : Any
            Attribute reference

        Returns
        -------
        Attribute
        """
        return self.client.asset.get(ref)

    @property
    def _get_methods(self):
        return self.from_tag, self.from_attribute

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        if data["type"] == "TIME_SERIES":
            return self.client.tag._from_json_fingerprint(data)

        if data["type"] == "ATTRIBUTE":
            return self.client.asset._from_json_fingerprint(data)