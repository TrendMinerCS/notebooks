import posixpath

from trendminer_interface.base import ByFactory, HasOptions, kwargs_to_class
from .filter import ContextFilterFactory

from trendminer_interface.times import time_json
from trendminer_interface.work import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.constants import MAX_CONTEXT_ITEM_GET_SIZE, CONTEXT_VIEW_OPTIONS

from .view_configuration import grid_settings_dummy, scatter_settings_dummy, gantt_settings_dummy


class ContextHubView(WorkOrganizerObject):
    """ContextHub view that can retrieve context items matching its associated context filters

    Attributes
    ----------
    filters : list
        Context filters associated with the view. These will determine the context items that are retrieved.
    view_type : str
        Visual representation of the view in the appliance: "gantt" or "grid"
    grid_settings : dict
        Configuration of the columns of the table view in json format. Not intended to be edited via the sdk.
    gantt_settings : dict
        Configuration of the gantt chart view in json format. Not intended to be edited via the sdk.
    scatter_settings : dict
        Settings for the sorting of context items in the table view, in json format. Not intended to be edited via the
        sdk.
    """
    content_type = "CONTEXT_LOGBOOK_VIEW"
    filters = ByFactory(ContextFilterFactory, "list")
    view_type = HasOptions(CONTEXT_VIEW_OPTIONS)

    def __init__(
        self,
        client,
        identifier,
        name,
        description,
        folder,
        owner,
        last_modified,
        filters,
        view_type,
        grid_settings,
        gantt_settings,
        scatter_settings,
    ):

        WorkOrganizerObject.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            folder=folder,
            owner=owner,
            last_modified=last_modified,
        )

        self.view_type = view_type
        self.grid_settings = grid_settings
        self.gantt_settings = gantt_settings
        self.scatter_settings = scatter_settings
        self.filters = filters

    def _full_instance(self):
        return self.client.context.view.from_identifier(self.identifier)

    def _json_search(self):
        return {
            "filters": self.filters,
            "sortProperties": ["startEventDate"],
            "sortDirection": "asc",
            "fetchSize": MAX_CONTEXT_ITEM_GET_SIZE,
        }

    def _json_delete(self):
        return {**self._json_search(), "createdBefore": time_json(self.client.time.now())}

    def _json_data(self):
        return {
            "gridSettings": self.grid_settings,
            "ganttSettings": self.gantt_settings,
            "scatterSettings": self.scatter_settings,
            "viewType": self.view_type,
            **self._json_search(),
        }

    def _content_blueprint(self):
        raise NotImplementedError

    def search_items(self):
        """Retrieve all context items matching the view filters

        Returns
        -------
        list of ContextItem
        """
        content = self.client.session.continuation(keys=["content"]).post(url="/context/v2/item/search",
                                                                          json=self._json_search(),
                                                                          )

        return [self.client.context.item._from_json(item) for item in content]

    def delete_items(self):
        """Delete all context items matching the view filters"""
        self.client.session.delete("/context/item/batch/filters", json=self._json_delete())


class ContextHubViewFactory(WorkOrganizerFactory):
    """Factory for creating and retrieving ContextHub views"""
    tm_class = ContextHubView

    def __call__(
            self,
            filters,
            name="New View",
            description="",
            folder=None,
            view_type="grid",
    ):
        """Create a new ContextHub view

        Parameters
        ----------
        filters : list
            Context filters for the view
        name : str, default "New View"
            View name
        description : str, optional
            View description
        folder : Folder or str, optional
            Folder to which the view needs to be saved
        view_type : str
            Visual representation of the view in the appliance: "gantt" or "grid"
        """

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            folder=folder,
            owner=None,
            last_modified=None,
            filters=filters,
            view_type=view_type,
            grid_settings=grid_settings_dummy,
            scatter_settings=scatter_settings_dummy,
            gantt_settings=gantt_settings_dummy,
        )

    def from_identifier(self, ref):
        link = posixpath.join('/context/view', ref, "enriched")
        response = self.client.session.get(link)
        return self._from_json(response.json())

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "filters": [
                ContextFilterFactory(client=self.client)._from_json(cfilter)
                for cfilter in data["data"]["filters"]
            ],
            "view_type": data["data"]["viewType"],
            "grid_settings": data["data"]["gridSettings"],
            "scatter_settings": data["data"]["scatterSettings"],
            "gantt_settings": data["data"]["ganttSettings"],
        }
