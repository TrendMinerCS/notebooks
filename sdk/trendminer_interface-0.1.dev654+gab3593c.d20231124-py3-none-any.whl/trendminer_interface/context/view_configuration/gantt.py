"""Default gantt configration when making a new ContextHub view"""

gantt_settings_dummy = {
    "displayDensity": "REGULAR",
    "expandedByDefault": False,
    "fieldsOverridingExpandSetting": [],
    "groupBy": "TYPE",
    "typesOverridingExpandSetting": [],
}