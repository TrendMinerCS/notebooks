from trendminer_interface.authentication import Authenticated
from .numeric import NumericFieldFilterFactory, NumericFieldFilter
from .string import StringFieldFilterFactory, StringFieldFilter
from .enumeration import EnumerationFieldFilterFactory, EnumerationFieldFilter


class FieldFilterFactory(Authenticated):
    """Factory for creating a field filter"""
    tm_class = (NumericFieldFilter, StringFieldFilter, EnumerationFieldFilter)

    def __call__(self, field, values=None, mode=None):
        """Create new context filter on a context field

        Parameters
        ----------
        field : Any
            A (reference to a) context field
        values : list, optional
            Values to filter on. List of string for enumeration or string fields, List of (entries convertible to)
            NumericQuery for numeric fields.
        mode : str, optional
            Search for special conditions, ignoring `values`. "EMPTY" or "NON_EMPTY"
        """
        field = self.client.context.field.get(field)

        if field.field_type == "NUMERIC":
            return NumericFieldFilterFactory(client=self.client)(field, values=values, mode=mode)

        elif field.field_type == "ENUMERATION":
            return EnumerationFieldFilterFactory(client=self.client)(field, values=values, mode=mode)

        elif field.field_type == "STRING":
            return StringFieldFilterFactory(client=self.client)(field, values=values, mode=mode)

        else:
            raise ValueError()