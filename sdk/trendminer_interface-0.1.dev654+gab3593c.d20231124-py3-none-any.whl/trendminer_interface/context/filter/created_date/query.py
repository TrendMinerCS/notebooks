from trendminer_interface.context.filter.base import ContextQuery, ContextQueryFactory
from trendminer_interface.times import time_json
from trendminer_interface.base import ByFactory
from trendminer_interface.times import DatetimeFactory


class CreatedDateQuery(ContextQuery):
    """Creation date query for creation date context filters

    Attributes
    ----------
    value : datetime.datetime
        Creation timestamp criterion
    """
    value = ByFactory(DatetimeFactory, "__call__")

    def __init__(self, client, operator, value):
        super().__init__(client=client, operator=operator, value=value)

    def __json__(self):
        return {
            "operator": self.operator_str,
            "createdDate": time_json(self.value),
        }


class DateQueryFactory(ContextQueryFactory):
    """Factory for making creation date queries"""
    tm_class = CreatedDateQuery

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        CreatedDateQuery
        """
        return self.tm_class(client=self.client, operator=data["operator"], value=data["createdDate"])
