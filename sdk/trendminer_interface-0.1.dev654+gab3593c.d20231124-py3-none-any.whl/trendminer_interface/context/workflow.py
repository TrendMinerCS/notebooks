from trendminer_interface import _input as ip

from trendminer_interface.base import Savable, QuerySearchFactory


class ContextWorkflow(Savable):
    """Context Workflow determining the events attachable to items of associated type

    Attributes
    ----------
    name : str
        Context workflow name
    states : list of str
        States of the workflow
    """
    endpoint = "context/workflow/"

    def __init__(self, client, identifier, name, states):

        super().__init__(client=client, identifier=identifier)
        self.name = name
        self.states = states

    def __json__(self):
        return {
            "identifier": self.identifier,
            "name": self.name,
            "states": self.states,
            "startState": self.states[0],
            "endState": self.states[-1],
        }

    def blueprint(self):
        return {
            "name": self.name,
            "states": self.states,
        }

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"<< ContextWorkflow | {self.name} >>"


class ContextWorkflowFactory(QuerySearchFactory):
    """Factory for creating and retrieving context workflows"""
    tm_class = ContextWorkflow

    def __call__(self, name, states, start_state=None, end_state=None):
        """Instantiate a new context workflow

        Parameters
        ----------
        name : str
            Context workflow name
        states : list of str
            Possible states of the workflow
        start_state : str, optional
            The start state; must be in `states`. Defaults to the first state in `states`.
        end_state : str, optional
            The end state; must be in `states`. Defaults to the last state in `states`.

        Returns
        -------
        ContextWorkflow
        """
        return self.tm_class(client=self.client,
                             identifier=None,
                             name=name,
                             states=states,
                             )

    def by_name(self, ref):
        """Search context workflows by name

        Parameters
        ----------
        ref : str
            search query

        Returns
        -------
        list of ContextWorkflow
        """
        return self._query_search(ref=ref, search_key="name")

    def from_name(self, ref):
        """Retrieve context workflow by its name

        Parameters
        ----------
        ref : str
            workflow name

        Returns
        -------
        ContextWorkflow
        """
        return ip.object_match_nocase(self.by_name(ref), attribute="name", value=ref)

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        ContextWorkflow
        """
        # make sure start and end states are in the correct order
        states = data["states"]
        start_state = data["startState"]
        end_state = data['endState']
        states = [start_state] + [state for state in states if state not in [start_state, end_state]] + [end_state]

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            name=data["name"],
            states=states,
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    @property
    def _search_methods(self):
        return self.by_name,
