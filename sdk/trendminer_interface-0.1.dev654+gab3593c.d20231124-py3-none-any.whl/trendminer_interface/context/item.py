from collections.abc import MutableMapping

import trendminer_interface._input as ip

from trendminer_interface.tag import Tag
from trendminer_interface.component_factory import ComponentFactory
from trendminer_interface.base import Savable, TrendMinerFactory, ByFactory
from trendminer_interface.user import UserFactory
from trendminer_interface.constants import MAX_POST_SIZE, MAX_GET_SIZE

from .type import ContextTypeFactory
from .field import ContextField
from .event import EventFactory
from .attachment import AttachmentFactory


search_field_keys = ['tm_monitor_id', 'tm_search_id', 'tm_search_type']


class ContextItem(Savable, MutableMapping):
    """Context item containing contextual information

    Attributes
    ----------
    created_by : User or
        User that created the context item on the appliance
    context_type : ContextType
        Context type of the context item
    sync_time : datetime.datetime
        Time the context item was synced to the appliance
    components : list
        Components (tags, assets, attributes) to which the context item is attached. Though through the UX, a context
        item can only be attached to a single component, multiple components can be provided via API. Adding more than
        a single component is not recommended.
    description : str
        Context item description
    identifier : str
        Context item uuid
    key : str
        Context item unique short-key
    search_fields : dict
        Metadata from when the context item was created from a monitor. Contains the keys 'tm_monitor_id',
        'tm_search_id' and 'tm_search_type'.
    """
    endpoint = "context/item/"

    created_by = ByFactory(UserFactory)
    context_type = ByFactory(ContextTypeFactory)
    components = ByFactory(ComponentFactory, "list")

    def __init__(self, client, identifier, key, context_type, components, events, fields, keywords, description,
                 created_by, search_fields, sync_time):
        super().__init__(client=client, identifier=identifier)
        self.sync_time = sync_time
        self.context_type = context_type
        self.components = components
        self.events = events
        self.fields = fields
        self.keywords = keywords
        self.description = description or ""
        self.identifier = identifier
        self.key = key
        self.created_by = created_by
        self.search_fields = search_fields or {}

    @property
    def events(self):
        """Contex item events

        Input for setting context item events can also be a list of datetimes, or an Interval instance.

        Returns
        -------
        events: list of ContextEvent
            Context item events corresponding to the context type workflow
        """
        return self._events

    @events.setter
    def events(self, events):
        # Setting events requires knowledge of the workflow
        self._events = EventFactory(client=self.client, workflow=self.context_type.workflow).list(events)

    @property
    def fields(self):
        """Context item data fields

        Returns
        -------
        fields : dict
            Field data. Dictionary keys are the keys of the corresponding context field, not ContextField instances.
            Data can be str or float, depending on the context field type. Other keys (not corresponding to the fields
            associated with the context type) can be added too, which will show up as 'other properties' in the UX.
        """
        return self._fields

    @fields.setter
    def fields(self, fields):
        fields = fields or {}
        fields = {field.key if isinstance(field, ContextField) else field: value for field, value in fields.items()}
        self._fields = fields

    @property
    def keywords(self):
        """Keywords attached to the item

        Keywords in TrendMiner are always lowercase.

        Returns
        -------
        keywords : list of str
            List of keywords attached to the context item
        """
        return self._keywords

    @keywords.setter
    def keywords(self, keywords):
        self._keywords = [kw.lower() for kw in ip.any_list(keywords)]

    @property
    def interval(self):
        """Time interval covered by the context item

        The interval is determined by the start and end event. If the end event has not occurred yet, the end of the
        interval will be the current time. If there is no workflow associated with the context type, the context item
        only has a single timestamp, so the length of the returned interval is 0.

        Returns
        -------
        interval : Interval
            The time interval covered by the context item
        """
        if not self.events:
            return None

        start_event = self.events[0]
        end_event = self.events[-1]

        if self.context_type.workflow is not None:
            is_open = end_event.state != self.context_type.workflow.states[-1]
        else:
            is_open = False

        if is_open:
            end_time = self.sync_time or self.client.time.now()
        else:
            end_time = end_event.timestamp

        return self.client.time.interval(start_event.timestamp, end_time, data=self.fields, is_open=is_open)

    def __json__(self):
        # ignore None values as they throw errors
        fields = {
            **self.search_fields,
            **{key: value for key, value in self.fields.items() if value is not None}
        }
        return {
            "identifier": self.identifier,
            "description": self.description,
            "keywords": self.keywords,
            "type": self.context_type,
            "components": [component._json_component() for component in self.components],
            "fields": fields, # {**self.fields, **self.search_fields},
            "events": self.events,
        }

    def _post_updates(self, response):
        super()._post_updates(response)
        self.key = response.json()["shortKey"]
        self.created_by = UserFactory(client=self.client)._from_json_limited(response.json()["userDetails"])
        self.events = [
            EventFactory(client=self.client, workflow=self.context_type.workflow)._from_json(event)
            for event in response.json()["events"]
        ]

    def _put_updates(self, response):
        self._sync_time = self.client.time.now()

    def approve(self):
        """Add user approval to this context item"""
        self.client.session.post(f"/context/data/{self.identifier}/approval")

    def remove_approval(self):
        """Remove user approval from this context item"""
        self.client.session.delete(f"/context/data/{self.identifier}/approval")

    def history(self):
        """Return context item history

        Keeping history must be configured for the context type.

        Returns
        -------
        dict
            Context item history
        """
        params = {"size": MAX_GET_SIZE, "sort": "desc"}
        response = self.client.session.get(f"/context/history/{self.identifier}", params=params)
        return response.json()

    @property
    def attachments(self):
        """Context item attachment facotry"""
        return AttachmentFactory(parent=self)

    def blueprint(self):
        return {
            "context_type": self.context_type.key,
            "components": [c.name if isinstance(c, Tag) else c.path for c in self.components],
            "events": self.events,
            "fields": self.fields,
            "keywords": self.keywords,
            "description": self.description,
        }

    def __repr__(self):
        if self.interval is not None:
            return (
                f"<< ContextItem | {self.context_type.key} | {self.interval.duration} >>"
            )
        return f"<< ContextItem | {self.context_type.key} >>"

    def __getitem__(self, item):
        return self.fields.__getitem__(item)

    def __setitem__(self, key, value):
        self.fields.__setitem__(key, value)

    def __delitem__(self, key):
        self.fields.__delitem__(key)

    def __iter__(self):
        return self.fields.__iter__()

    def __len__(self):
        return self.fields.__len__()


class ContextItemFactory(TrendMinerFactory):
    """Factory for creating and retrieving context items"""
    tm_class = ContextItem

    def __call__(self, context_type, components, events=None, description="", fields=None, keywords=None):
        """Create new context item

        Parameters
        ----------
        context_type : ContextType or str
            Type associated with the new context item
        components : list
            Components (tags, assets, attributes) to which the context item needs to be attached. Though through the UX,
            a context item can only be attached to a single component, multiple components can be provided via API.
            Adding more than a single component is not recommended.
        events : list or Interval, optional
            List of events corresponding to the context item. These can be ContextEvent or datetime. An interval can
            also be given as input, taking the interval start and end as the start and end events. Though the events
            need to be defined before context item creation on the appliance, this parameter can be left initially,
            allowing a context item 'template' to be initialized. This template can then be used to create many items
            (e.g. by filling in the `events` attribute in a loop).
        description : str, default ""
            Context item description
        fields : dict, optional
            Context item data fields
        keywords : list, optional
            Keywords attached to the context item
        """
        return self.tm_class(client=self.client,
                             identifier=None,
                             key=None,
                             context_type=context_type,
                             components=components,
                             events=events,
                             description=description,
                             fields=fields,
                             keywords=keywords,
                             created_by=None,
                             search_fields=None,
                             sync_time=None,
                             )

    def bulk_post(self, items, per=MAX_POST_SIZE):
        """Post multiple context items to the appliance at once

        Creating multiple items at once in one (large) POST request is much more efficient than creating items
        individually in a loop. We can thus initialize all items we want to create, and then create them in one go
        using this method.

        Parameters
        ----------
        items : list of ContextItem
            The context items that we want to post to the appliance
        per : int, optional
            How many items we want to create in one go. An appropriate default value is selected, but this parameter
            allows customization for when requests time out on slow setups.
        """
        payloads = [item.__json__() for item in self.list(items)]
        for i in range(0, len(items), per):
            self.client.session.post("/context/item/batch", json=payloads[i:i+per])

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        ContextItem
        """
        fields = data['fields']

        search_fields = {}
        for key in search_field_keys:
            if key in fields:
                search_fields.update({key: fields.pop(key)})

        if "userDetails" in data:
            user = UserFactory(client=self.client)._from_json_limited(data["userDetails"])
        else:
            user = None  # Deleted user

        context_type = ContextTypeFactory(client=self.client)._from_json(data["type"])

        events = [
            EventFactory(client=self.client, workflow=context_type.workflow)._from_json(event)
            for event in data["events"]
        ]

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            key=data["shortKey"],
            context_type=context_type,
            components=[
                ComponentFactory(client=self.client)._from_json_context_item(component)
                for component in data["components"]
            ],
            events=events,
            fields=fields,
            keywords=data["keywords"],
            description=data.get("description"),
            created_by=user,
            search_fields=search_fields,
            sync_time=self.client.time.now()
        )

    def _from_json_monitor(self, data):
        return self.tm_class(
            client=self.client,
            identifier=None,
            key=None,
            context_type=data["type"],
            components=[data["componentReference"]],
            events=None,
            fields=data["fields"],
            keywords=data["keywords"],
            description=data.get("description"),
            created_by=None,
            search_fields={},
            sync_time=None,
        )

    @property
    def _get_methods(self):
        return self.from_identifier,
