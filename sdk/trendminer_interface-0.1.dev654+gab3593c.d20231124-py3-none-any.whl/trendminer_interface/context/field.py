from trendminer_interface import _input as ip
from trendminer_interface.base import Savable, QuerySearchFactory, HasOptions
from trendminer_interface.constants import CONTEXT_FIELD_OPTIONS


class ContextField(Savable):
    """Context field structure

    A ContextField instance gives the structure of a context field, it does not represent a single field+value on a
    context item. Context item field values are given as a dict by `ContextItem.fields`, where the key in the dict must
    match the key of the corresponding ContextField instance.

    Attributes
    ----------
    name : str
        Name that is visible to the users in the appliance
    key : str
        Key that is used as the main identifier of the field. Needs to be unique.
    field_type : {"ENUMERATION", "STRING", "NUMERIC"}
        Context field type. Determines what type of values the field can take.
    placeholder : str
        Field placeholder that is displayed to the user if the field is blank. This is NOT a default value, it is a
        visual aid to the user.
    """
    endpoint = "context/fields/"
    field_type = HasOptions(CONTEXT_FIELD_OPTIONS)

    def __init__(self, client, identifier, field_type, name, key, placeholder, options):
        super().__init__(client, identifier=identifier)
        self.name = name
        self.key = key
        self.field_type = field_type
        self.placeholder = placeholder
        self.options = options

    @property
    def options(self):
        """Get field options. Returns None if field is not of type ENUMERATION

        Returns
        -------
        options : list of str, optional
            Options for enumeration fields
        """
        return self._options

    @options.setter
    def options(self, options):
        options = options or []
        if not (self.field_type == "ENUMERATION") and options != []:
            raise ValueError(
                f"Context field of type {self.field_type} does not take options"
            )
        self._options = [str(i) for i in options]

    @property
    def blueprint(self):
        return {
            "key": self.key,
            "name": self.name,
            "field_type": self.field_type,
            "placeholder": self.placeholder,
            "options": self.options,
        }

    def __json__(self):
        """post/put request payload for saving context field"""
        payload = {
            "identifier": self.identifier,
            "propertyKey": self.key,
            "name": self.name,
            "type": self.field_type,
            "placeholder": self.placeholder,
        }
        if self.field_type == "ENUMERATION":
            payload.update({"options": self.options})
        return payload

    def __str__(self):
        return self.key

    def __repr__(self):
        return f"<< ContextField | {self.key} >>"


class ContextFieldFactory(QuerySearchFactory):
    """Factory for creating and retrieving context fields"""
    tm_class = ContextField

    def __call__(self, key, name, field_type="STRING", placeholder="", options=None):
        """Create new context field

        Parameters
        ----------
        key : str
            Context field unique key
        name : str
            Context field name
        field_type : str, default "STRING"
            "STRING", "ENUMERATION" or "NUMERIC"
        placeholder : str
            Placeholder displayed in empty field (NOT a default value)
        options : list of str, optional
            List of options for enumeration type field
        """
        return self.tm_class(client=self.client,
                             identifier=None,
                             field_type=field_type,
                             name=name,
                             key=key,
                             placeholder=placeholder,
                             options=options,
                             )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        ContextField
        """
        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            field_type=data["type"],
            name=data["name"],
            key=data["propertyKey"],
            placeholder=data.get("placeholder"),
            options=data.get("options"),
        )

    def from_key(self, ref):
        """Retrieve context field by its unique key

        Parameters
        ----------
        ref : str
            Context field key
        """
        return ip.object_match_nocase(self.by_key(ref), attribute="key", value=ref)

    def from_name(self, ref):
        """Retrieve context field by its name

        Parameters
        ----------
        ref : str
            Context field name
        """
        return ip.object_match_nocase(self.by_name(ref), attribute="name", value=ref)

    def by_key(self, ref):
        """Search context fields by key

        Parameters
        ----------
        ref : str
            Search query, can contain * as wildcard
        """
        return self._query_search(ref=ref, search_key="propertyKey")

    def by_name(self, ref):
        """Search context fields by name

        Parameters
        ----------
        ref : str
            Search query, can contain * as wildcard
        """
        return self._query_search(ref=ref, search_key="name")

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_key, self.from_name

    @property
    def _search_methods(self):
        return self.by_name, self.by_key
