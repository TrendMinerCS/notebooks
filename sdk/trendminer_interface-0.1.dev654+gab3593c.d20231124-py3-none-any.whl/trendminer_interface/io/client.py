from trendminer_interface.authentication import Authenticated
from .tag import TagIOFactory
from .work import WorkIOFactory
from .context import ContextIOFactory


class IOClient:
    """Client for input-output factory"""
    @property
    def io(self):
        """Input-output factory

        Returns
        -------
        IOFactory
        """
        return IOFactory(client=self)


class IOFactory(Authenticated):
    """Input-output factory"""
    @property
    def tag(self):
        """Factory for tag import

        Returns
        -------
        TagIOFactory
        """
        return TagIOFactory(client=self.client)

    @property
    def work(self):
        """Factory for work organizer item export/import

        Returns
        -------
        WorkIOFactory
        """
        return WorkIOFactory(client=self.client)

    @property
    def context(self):
        """Factory for context item import

        Returns
        -------
        ContextIOFactory
        """
        return ContextIOFactory(client=self.client)

