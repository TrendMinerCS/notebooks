import pandas as pd
from trendminer_interface.times import time_json


def structure_csv(items):
    """Puts context items in correct format to upload as csv

    Parameters
    ----------
    items : list of ContextItem
        ContextItems to be structured into a file

    Returns
    -------
    pandas.DataFrame
        DataFrame with correct structure for import. Call `.to_csv` with `index=False` to save as csv file.
    """
    max_states = max([len(item.events) for item in items])
    max_fields = max([len(item.fields) for item in items])

    columns = (
            ["description", "type", "keywords"]
            + [
                f"events_{state_counter}_{header_addendum}"
                for state_counter in range(0, max_states)
                for header_addendum in ["state", "ts"]
            ]
            + [
                f"properties_{field_counter}_{header_addendum}"
                for field_counter in range(0, max_fields)
                for header_addendum in ["key", "value"]
            ]
    )

    df = pd.DataFrame(index=range(0, len(items)), columns=columns)

    for i, item in enumerate(items):
        df.loc[i, "description"] = item.description
        df.loc[i, "type"] = item.context_type.key
        df.loc[i, "keywords"] = ", ".join(item.keywords)

        for k, event in enumerate(item.events):
            if event.state is not None:
                df.loc[i, f"events_{k}_state"] = event.state
            df.loc[i, f"events_{k}_ts"] = time_json(event.timestamp)

        for k, key in enumerate(item.fields):
            df.loc[i, f"properties_{k}_key"] = key
            df.loc[i, f"properties_{k}_value"] = item.fields[key]

    df.fillna("", inplace=True)

    return df