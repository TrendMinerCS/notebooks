import pandas as pd
from trendminer_interface.base import LazyAttribute


def timestamp_insert_colon(timestring):
    return timestring[0:-2] + ":" + timestring[-2:]


def structure_csv(tags):
    """Construct DataFrame matching TrendMiner csv import format from list of tags with timeseries data"""

    # Set timezone if absent
    for tag in tags:
        if tag.data.index.tz is None:
            tag.data.index = tag.data.index.tz_localize(tag.client.tz, ambiguous='infer')

    # Join data in single dataframe
    df = pd.concat(
        [tag.data for tag in tags],
        axis=1,
        keys=[tag.name for tag in tags],
    )

    # Empty values need to be blank for the import
    df.fillna("", inplace=True)

    # Set index to correct string format
    df.index = df.index.strftime("%Y-%m-%dT%H:%M:%S%z").map(timestamp_insert_colon)

    # Columns need to contain metadata for the import. Digital tag import not supported, map to digital.
    df.columns = pd.MultiIndex.from_tuples(
        zip(
            df.columns,
            [tag.description for tag in tags],
            [tag.units for tag in tags],
            ["string" if tag.tag_type.lower() == "digital" else tag.tag_type.lower() for tag in tags],
        )
    )
    return df
