from trendminer_interface.authentication import Authenticated
from trendminer_interface.base import LazyAttribute
import trendminer_interface._input as ip

from .structure import structure_csv


class TagIOFactory(Authenticated):
    """Factory for managing tag file export/import"""
    endpoint = "ds/imported/timeseries/"

    @staticmethod
    def structure(tags):
        """Puts tags in correct format to upload as csv

        Parameters
        ----------
        tags : list of Tag
            Tags with timeseries data added

        Returns
        -------
        pandas.DataFrame
            DataFrame with correct structure for import. Call `.to_csv` with `index_label=False` to save as csv file.
        """
        return structure_csv(tags=tags)

    # TODO: implement get method, needs tag from_json_imported
    # def get(self):
    #     # response = self.client.session.get(self.endpoint)
    #     raise NotImplementedError

    def post(self, tags, index=True):
        """Uploads new csv tags or overwrites user's existing tags

        Parameters
        ----------
        tags : list of Tag
            Tags to be uploaded to the appliance via the csv import endpoint. The `Tag.data` attributes must contain
            pandas series objects for any time-series data to be imported.
        index : bool, default True
            Whether to send an index request to the tags after uploading. Indexing them makes them ready for use in
            the appliance.
        """

        df = structure_csv(tags=tags)
        file = df.to_csv(index_label=False)
        files = {"file": ("tagdata.csv", file)}
        self.client.session.post(self.endpoint, files=files)

        # Update input tag data
        for tag in tags:
            server_tag = self.client.tag.from_name(tag.name)
            tag.identifier = server_tag.identifier
            tag.datasource = server_tag.datasource
            if not tag.isnumeric():
                tag.states = LazyAttribute()

        # Index tags if requested
        if index:
            for tag in tags:
                tag.index()

    def delete(self, tags):
        """Remove imported tags

        Tagnames of removed tags can never be used again. To preserve names, it is better to overwrite them with a new
        call to the `post`.

        Parameters
        ----------
        tags : list of Tag or Any
            Imported tags (or references to these tags) that need to be removed.
        """
        tags = self.client.tag.list(tags)

        # Need to load all imported tags and match by name to get correct identifier
        content = self.client.session.paginated(keys=["content"]).get(self.endpoint)
        for tag in tags:
            match = ip.dict_match_nocase(items=content, key="name", value=tag.name)
            self.client.session.delete(f"{self.endpoint}/{match['identifier']}")

    def delete_all(self):
        """Remove all imported tags"""
        self.client.session.delete(self.endpoint)