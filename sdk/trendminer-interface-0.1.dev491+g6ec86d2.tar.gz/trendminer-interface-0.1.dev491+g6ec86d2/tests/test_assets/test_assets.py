import pandas as pd
import time


def test_asset(user):
    assets = user.asset.by_name(ref="Hasselt")
    assets = user.asset.by_description(ref="Hasselt")
    assets = user.asset.by_template(ref="SIN-CH")
    print(assets)

    asset = user.asset.from_identifier("38577c7d-6ca2-4d06-8210-f1b3f7ada431")
    print(asset.source)
    root = user.asset.root()
    print(root.children)
    assets = user.asset.by_template(ref="SIN-CH", frameworks="Edwards")
    print(assets)

    asset = user.asset.get("AF-example/Europe/Belgium")
    asset = user.asset.from_path("AF-example/Europe/Belgium")
    asset = user.asset.from_identifier(asset.identifier)
    print(asset)
    print(asset.children)
    print(asset.parent)
    print(asset.path)


def test_frameworks(user):
    frameworks = user.asset.framework.all()[0:5]
    for fw in frameworks:
        print(fw.name)
        print(fw.root_asset.children)
        if fw.sync.status == "DONE_WITH_ERRORS":
            try:
                print(fw.get_errors())
            except FileNotFoundError:
                pass
        elif fw.af_type != "CSV":
            print(fw.af_type)
        else:
            fw.export()


def test_framework_create(user, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "/"+prefix, prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = user.asset.framework(name=prefix, df=df)
    af.post()
    print(af.ordering)
    while af.sync.status != 'DONE':
        time.sleep(0.1)
    af = user.asset.framework.from_identifier(af.identifier)
    af.delete()


def test_framework_errors(user, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "incorrect path", prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = user.asset.framework(name=prefix, df=df)
    af.post()
    while True:
        if af.sync.status != "RUNNING":
            break
    print(af.get_errors())
    af.delete()


def test_access(user, cfg, prefix):
    # asset = user.asset.root().children[1]
    # print(asset.access.all())
    # print(asset.children[0].access_inherited.all())

    # User and group setup
    new_user = cfg.user(
        name=f"{prefix}_user",
        first="My",
        last="User",
        mail="MyUser@trendminer.com"
    )
    new_user.post("MyPassword1!")

    tm_user = user.user.from_name(new_user.name)

    # Load asset
    asset = user.asset.from_path("AF-example")

    # Set access
    asset.access.add(tm_user, "read")
    print(asset.access.all())
    print(asset.children[0].access_inherited.all())
    asset.access.remove(tm_user)
    print(asset.access.all())
    asset.access.add(tm_user, "browse")
    print(asset.access.all())
    asset.access.clear()
    print(asset.access.all())

    new_user.delete()


def test_sync_status(user):
    syncs = user.asset.framework.sync.all()
    print(syncs)
    print(syncs[0].started)
    print(syncs[0].ended)
