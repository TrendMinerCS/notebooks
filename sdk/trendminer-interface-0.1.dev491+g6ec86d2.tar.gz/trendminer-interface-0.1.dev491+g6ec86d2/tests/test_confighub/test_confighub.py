def test_client(cfg):
    cfg.session.token_refresh()
    print(cfg.time.now())


def test_users(cfg, prefix):

    # Users
    user = cfg.user(
        name=prefix,
        first="QA",
        last="Test",
        mail=f"{prefix}@trendminer.com"
    )
    user.post("Password1!")
    user = cfg.user.from_name(prefix)
    user.first = "QA2"
    user.put()
    assert cfg.user.from_identifier(user.identifier).first == "QA2"
    user.set_password("Password2!")
    assert len(cfg.user.by_name(prefix)) > 0
    assert len(cfg.user.all()) > 0
    user.delete()

    # Clients
    client = cfg.client(f"{prefix}client")
    client.post()
    client.name = f"{prefix}client2"
    client.put()
    assert cfg.client.get(f"{prefix}client2")
    assert len(cfg.client.all()) > 0
    client.delete()


def test_groups(cfg, prefix):
    assert cfg.group.local()

    group = cfg.group(prefix+"1")
    group.post()

    n = 5
    users = [cfg.user(name=f"{prefix}{i}", first="QA", last="TEST", mail=f"{prefix}{i}@trendminer.com")
             for i in range(0,n)]

    for user in users:
        user.post("Password1!")
        group.member_add(user)

    assert len(group.members_get()) == n

    group2 = cfg.group(prefix+"2")
    group2.post()
    assert len(cfg.group.by_name(prefix)) == 2

    group2.member_add(group)
    assert len(group2.members_get()) == 1

    group.member_remove(users[0].name)
    assert len(group.members_get()) == n-1

    group.delete()
    group2.delete()

    for user in users:
        user.delete()


def test_datasource(cfg, prefix):
    connector = cfg.connector(prefix, "https://trendminer.com", username="wouter", password="wouterwouter123")
    connector.post()
    assert len(cfg.connector.all()) > 0

    ds = cfg.datasource(
        name=prefix,
        connector=prefix,
        provider="odbc",
        host=prefix,
        tagfilter="CS*",
        prefix=prefix[-5:],
    )
    ds.post()

    ds = cfg.datasource.get(prefix)
    ds.name = prefix + "2"
    ds.put()
    assert len(cfg.datasource.all()) > 0

    ds.delete()
    connector.delete()


def test_acl(cfg, prefix):
    user = cfg.user(name=prefix, first="QA", last="TEST", mail=f"{prefix}@trendminer.com")
    user.post("Password123!")

    client = cfg.client(prefix+"client")
    client.post()

    group = cfg.group(name=prefix)
    group.post()

    acl = cfg.access(name=prefix, members=[user, group, client])
    acl.post()

    for member in [user, group, client]:
        acl.member_remove(member)
        assert len(acl.members_get()) == 2
        acl.member_add(member)
        assert len(acl.members_get()) == 3

    acl.delete()
    client.delete()
    user.delete()
    group.delete()


def test_cleanup(cfg):
    for user in cfg.user.by_name("QA"):
        user.delete()

    for client in cfg.client.all():
        if client.name.startswith("QA"):
            client.delete()

    for group in cfg.group.by_name("QA"):
        try:
            group.delete()
        except Exception:
            pass

    for acl in cfg.access.all():
        if acl.name.startswith("QA"):
            acl.delete()

    for ds in cfg.datasource.all():
        if ds.name.startswith("QA"):
            ds.delete()

    for conn in cfg.connector.all():
        if conn.name.startswith("QA"):
            conn.delete()
