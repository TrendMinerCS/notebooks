from trendminer_interface.base import TrendMinerFactory, LazyAttribute, ByFactory
from trendminer_interface.times import DatetimeFactory
import trendminer_interface._input as ip
from .access import Member


class ConfigUserClient:
    @property
    def user(self):
        return ConfigUserFactory(client=self)


class ConfigUser(Member):
    endpoint = "/confighub/v2/users"
    member_type = "USER"

    def __init__(
            self,
            client,
            identifier,
            name,
            first,
            last,
            mail,
            identity_provider,
            local,
            locked,
    ):
        super().__init__(client=client, identifier=identifier, name=name)
        self.first = first
        self.last = last
        self.mail = mail
        self.identity_provider = identity_provider
        self.local = local
        self.locked = locked
        
    @property
    def path(self):
        return self.name.lower()  # user cannot be removed from group if not lowercase

    def _post_updates(self, response):
        self.identifier = response.json()["id"]

    def __json__(self, password=None):
        return {
            "email": self.mail,
            "firstName": self.first,
            "id": self.identifier,
            "identityProvider": self.identity_provider,
            "isLocal": self.local,
            "isLocked": self.locked,
            "lastName": self.last,
            "username": self.name,
            "password": password,
        }

    def post(self, password):
        self.identifier = None  # prevents accidental overwriting
        payload = self.__json__(password=password)
        response = self.client.session.post(self.endpoint, json=payload)
        self._post_updates(response)

    def put(self):
        payload = self.__json__(password=None)
        response = self.client.session.put(self.link, json=payload)
        self._put_updates(response)

    def set_password(self, password):
        url = f"{self.endpoint}/changepassword/{self.identifier}"
        self.client.session.put(url, data=password)

    def _full_instance(self):
        if self.identifier is None:
            return ConfigUserFactory(client=self.client).from_name(self.name)
        else:
            return ConfigUserFactory(client=self.client).from_identifier(self.identifier)

    def blueprint(self):
        raise NotImplementedError


class ConfigUserFactory(TrendMinerFactory):
    tm_class = ConfigUser

    def __call__(self, name, first, last, mail):
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            first=first,
            last=last,
            mail=mail,
            identity_provider="local",
            local=True,
            locked=False,
        )

    def from_json(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["username"],
            first=data["firstName"],
            last=data["lastName"],
            mail=data["email"],
            identity_provider=data["identityProvider"],
            local=data["isLocal"],
            locked=data["isLocked"],
        )

    def from_json_name_only(self, data):
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=data,
            first=LazyAttribute(),
            last=LazyAttribute(),
            mail=LazyAttribute(),
            identity_provider=LazyAttribute(),
            local=LazyAttribute(),
            locked=LazyAttribute(),
        )

    def from_json_member_acl(self, data):
        return self.from_json_name_only(data["name"])

    def from_json_member_group(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            first=data["properties"]["firstname"],
            last=data["properties"]["lastname"],
            mail=LazyAttribute(),
            identity_provider=LazyAttribute(),
            local=LazyAttribute(),
            locked=LazyAttribute(),
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    @property
    def _search_methods(self):
        return self.by_name,

    def by_name(self, ref):
        params = {
            "size": 1000,
            "enabled": True,
            "searchPattern": ref,
        }
        content = self.client.session.paginated(keys=["content"], total=False).get("confighub/v2/users", params=params)
        return [self.from_json(user) for user in content]

    def from_name(self, ref):
        return ip.object_match_nocase(self.by_name(ref), "name", ref)
