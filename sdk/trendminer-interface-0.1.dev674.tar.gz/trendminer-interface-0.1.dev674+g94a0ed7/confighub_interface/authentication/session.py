import datetime
from requests import Session
from trendminer_interface.authentication import TrendMinerSession


class ConfigSession(TrendMinerSession):
    def __init__(self, base_url, verify, keep_history):
        super().__init__(base_url=base_url, verify=verify, keep_history=keep_history)
        self.token_refresh = self._confighub_token_refresh
        self.token_expires = None

    def _confighub_token_refresh(self):
        response = Session.request(self, "POST", url=f"{self.base_url}/confighub/security/service/token", json={})
        self.token = response.json()
        self.token_expires = datetime.datetime.now() + datetime.timedelta(seconds=int(self.token["expires_in"])) \
                             - datetime.timedelta(seconds=self.token_expiration_margin)

    @property
    def access_expired(self):
        if self.token_expires is None:
            return False
        return datetime.datetime.now() > self.token_expires

    def config_login(self, password):
        payload = {
            "username": "admin",
            "password": password,
        }
        self.post(url="/confighub/login", data=payload)
        self.token_refresh()
