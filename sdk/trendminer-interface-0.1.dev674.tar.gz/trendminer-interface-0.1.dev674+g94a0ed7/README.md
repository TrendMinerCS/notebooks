# TrendMiner Python Interface

## Goal 

The goal of this package is to provide a user-friendly interface to all TrendMiner functionality. This allows a user
to automate any in-app workflow with python. As such, this package should prove very useful as a basis for creating
scripts that automate tasks, or that extend upon the basic TrendMiner functionality.

This package is a work in progress. Not all in-app functionality is represented, and the package should not be
considered stable (names may change; functions have not been tested thoroughly).

## Development

To get started with development execute the following:

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
pip install -r dev_requirements.txt
```

### Linting

This package uses [Pylint](https://pylint.org/) to verify the Python code. 
The configuration of the tool is done in `.pylintrc`.

To run the linting:
```
pylint trendminer_core
```

## TO DO: structural changes and enhancements
- [ ] Info on setting up testing
- [x] Testing broken for new devs: they should not have to set up real server testing to run mocked tests
- [ ] Complete documentation
- [ ] Pylint checkers
- [ ] Rethink factory classes. Currently, the SearchFactory copies methods from WorkOrganizerObjectFactory
- [ ] Rename and restructure files and classes: currently a lot of variation on class naming and in what folder they are.
- [ ] Probably better to try from_name before from_identifier when using .get method
- [ ] Blueprints and from_json_work_export for all classes -> allows copying work between users and servers
- [ ] Cacheing review: which (other) objects can be cached?
- [ ] Caching strategy for asset, placed on the browse; cache should be cleared when AF is updated
- [ ] Would it be better if the caches lived on the client level? Now caches can be filled with references to clients that no longer exist. Would also simplify clearing of cache.
- [ ] There is no entry added in the cache when a request fails. So when looping over a get method where failure is common/expected, we still can send many many requests.
- [x] Get rid of the concept of having a general from_json method, as this can lead to vague and delayed errors. It should be clear which from_json method is required.
- [x] Make from_json_* methods private (_from_json). User does not need to use them.
- [ ] Make versions specific to the TrendMiner version. Check the version when creating a client and throw a warning if that TrendMiner version is not explicitly supported.
- [ ] Tag should have an interpolation type attribute. Now we only have a tag type attribute, but from many endpoints we only receive the interpolation type, giving us no choice but to set the tag type to LazyAttribute(). This generates unnecessary _full_instance() calls.
- [ ] One set of files per test function: pickle files to database, body, responses and prefix to single json
- [x] Do not copy shared _from_json payload part from superclass to subclasses. Superclass should implement the _from_json and partial payload (e.g., _args_full), subclasses the specific parts of the payload ({**super()._args_full, ...}).
- [ ] Abstract base classes for dependent items
  - access rights
  - context item attachments
  - Asset framework sync status
  - Tag index status
- [ ] Rethink search-monitor relationship. What are the workflows by which we can get these. Should there not be a search attribute in MonitorFactory and the other way around?

## TO DO: bugs
- [ ] cfr. code #TODO / #FIXME
- [ ] includeData True does not necessarily provide all info for from_json_enriched, e.g., fails for context type filters.

## TO DO: missing functionality
- [ ] Allow the direct creation of value-based search query filters; analogous to client.search.similarity.query
- [ ] TrendHub view filters should be accounted for when getting tag data for the view (those periods should be skipped)
- [ ] Managing context sql connections
- [ ] Fingerprint and Fingerprint monitors. Will require rework of Monitor to make it more general.
- [ ] Context item import via IO
- [ ] Aggregation tag
- [ ] Compare table
- [ ] Statistics table
- [ ] ConfigHub getting users currently (likely) only works for local users (fixed endpoint: /local/users/)
- [ ] Allow full class-based configuration of ContextHub and TrendHub views. Some configuration options are still in raw json format.
- [ ] Dashboard text tile
- [x] Context item attachments
- [ ] Context item type/field by_name method -> use this also in the from_name methods
- [ ] Scatter type for ContextHub views
- [ ] See if context item is approved
- [ ] tag last value
- [ ] similarity search 'limitResults' optional parameter
- [ ] getting monitoring results
- [ ] Filters
- [ ] Better control of context item events: only possible to create events from list of timestamps or from interval. If there are 4 possible states, but we only want to use 3 of them for our context item, there is no way to do this.

## TO DO: testing
- [x] Assess testing coverage
- [ ] Increase testing coverage

