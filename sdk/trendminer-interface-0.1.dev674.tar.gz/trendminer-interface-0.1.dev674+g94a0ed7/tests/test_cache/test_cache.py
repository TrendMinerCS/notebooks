from trendminer_interface.exceptions import ResourceNotFound


def test_cache(client, user1):

    # Can have cached elements from previous tests
    client.tag.from_name.cache_clear()

    client.tag.from_name("TM_hour_Europe_Brussels")
    client.tag.from_name("TM_hour_Europe_Brussels")
    client.tag.from_name("TM_month_Europe_Brussels")
    client.tag.from_name("TM_month_Europe_Brussels")
    client.tag.from_name("TM_year_Europe_Brussels")
    client.tag.from_name("TM_year_Europe_Brussels")

    assert client.tag.from_name.cache.currsize == 3

    user1.tag.from_name("TM_hour_Europe_Brussels")
    assert user1.tag.from_name.cache.currsize == 4

    client.tag.from_name.cache_clear()
    assert user1.tag.from_name.cache.currsize == 0
