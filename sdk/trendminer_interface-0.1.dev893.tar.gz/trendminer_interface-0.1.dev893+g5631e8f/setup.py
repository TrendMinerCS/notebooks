from setuptools import setup, find_packages
from setuptools_scm import get_version

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='trendminer-interface',
    version=get_version(),
    author='Wouter Daniels',
    author_email='wouter.daniels@trendminer.com',
    description='TrendMiner API control package',
    long_description=long_description,
    packages=find_packages(),
    install_requires=['pandas',
                      'requests',
                      'pytz',
                      'python-dateutil',
                      'colour',
                      'isodate',
                      'urllib3',
                      'numpy',
                      'cachetools'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9'
)
