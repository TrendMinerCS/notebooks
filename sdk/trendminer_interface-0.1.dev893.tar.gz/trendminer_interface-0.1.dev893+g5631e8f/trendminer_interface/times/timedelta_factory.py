import pandas as pd

from trendminer_interface.times.parsers import string_to_timedelta
from trendminer_interface.base import FactoryBase


class TimedeltaFactory(FactoryBase):
    tm_class = pd.Timedelta

    def from_seconds(self, ref):
        """Timedelta from number of seconds

        Parameters
        ----------
        ref : float
            Number of seconds

        Returns
        -------
        pandas.Timedelta
        """
        return pd.Timedelta(seconds=ref)

    def from_str(self, ref):
        """Timedelta from string

        Parameters
        ----------
        ref : str
            String representing a duration (e.g., '17d 12h 30m 15s')

        Returns
        -------
        pd.Timedelta
        """
        return string_to_timedelta(ref)

    @property
    def _get_methods(self):
        return self.from_str, self.from_seconds

    def round(self, td, resolution=None):
        """Round Timedelta to given resolution

        Parameters
        ----------
        td : pandas.Timedelta
            Input duration
        resolution : pandas.Timedelta or str or float
            Rounding resolution

        Returns
        -------
        td : pandas.Timedelta
            Rounded Timedelta
        """

        # Convert inputs if needed
        td = TimedeltaFactory(client=self.client)._get(td)
        resolution = TimedeltaFactory(client=self.client)._get(resolution) or self.client.resolution

        # Round and return
        seconds = round(td.total_seconds() / resolution.total_seconds()) * resolution.total_seconds()
        return pd.Timedelta(seconds=seconds)
