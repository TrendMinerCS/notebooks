import requests
import keycloak
import urllib3
import pytz

from .response_hooks import raise_all
from trendminer_interface import _input as ip

from urllib.parse import urljoin
from datetime import datetime

from trendminer_interface.constants import DEFAULT_USER_AGENT, TOKEN_EXPIRATION_MARGIN, KEYCLOAK_REALM, MAX_GET_SIZE


class TrendMinerSession(requests.Session):
    """Low level client for TrendMiner API calls

    This class automates some boilerplate that are needed for TrendMiner appliance requests, or SDK development:
    - Handles Keycloak authentication by adding the access token to the headers, and refreshing expired token
    - Adds the appliance base url to every request, so that a relative url can be given
    - Provide easy access to decoded Keycloak token
    - Provides interfaces for automatically iterating over paginated responses
    - Globally set SSL verification, request timeout parameters, and user agent for all requests. Currently, only the
    turning off of SSL verification by the user (``verify=False``) is supported.

    The session is meant for internal use, but could also be used to send custom requests through the client instance
    (e.g. ``client.session.get("custom_endpoint/object")``)
    """

    def __init__(
            self,
            base_url,
            verify,
            timeout,
            proxies,
            user_agent=DEFAULT_USER_AGENT,
            token_expiration_margin=TOKEN_EXPIRATION_MARGIN,
    ):
        super().__init__()

        self.base_url = base_url

        self.fixed_hooks = []

        if not verify:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.verify = verify

        self.token_expiration_margin = token_expiration_margin
        self.timeout = timeout
        self.headers.update({
            "User-Agent": user_agent,
            "Accept": "application/json, text/plain, */*"
        })

        if proxies is not None:
            self.proxies.update(proxies)

        # Initializing -- these attributes will be set after logging in via Keycloak
        self.keycloak_openid = None  # keycloak package KeycloakOpenID object
        self.token = None  # Keycloak token dict
        self._token_decoded = None  # Decoded Keycloak token
        self.mode = None
        self.token_refresh = self._refresh_none

    def _set_openid(self, client_id, client_secret):
        url = self._join_base_url('auth/')
        self.keycloak_openid = keycloak.KeycloakOpenID(
            server_url=url,
            realm_name=KEYCLOAK_REALM,
            client_id=client_id,
            client_secret_key=client_secret,
            verify=self.verify,
            custom_headers=None,
            proxies={key + "://": value for key, value in self.proxies.items()},
            timeout=self.timeout,
        )

    def _refresh_none(self):
        raise ValueError(f"No token refresh possible for authentication mode '{self.mode}'")

    def _refresh_keycloak(self):
        self.token = self.keycloak_openid.refresh_token(self.token['refresh_token'])

    def _refresh_openid(self):
        self._set_openid(client_id=self.keycloak_openid.client_id, client_secret=self.keycloak_openid.client_secret_key)
        self.token = self.keycloak_openid.token(grant_type=self.mode)

    def login(
            self,
            client_id=None,
            client_secret=None,
            username=None,
            password=None,
            token=None,
    ):
        """Use credentials to receive valid Keycloak tokens, or input a valid token directly. Client ID and Client
        secret give access by themselves, but to access user resources also a valid username and password need to be
        given"""

        # Set openid even if no id and secret are given
        self._set_openid(client_id, client_secret)
        self.token = token

        if client_id and client_secret:
            if (username or password) or token:
                self.mode = "password"
                self.token_refresh = self._refresh_keycloak
            else:
                self.mode = "client_credentials"
                self.token_refresh = self._refresh_openid

            if not token:
                self.token = self.keycloak_openid.token(username=username, password=password, grant_type=self.mode)
            else:
                self.token = token

        if client_id and not self.token:
            raise ValueError("Incorrect credentials; no token set")

    def logout(self):
        """Explicitly log out user, invalidating token"""
        self.keycloak_openid.logout(self.token["refresh_token"])

    def assure_valid_token(self):
        """Refreshes the token if it has expired"""
        if not self.access_expired:
            return
        self.token_refresh()

    @property
    def token(self):
        """Dictionary with Keycloak token data"""
        return self._token

    @token.setter
    def token(self, token):
        """Setting the Keycloak token refreshes the expiration dates and the session headers"""
        self._token = token
        if token is None:
            return
        self.headers.update({"Authorization": "Bearer " + self.token['access_token']})
        self._token_decoded = self._decode_token(token)

    @property
    def token_decoded(self):
        """Dictionary with info from decoded Keycloak token

        Returns
        -------
        dict
            Decoded Keycloak token
        """
        return self._token_decoded

    def _decode_token(self, token):
        """Decodes a Keycloak token to human-readable dict

        Parameters
        ----------
        token : dict
            Keycloak token

        Returns
        -------
        dict
            Decoded Keycloak token
        """
        # Token validation needs to be off to avoid errors on token expiration when mocking previously recorded
        # responses (of which the token will be be long since expired).
        return self.keycloak_openid.decode_token(token["access_token"], validate=False)

    @property
    def access_expired(self):
        """Whether Keycloak token has expired

        Returns
        -------
        bool
            Whether Keycloak token has expired
        """
        # Cannot pandas.Timestamp due to compatibility with freezegun for test mocking (conftest.py)
        expiration_time = datetime.fromtimestamp(self.token_decoded["exp"] - self.token_expiration_margin, tz=pytz.utc)
        return datetime.now(tz=pytz.utc) > expiration_time

    def _join_base_url(self, url):
        """Adds base url so the relative path can be given in requests

        Parameters
        ----------
        url : str
            Relative url (does not include the appliance base url)

        Returns
        -------
        str
            Complete url, including the appliance base url, to be used in requests
        """
        return urljoin(self.base_url, url)

    def _set_kwargs(self, kwargs):
        """Prepare the kwargs for an HTTP request by inserting default parameters, if not already present."""

        # Default values
        kwargs.setdefault('timeout', self.timeout)
        kwargs.setdefault('verify', self.verify)
        kwargs.setdefault('hooks', {"response": [raise_all]})

        # Handle hooks: run session fixed hooks (e.g. logging responses) first, then function input hooks
        response_hooks = kwargs['hooks'].get("response", [])
        response_hooks = [response_hooks] if not isinstance(response_hooks, (list, tuple)) else response_hooks
        kwargs['hooks'].update({"response": self.fixed_hooks + response_hooks})

        return kwargs

    def request(self, method, url, **kwargs):
        """Overrides requests.Session.request to add additional functionalities.

        Takes relative url, automatically updates keycloak token if needed, and sets instance values as defaults for
        timeout and verify.

        Because direct methods like Session.post(...) just call Session.request(method="POST", ...), we only need to
        overwrite this method to take care of all TrendMinerSession requests.

        Parameters
        ----------
        method : str
            GET, POST, PUT or DELETE
        url : str
            Relative url. The base url of the appliance is added automatically

        Returns
        -------
        requests.Response
            request response
        """
        self.assure_valid_token()
        response = super().request(method=method, url=self._join_base_url(url), **self._set_kwargs(kwargs))
        return response

    def paginated(self, keys, total=True, json_params=False):
        """Creates an interface to iterate over paginated data

        The interface can iterate a request over multiple pages, and joins the main outputs together in a single list.

        Works for data that is literally paginated, i.e., where the current page and total numer of pages are returned
        as part of the response.

        Parameters
        ----------
        keys : list
            References to the data that needs to be extracted from the subsequent requests. All other data in the json
            response is discarded. For example, for ``keys=["content", "properties"]``, the iterator will return a list
            of ``response.json()["content"]["properties"]``.
        total : bool, default True
            Whether the total number of pages is returned by the endpoint. When this is not the case (at least one known
            example), we cannot go by the totalPages parameter and instead need to iterate until the size of the content
            is smaller than the get size. In this case we do need to pay attention that the max get size is actually
            attainable by the endpoint. Otherwise, only the first page will be returned.
        json_params : bool, default False,
            Whether the `size` and `page` parameters are given as part of the json payload to the post request rather
            than url parameters.

        Returns
        -------
        PageIterator
            An instance that can iterate over multiple requests until all data is returned, that extracts data from
            every response based on the given keys, giving a list of outputs.
        """
        if total:
            return PageIterator(session=self, keys=keys, json_params=json_params)
        return PageIteratorNoTotal(session=self, keys=keys, json_params=json_params)

    def continuation(self, keys):
        """Creates an interface to iterate over paginated data

        The interface can iterate a request over multiple pages, and joins the main outputs together in a single list.

        Works for data that is returned with a continuation token. Subsequent requests using the returned continuation
        tokens need to be done, until the response is empty.

        Parameters
        ----------
        keys : list
            References to the data that needs to be extracted from the subsequent requests. All other data in the json
            response is discarded. For example, for ``keys=["content", "properties"]``, the iterator will return a list
            of ``response.json()["content"]["properties"]``.

        Returns
        -------
        ContinuationIterator
            An instance that can iterate over multiple requests until all data is returned, that extracts data from
            every response based on the given keys, giving a list of outputs.
        """
        return ContinuationIterator(session=self, keys=keys)


class PageIterator:
    """Can iterate a request over multiple pages, and joins the main outputs together in a single list.

    Works for data that is literally paginated, i.e., where the current page and total numer of pages are returned as
    part of the response.
    """
    def __init__(self, session, keys, json_params):
        self.session = session
        self.keys = ip.any_list(keys)
        if json_params:
            self.setter_key = "json"
        else:
            self.setter_key = "params"
        self.json_params = json_params

    def _extract_content(self, data):
        """Extract relevant content from a single json response"""
        value = data
        try:
            for key in self.keys:
                value = value[key]
            return value
        except KeyError:
            return []

    def _iterate_requests(self, method, url, **kwargs):
        """Iterate a given request to extract all paginated data"""
        kwargs.setdefault(self.setter_key, {"page": 0})
        kwargs[self.setter_key].update({"page": 0})

        responses = [self.session.request(method=method, url=url, **kwargs)]
        total_pages = responses[0].json()["page"]["totalPages"]

        if total_pages == 1:
            return responses

        for page in range(1, total_pages):
            kwargs[self.setter_key].update({"page": page})
            responses.append(self.session.request(method=method, url=url, **kwargs))

        return responses

    def _content_list(self, method, url, **kwargs):
        """Iterate a given request, and then extract the relevant data from each request, returning a list"""
        responses = self._iterate_requests(method=method, url=url, **kwargs)
        return [item for r in responses for item in self._extract_content(r.json())]

    def get(self, url, **kwargs):
        """Iterate a GET request, returning a list of content requested from each subsequent request"""
        return self._content_list(method="GET", url=url, **kwargs)

    def post(self, url, **kwargs):
        """Iterate a POST request, returning a list of content requested from each subsequent request"""
        return self._content_list(method="POST", url=url, **kwargs)


class PageIteratorNoTotal(PageIterator):
    """Iterate over multiple pages when the total number of pages is not returned correctly

    Some endpoints always return the totalPages parameters as 1, even though there are more pages. The only way to
    correctly iterate in that case is to keep incrementing the page number until the response size is smaller than the
    get size.
    """

    def _iterate_requests(self, method, url, **kwargs):
        """This method can no longer be used, we need to extract as we iterate"""
        raise NotImplementedError

    def _content_list(self, method, url, **kwargs):
        """Iterate a given request, and then extract the relevant data from each request, returning a list"""
        full_output = []
        kwargs.setdefault(self.setter_key, {"page": 0, "size": MAX_GET_SIZE})
        page = 0
        size = kwargs[self.setter_key]["size"]
        while True:
            kwargs[self.setter_key].update({"page": page})
            response = self.session.request(method=method, url=url, **kwargs)
            output = response.json()
            for key in self.keys:
                output = output[key]
            full_output = full_output + output
            if len(output) < size:
                break
            page += 1

        return full_output


class ContinuationIterator:
    """Can iterate a request over multiple pages, and joins the main outputs together in a single list.

    Works for data that is returned with a continuation token. Subsequent requests using the returned continuation
    tokens need to be done, until the response size is smaller than the get size.
    """
    def __init__(self, session, keys):
        self.session = session
        self.keys = ip.any_list(keys)

    def _content_list(self, method, url, **kwargs):
        """Iterate a given request, and then extract the relevant data from each request, returning a list"""
        full_output = []
        continuation_token = ""
        kwargs.setdefault("json", {"fetchSize": MAX_GET_SIZE})
        size = kwargs["json"]["fetchSize"]
        while True:
            kwargs["json"].update({"continuationToken": continuation_token})
            response = self.session.request(method=method, url=url, **kwargs)
            output = response.json()
            for key in self.keys:
                output = output[key]
            full_output = full_output + output
            if len(output) < size:
                break
            continuation_token = response.json()["page"]["continuationToken"]

        return full_output

    def post(self, url, **kwargs):
        """Iterate a POST request, returning a list of content requested from each subsequent request"""
        return self._content_list(method="POST", url=url, **kwargs)
