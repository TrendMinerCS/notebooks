from .base import TileBase, TileFactoryBase


class ExternalContentTile(TileBase):
    """External content dashboard tile"""
    visualization_type = "EXTERNAL_CONTENT"
    min_size = (1, 2)

    def _json_configuration(self):
        return {
            "url": self.content
        }


class ExternalContentTileFactory(TileFactoryBase):
    """Factory for creating external content dashboard tiles"""
    tm_class = ExternalContentTile

    def _from_json_content(self, data):
        return data["url"]
