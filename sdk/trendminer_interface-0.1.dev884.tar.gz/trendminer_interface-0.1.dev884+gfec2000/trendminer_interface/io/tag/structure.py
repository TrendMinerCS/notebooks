import pandas as pd


def timestamp_insert_colon(timestring):
    return timestring[0:-2] + ":" + timestring[-2:]


def structure_csv(tag_data_dict):
    """Construct DataFrame matching TrendMiner csv import format from list of tags with timeseries data"""

    # Set timezone if absent
    for tag, data in tag_data_dict.items():
        if data.index.tz is None:
            data.index = data.index.tz_localize(tag.client.tz, ambiguous='infer')

    # Join data in single dataframe
    df = pd.concat(
        [data for data in tag_data_dict.values()],
        axis=1,
        keys=[tag.name for tag in tag_data_dict],
    )

    # Empty values need to be blank for the import
    df.fillna("", inplace=True)

    # Set index to correct string format
    df.index = df.index.strftime("%Y-%m-%dT%H:%M:%S%z").map(timestamp_insert_colon)

    # Columns need to contain metadata for the import. Digital tag import not supported, map to digital.
    df.columns = pd.MultiIndex.from_tuples(
        zip(
            df.columns,
            [tag.description for tag in tag_data_dict],
            [tag.units for tag in tag_data_dict],
            ["string" if tag.tag_type.lower() == "digital" else tag.tag_type.lower() for tag in tag_data_dict],
        )
    )
    return df
