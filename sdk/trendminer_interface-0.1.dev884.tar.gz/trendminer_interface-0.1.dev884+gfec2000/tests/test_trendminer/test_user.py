def test_self(client, user1):
    assert user1.user.from_client()
    assert user1.user.from_client(client)
    assert client.user.from_client()
    assert client.user.from_client(user1)


def test_everyone(client):
    assert client.user.everyone


def test_search(client, user1):
    user = client.user.from_name(user1.username)
    assert client.user.search(user.name)
    # TODO: statements below do not work in R1.0 (but do work in future versions)
    # assert client.user.search(user.first_name.replace(" ", "*"))
    # assert client.user.search(user.last_name.replace(" ", "*"))
    assert client.user.search(user.mail)
    assert client.user.from_identifier(user.identifier)
