def test_create(user1, prefix):

    folder = user1.folder.from_path(prefix, create_new=True)

    a = user1.aggregation(
        target="TM_hour_Europe_Brussels",
        name=prefix,
        operator="average",
        window="1h",
        position="backward",
        folder = folder,
    )

    a.post()
    a.window = "2h"
    a.put()

    assert user1.aggregation.all()
    assert user1.aggregation.from_identifier(a.identifier)
    assert user1.aggregation.from_path(f"{prefix}/{prefix}")
    assert user1.aggregation.from_name(prefix)
    assert folder.browse(included=["aggregation"])
    assert folder.get(name=prefix)

    a.delete()
    folder.delete()
