trendminer-interface
====================

.. toctree::
    :maxdepth: 2

    how_to/index
    use_cases/index
    admin workflows/index
    references
    structure_test
    .. understand/index