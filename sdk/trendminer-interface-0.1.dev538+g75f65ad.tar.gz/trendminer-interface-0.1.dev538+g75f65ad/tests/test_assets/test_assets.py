import pandas as pd


def test_asset(user1, af_name):

    # Root
    root = user1.asset.root()
    print(root.children)

    # Asset get
    asset = user1.asset.from_path(f"{af_name}/Hasselt/Plant")
    asset = user1.asset.from_identifier(asset.identifier)
    asset = user1.asset.get(f"{af_name}/Hasselt/Plant")
    print(asset.source)
    print(asset.children)
    print(asset.parent)
    print(asset.path)

    # Attribute get
    attribute = user1.asset.from_path(f"{af_name}/Hasselt/Time/Hour")
    attribute = user1.asset.from_identifier(asset.identifier)
    attribute = user1.asset.get(f"{af_name}/Hasselt/Time/Hour")
    print(attribute.source)
    print(attribute.tag)
    print(attribute.parent)
    print(attribute.path)

    # Asset search
    assert user1.asset.by_template("time tags")
    assert user1.asset.by_template("time tags", frameworks=[af_name])

    assert user1.asset.by_name(ref="Hasselt")
    assert user1.asset.by_name(ref="Hasselt", frameworks=af_name)

    assert user1.asset.by_description(ref="US offices")
    assert user1.asset.by_description(ref="US offices", frameworks=af_name)

    # Attribute search
    assert user1.asset.by_name(ref="day", frameworks=[af_name])
    assert user1.asset.by_template(ref="day", frameworks=af_name)
    assert user1.asset.by_description(ref="Product density", frameworks=[af_name])


def test_frameworks(admin):
    frameworks = admin.asset.framework.all()[1:5]
    for fw in frameworks:
        print(fw.name)
        print(fw.root_asset.children)
        if fw.sync.status == "DONE_WITH_ERRORS":
            try:
                print(fw.get_errors())
            except FileNotFoundError:
                pass
        elif fw.af_type != "CSV":
            print(fw.af_type)
        else:
            fw.export()


def test_framework_create(admin, prefix, user1, mock):

    # Create
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "/"+prefix, prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.post()
    print(af.ordering)
    af.wait_for_sync(sleep=(not mock)*0.5)
    af = admin.asset.framework.from_identifier(af.identifier)

    af.published = True
    af.put()

    # Access rights
    asset = af.root_asset
    asset.access.add(user1.username, "read")
    print(asset.access.all())
    print(asset.children[0].access_inherited.all())
    asset.access.remove(user1.username)
    print(asset.access.all())
    asset.access.add(user1.username, "browse")
    print(asset.access.all())
    asset.access.clear()
    print(asset.access.all())

    # Delete
    af.delete()


def test_framework_errors(admin, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "incorrect path", prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.post()
    while True:
        if af.sync.status != "RUNNING":
            break
    print(af.get_errors())
    af.delete()


def test_sync_status(admin):
    syncs = admin.asset.framework.sync.all()
    print(syncs)
    print(syncs[0].started)
    print(syncs[0].ended)
