import pytest
from datetime import timedelta


def test_workflow(admin, user1):

    assert admin.context.workflow.all()
    assert user1.context.workflow.all()

    workflow = admin.context.workflow(
        name=admin.unique_prefix,
        states=["QA_start", "QA_middle", "QA_end"]
    )

    workflow.save()

    assert workflow.__repr__()
    assert workflow.__str__()

    assert admin.context.workflow._get(workflow.name)
    assert admin.context.workflow.from_identifier(workflow.identifier)

    workflow.delete()


def test_field(admin):
    prefix = admin.unique_prefix

    # Only enumeration field can have options
    with pytest.raises(ValueError):
        admin.context.field(
            key=prefix,
            name=prefix,
            field_type="STRING",
            options=["True", "False"]
        )

    field = admin.context.field(
        key=prefix,
        name=f"Name_{prefix}",
        field_type="STRING",
    )
    field.save()
    assert field.__repr__()
    assert field.__str__()
    assert admin.context.field.from_name(field.name)
    assert len(admin.context.field.search(name=field.name)) == 1

    field.delete()


def test_type(admin, user1):
    prefix = admin.unique_prefix

    assert user1.context.type.all()
    assert admin.context.type.all()

    context_type = admin.context.type(
        name=prefix,
        key=prefix,
        workflow="Start end states"
    )

    context_type.save()
    assert context_type.__repr__()
    assert context_type.__str__()

    admin.context.type.from_name(prefix)

    # Test lazy loading of context type workflow attribute
    chv = user1.context.view(
        name=prefix,
        filters=[
            user1.context.filter.context_types([context_type.key])
        ]
    )
    chv.save()
    chv = user1.context.view.from_identifier(chv.identifier)
    assert chv.filters[0].context_types[0].workflow.name == "Start end states"

    chv.delete()
    context_type.delete()


def test_filters(admin):
    prefix = admin.unique_prefix

    # Test context filter queries
    field = admin.context.field(
        name=prefix,
        key=prefix,
        field_type="NUMERIC",
    )
    field.save()

    cfilter = admin.context.filter.field(
        field=field,
        values=[
            {"operator": ">", "value": 12},
            {"operator": "<=", "value": 20},
        ]
    )

    for value in cfilter.values:
        assert value.__repr__()

    field.delete()


def test_items(user1):
    hour = user1.tag.from_name("TM_hour_Europe_Brussels")
    anomaly = user1.context.item(context_type="ANOMALY",
                                 events=["2021", "2022"],
                                 components=["TM_day_Europe_Brussels"])

    anomaly = user1.context.item(context_type="ANOMALY",
                                 events=user1.interval("2021", "2022"),
                                 components=["TM_day_Europe_Brussels"])

    anomaly.save()
    for event in anomaly.events:
        assert event.__repr__()

    anomaly.delete()

    info = user1.context.item(context_type="INFORMATION",
                              events=["2021-01-01"],
                              components=["TM_day_Europe_Brussels"])

    info = user1.context.item(context_type="INFORMATION",
                              events="2021-01-01",
                              components=["TM_day_Europe_Brussels"])

    info = user1.context.item(context_type="INFORMATION",
                              events=user1.interval.from_timedelta("1y"),
                              components=["TM_day_Europe_Brussels"])

    info.save()

    assert info.__repr__()

    info.fields["property"] = "test"
    info.update()

    for f in info.fields:
        assert f == "property"

    del info.fields["property"]
    info.update()

    info = user1.context.item._get(info.identifier)
    info.delete()

    item = user1.context.item(context_type="ANOMALY",
                              components=["TM_day_Europe_Brussels"],
                              events=user1.interval.from_timedelta("8h"),
                              description="sdk test",
                              keywords=["QA"],
                              )
    hour.calculate(
        intervals=[item],
        operation="start",
        key="hour",
        inplace=True,
        fun=lambda x: f"{x:02}:00"
    )
    assert item.fields.get("hour")
    item.save()
    item = user1.context.item._get(item.key)
    item = user1.context.item._get(item.identifier)
    assert item.fields.get("hour")
    item.delete()


def test_item_history(user1):
    prefix = user1.unique_prefix
    item = user1.context.item(context_type="ANOMALY",
                              components=["TM_day_Europe_Brussels"],
                              events=user1.interval.from_timedelta("8h"),
                              description="sdk test",
                              keywords=["QA"],
                              )
    item.save()
    history1 = item.history()
    item.description = "sdk test2"
    item.events = user1.interval.from_timedelta("9h")
    item.save()
    history2 = item.history()
    assert history1 != history2, "history should have changed"
    item.delete()


def test_view(user1):
    prefix = user1.unique_prefix
    folder = user1.folder(prefix)
    folder.save()
    view = user1.context.view(
        [
            user1.context.filter.period("365d")
        ],
        name=prefix,
        description=prefix,
        parent=prefix,
    )
    view.save()
    view = user1.context.view.from_path(f"{prefix}/{prefix}")
    assert view
    assert len(view.filters) > 0
    folder.delete()

    filters = [
        user1.context.filter.period('1h')
    ]
    view = user1.context.view(filters=filters, name=prefix)
    view.save()
    view.filters = view.filters + [user1.context.filter.users(user1.user.from_client())]
    view.description = "new_description"
    view.update()
    view2 = user1.context.view._get(view.identifier)
    assert view2.description == view.description
    view2.delete()


def test_full_flow(admin, af_name):

    prefix=admin.unique_prefix

    # fields
    key_num = prefix + "num"
    f_num = admin.context.field(key=key_num,
                                name=key_num,
                                field_type="Numeric",
                                placeholder='numeric field')
    f_num.save()
    f_num.placeholder = 'edited placeholder'
    f_num.update()

    key_str = prefix + "str"
    f_str = admin.context.field(key=key_str,
                                name=key_str,
                                field_type="STRING",
                                placeholder='string field')
    f_str.save()
    f_str.name = f_str.name + "_edited"
    f_str.update()

    key_enum = prefix + "enum"
    f_enum = admin.context.field(key=key_enum,
                                 name=key_enum,
                                 field_type="enumeration",
                                 placeholder=None,
                                 options=["yes", "no"])
    f_enum.save()
    f_enum.options.append("maybe")
    f_enum.update()

    assert admin.context.field.all()

    # workflow
    wf = admin.context.workflow(name=prefix + "wf",
                                states=["QA_start", "QA_end"],
                                )
    wf.save()
    # types
    type1 = admin.context.type(key=prefix + "t1",
                               name="QA type 1",
                               workflow=wf,
                               fields=[f_num.name, f_str.key, f_enum.identifier],
                               color="green",
                               audit_trail_enabled=True,
                               approvals_enabled=True
                               )
    type1.save()
    type1.name = type1.name + " updated"
    type1.update()

    type2 = admin.context.type(key=prefix + "t2",
                               name="QA type 2",
                               workflow=None,
                               fields=[f_num, f_str],
                               color=None,
                               audit_trail_enabled=False,
                               approvals_enabled=False
                               )
    type2.save()
    type2.color = 'blue'
    type2.fields = type2.fields + [f_enum]
    type2.update()

    # items
    other_property_key = prefix + '_other'
    tag = 'TM_day_Europe_Brussels'
    asset = f"{af_name}/Hasselt/Plant"
    attribute = f"{af_name}/Houston/time/day"

    items = []
    for component in [tag, asset, attribute]:
        item = admin.context.item(context_type=type1.key,
                                  components=[component],
                                  events=admin.interval.from_timedelta('1h'),
                                  keywords=[prefix],
                                  fields={
                                     f_str: 'test',
                                     f_enum.key: 'yes',
                                     f_num.key: 12.3,
                                     other_property_key: 'other',
                                  }
                                  )
        item.save()

        item.approve()
        item.remove_approval()

        item.description = prefix
        item.update()

        item.approve()

        assert item.interval.data
        assert item.key == admin.context.item._get(item.identifier).key
        assert admin.context.item._get(item.key).description == item.description
        items.append(item)

    # filters
    kw = admin.context.filter.keywords([prefix])
    filter_sets = [
        [kw],
        [admin.context.filter.field(field=f_num, values=[">12", ('<', 15)])],
        [admin.context.filter.field(field=f_str, values=['test', 'foo'])],
        [admin.context.filter.field(field=f_enum, values=['yes', 'maybe'])],
        [admin.context.filter.property(key=other_property_key, values='other')],
        [admin.context.filter.approval(True), kw],
        [admin.context.filter.context_types([type1.key])],
        [admin.context.filter.users([admin.user.from_client()]), kw],
        [admin.context.filter.components([tag, asset, attribute]), kw],
        [admin.context.filter.duration(['> 50m', ('<', 3700)]), kw],
        [admin.context.filter.description(prefix)],
        [admin.context.filter.interval(admin.interval.from_timedelta('1h')), kw],
        [admin.context.filter.period("1h"), kw],
        [admin.context.filter.states(['QA_end']), kw],
        [admin.context.filter.interval(admin.interval.from_timedelta('1h').shift("5m"), created_date=True), kw],
        [admin.context.filter.created_date(('<=', admin.now() + timedelta(minutes=5))), kw]
    ]

    for i, filters in enumerate(filter_sets):
        chv_name = f"{prefix}_view{i}"
        chv = admin.context.view(
            name=chv_name,
            description="view test",
            filters=filters,
        )
        chv.save()
        chv = admin.context.view.from_identifier(chv.identifier)
        chv_items = chv.get_items()
        assert len(chv_items) == 3
        assert admin.context.view.search(ref=chv_name)
        chv.delete()

    # cleanup
    for item in items:
        item.delete()
    type1.delete()
    type2.delete()
    f_num.delete()
    f_str.delete()
    f_enum.delete()
    wf.delete()


def test_bulk_items(client):

    prefix = client.unique_prefix

    intervals = client.interval.from_timedelta("1y").split(max_size="1d")
    item = client.context.item("Anomaly", components="TM_day_Europe_Brussels", keywords=[prefix])
    items = [item.copy({"events": interval}) for interval in intervals]
    client.context.item.bulk_post(items)
    chv = client.context.view(
        filters=[
            client.context.filter.keywords([prefix])
        ]
    )
    assert len(chv.get_items()) == len(intervals)
    chv.delete_items()


def test_from_search(user1):

    prefix = user1.unique_prefix

    vbs = user1.search.value(
        queries=[("TM_hour_Europe_Brussels", ">", 12)],
        operator="AND"
    )

    results = vbs.get_results("1M")

    item = user1.context.item(
        context_type="ANOMALY",
        components="TM_day_Europe_Brussels",
        events=None,
        description=None,
        fields=None,
        keywords=[prefix, f"{prefix}/{prefix}.xlsx", prefix]
    )

    # FIXME
    items = [item.copy({"events": result}) for result in results]

    user1.context.item.bulk_post(items)

    chv = user1.context.view(
        filters=[user1.context.filter.keywords([prefix])]
    )
    assert len(chv.get_items()) == len(items)
    chv.delete_items()


def test_filter_modes(admin):

    prefix = admin.unique_prefix

    # create context fields
    key_num = prefix + "num"
    f_num = admin.context.field(key=key_num,
                                name=key_num,
                                field_type="Numeric",
                                placeholder='numeric field')
    f_num.save()

    key_str = prefix + "str"
    f_str = admin.context.field(key=key_str,
                                name=key_str,
                                field_type="STRING",
                                placeholder='string field')
    f_str.save()

    key_enum = prefix + "enum"
    f_enum = admin.context.field(key=key_enum,
                                 name=key_enum,
                                 field_type="enumeration",
                                 placeholder=None,
                                 options=["yes", "no"])
    f_enum.save()

    # create view
    chv = admin.context.view(
        filters=[
            admin.context.filter.period("30d"),
            admin.context.filter.components(mode="non empty"),
            admin.context.filter.description(mode="empty"),
            admin.context.filter.keywords(mode="empty"),
            admin.context.filter.field(f_num, mode="empty"),
            admin.context.filter.field(f_str, mode="empty"),
            admin.context.filter.field(f_enum, mode="empty"),
            admin.context.filter.states(mode="closed")
        ]
    )
    chv.save()
    chv = admin.context.view.from_identifier(chv.identifier)
    chv.get_items()
    chv.delete()
    f_num.delete()
    f_str.delete()
    f_enum.delete()


def test_component_filter(user1, af_name):

    prefix = user1.unique_prefix

    parent = user1.asset.from_path(f"{af_name}/Houston/time")
    child = user1.attribute.from_path(f"{af_name}/Houston/time/day")

    for component in [parent, child]:
        item = user1.context.item(
            context_type="ANOMALY",
            events=user1.interval.from_timedelta("1h"),
            keywords=[prefix],
            components=[component]
        )
        item.save()

    kw = user1.context.filter.keywords([prefix])

    cfilters = [
        (user1.context.filter.components([(parent, "self")]), 1),
        (user1.context.filter.components([(child, "self")]), 1),
        (user1.context.filter.components([(child, "ancestors")]), 2),
        (user1.context.filter.components([(parent, "descendants")]), 2),
        (user1.context.filter.components([(parent, "descendants"), (child, "ancestors")]), 2),
    ]

    for i, cfilter in enumerate(cfilters):
        chv = user1.context.view(
            filters=[kw, cfilter[0]],
            name=f"{prefix}{i}",
        )

        assert len(chv.get_items()) == cfilter[1]

        chv.save()
        chv = user1.context.view.from_identifier(chv.identifier)

        assert len(chv.get_items()) == cfilter[1]

        chv.delete()


def test_attachments(client):

    prefix = client.unique_prefix

    # Initialize item
    item = client.context.item(
        context_type="ANOMALY",
        events=client.interval.from_timedelta("1h"),
        components=["TM_day_Europe_Brussels"]
    )
    item.save()

    # Text
    my_text = "Hello World!"
    item.attachments.add(filename="text.txt", content=my_text)
    item.attachments.add(filename="text_binary.txt", content=b"Hello World!")

    # Svg
    data = '''
    <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
    <rect width="100%" height="100%" fill="lightblue" />
    <text x="10" y="40" font-family="Arial" font-size="20" fill="black">Dummy SVG</text>
    </svg>
    '''
    item.attachments.add(filename="vector.svg", content=data)

    assert len(item.attachments.all()) == 3
    a = item.attachments.from_name("text.txt")
    a = item.attachments.from_identifier(a.identifier)
    a.name = "updated"
    a.update()
    content = a.download()
    assert content.decode("utf-8")== my_text
    a.delete()

    item.delete()
