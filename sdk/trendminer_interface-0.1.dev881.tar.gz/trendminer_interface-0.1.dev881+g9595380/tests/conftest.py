import pytest
import datetime
import pytz
from . import config
from freezegun import freeze_time
from contextlib import contextmanager
import vcr


from trendminer_interface import TrendMinerClient
from confighub_interface import ConfigClient


def pytest_addoption(parser):
    """Add the --record option to control request record/replay behavior

    - When flag is present: requests are run against server, and recorded
    - When flag is nog present: requests are mocked from recorded responses
    """
    parser.addoption(
        "--record",
        action="store_true",
        default=False,
        help="Run real requests and cache the outputs using vcr.py"
    )

cassette_extension = "yaml"
cassette_filter_parameters = ["password", "client_secret"]


@contextmanager
def initialize_client(client_type, credentials, request):
    """Initialize a client for testing with VCR.py recording/replay functionality.

    This context manager handles:
    - VCR cassette management for recording/replaying HTTP interactions
    - Time freezing to ensure consistent timestamps between recordings and replays
    - Unique prefix generation for object naming based on authentication tokens

    Parameters
    ----------
    client_type : class
        Client class. TrendMinerClient or ConfigClient.
    credentials : dict
        Dict of credentials passed to the client
    request : _pytest.fixtures.SubRequest
        Pytest request fixture providing test context for recording setting and cassette path construction


    Yields
    -------
    client : TrendMinerClient or  ConfigClient
        Client initialized for use with pytest and pytest-recording. Additional attributes are added for test control:
        - mock: bool
            True when mocking from recorded responses. False if running real requests against server and recording
            responses for future use.
        - unique_prefix:
            String generated from client token timestamp, which can be used to generate objects with unique names when
            running tests against server. Mock tests will retrieve the correct prefix, and thus the correct object names
            from the recorded token. Example use in tests: `client.formula(name=f"{client.unique_prefix}_sum", ...).

    Notes
    -----
    Cassettes are stored in:
    tests/cassettes/{test_function_name}/{fixture_name}.yaml

    The time is frozen (with `tick=True`) to the token initialization time (iat claim) for both live and mock tests.
    This ensures consistent timestamps between recording and replay. For live tests, there will only be a minimal
    difference between frozen and real time (the time to return the token from the server).

    Raises
    ------
    FileNotFoundError
        When running without --record and the required cassette file
        doesn't exist.

    """

    record = request.config.getoption("--record")

    cassette_path = request.path.parent.joinpath(
        "cassettes",
        request.path.with_suffix("").name,
        request.function.__name__,
        request.fixturename + "." + cassette_extension
    )

    if record:
        vcr_record_mode = "all"
        cassette_path.unlink(missing_ok=True)  # remove existing cassette file
    else:
        vcr_record_mode = "none"
        if not cassette_path.exists():
            raise FileNotFoundError(
                f"Expecting file with recorded responses for mocking: {cassette_path}\n"
                f"Add --record flag to pytest to run live tests against configured server (tests/config.py)"
                f"and store the responses for subsequent mock testing.\n"
                f"Refer to tests/README.md for more details."
            )

    test_vcr = vcr.VCR(
        serializer=cassette_extension,
        cassette_library_dir=str(cassette_path.parent),
        record_mode=vcr_record_mode,
        filter_query_parameters=cassette_filter_parameters,
        filter_post_data_parameters=cassette_filter_parameters,
    )

    with test_vcr.use_cassette(cassette_path.name) as cassette:

        # Set initial artificial time to avoid issues with the token appearing as expired for the requests that happen
        # on instantiation of the Client.
        freezer = freeze_time("2024-01-01 00:00:00", tick=False)
        freezer.start()

        # Initialize the client
        client = client_type(**credentials)

        # Stop first freezer
        if freezer:
            freezer.stop()

        # Give the client the info on whether it is mocking
        client.mock = not record

        # Get a unique prefix based on token initialization time
        client.unique_prefix = str(client.session.token_decoded["iat"])

        # Freeze time to token initialization time.
        token_issue_time = datetime.datetime.fromtimestamp(
            client.session.token_decoded["iat"],
            pytz.utc,
        )
        freezer = freeze_time(token_issue_time, tick=True)
        freezer.start()

        # Yield client
        yield client

        # Freezer cleanup
        if freezer:
            freezer.stop()


@pytest.fixture
def client(request):
    """Yields client user TrendMinerClient

    Set with only client ID and client secret

    Credentials are taken from tests/config.py; it is the tester's responsibility that the provided credentials are
    correct and lead to a client with the correct access rights.

    Yields
    ------
    client : TrendMinerClient
    """
    with initialize_client(TrendMinerClient, config.client, request) as client:
        yield client


@pytest.fixture
def user1(request):
    """Yields a regular user client

    Set with client ID/secret + username/password

    Credentials are taken from tests/config.py; it is the tester's responsibility that the provided credentials are
    correct and lead to a client with the correct access rights.

    Yields
    ------
    user1 : TrendMinerClient
    """
    with initialize_client(TrendMinerClient, config.user1, request) as client:
        yield client


@pytest.fixture
def user2(request):
    """Yields a regular user client

    Set with client ID/secret + username/password

    A second regular user is required to tests interactions between two users.

    Credentials are taken from tests/config.py; it is the tester's responsibility that the provided credentials are
    correct and lead to a client with the correct access rights.

    Yields
    ------
    user2 : TrendMinerClient
    """
    with initialize_client(TrendMinerClient, config.user2, request) as client:
        yield client


@pytest.fixture
def admin(request):
    """Yields an application admin client

    Set with client ID/secret + username/password

    Credentials are taken from tests/config.py; it is the tester's responsibility that the provided credentials are
    correct and lead to a client with the correct access rights.

    Yields
    ------
    admin : TrendMinerClient
    """
    with initialize_client(TrendMinerClient, config.application_administrator, request) as client:
        yield client


@pytest.fixture
def cfg(request):
    """Yields a system admin client

    Set with client ID/secret + username/password

    Credentials are taken from tests/config.py; it is the tester's responsibility that the provided credentials are
    correct and lead to a client with the correct access rights.

    Yields
    ------
    cfg : ConfigClient
    """
    with initialize_client(ConfigClient, config.system_administrator, request) as client:
        yield client


@pytest.fixture
def af_name(request):
    """
    Asset framework name fixture

    Parameters
    ----------
    request: _pytest.fixtures.SubRequest
        pytest request

    Returns
    -------
    af_name: str
        Asset framework name matching the chosen test configuration
    """

    return config.asset_framework_name
