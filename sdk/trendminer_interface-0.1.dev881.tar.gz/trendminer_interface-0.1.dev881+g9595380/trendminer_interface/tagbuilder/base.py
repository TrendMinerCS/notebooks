import abc
from trendminer_interface.base import WorkOrganizerObjectBase
from trendminer_interface.tag import TagFactory


class TagBuilderTagBase(WorkOrganizerObjectBase, abc.ABC):
    """Base class for tag builder tags"""

    def delete(self):
        """Delete the formula tag

        Tag is automatically renamed before (soft) deletion to keep the original name available for new tags.
        """
        # Rename before deleting to free the name
        self.name = "api_delete_" + self.client.now().isoformat(timespec="milliseconds")
        self.update()
        super().delete()

    @property
    def tag(self):
        """The tag made by the formula

        Returns
        -------
        Tag
        """
        return TagFactory(client=self.client).from_name(self.name)
