Structure
=========

.. raw:: html

   <style>
   .red-node {
       color: red;
   }
   </style>

   <pre>
   <code>
   ── Root
   │  ├── <a href="#node1">Node 1</a>
   │  │  ├── <a href="#subnode1">Subnode 1</a>
   │  │  └── <a href="#subnode2">Subnode 2</a>
   │  └── Node 2
   └── <span class="red-node">Leaf</span>
   </code>
   </pre>

.. _node1:

Node 1
======

This is the detailed explanation of Node 1.

.. _subnode1:

Subnode 1
---------

This is the detailed explanation of Subnode 1.

.. _subnode2:

Subnode 2
---------

This is the detailed explanation of Subnode 2.