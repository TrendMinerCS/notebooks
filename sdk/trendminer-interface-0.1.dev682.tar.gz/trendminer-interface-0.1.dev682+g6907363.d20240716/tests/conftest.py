import keyring
import pytest
import pickle
import json
import glob
import os
import re
import datetime
from typing import Type

from trendminer_interface import TrendMinerClient
from confighub_interface import ConfigClient
from tests.mock import MockClient, MockConfigClient

from ._default_mode import default_mode


def pytest_addoption(parser):

    parser.addoption(
        "--mode",
        action="store",
        default=default_mode,
        choices=("mock", "real", "log"),
        help="test mode"
             "\n log: runs everything against server, stores outputs for later mocking"
             "\n real: runs everything against server without storing output"
             "\n mock: runs all function against responses cached by running 'log' earlier"
    )

    parser.addoption(
        "--config",
        action="store",
        default="",
        help="test configuration key for runs against a server"
    )


def get_folders(request):
    # Base path on test function being executed
    relative_path = re.match("(.*/).*\\.py::.*", os.getenv("PYTEST_CURRENT_TEST"))[1] + request.function.__name__
    main = __file__.replace("tests/conftest.py", relative_path)

    folder_response = os.path.join(main, "response")
    folder_body = os.path.join(main, "body")
    folder_pickle = os.path.join(main, "pickle")

    # Make sure main path exists for logging
    if request.config.getoption("--mode").lower().strip() == "log":
        os.makedirs(main, exist_ok=True)
        os.makedirs(folder_response, exist_ok=True)
        os.makedirs(folder_body, exist_ok=True)
        os.makedirs(folder_pickle, exist_ok=True)

    return {
        "main": main,
        "response": folder_response,
        "body": folder_body,
        "pickle": folder_pickle,
    }


def log_client(folders, request, client):

    client.history_df.to_csv(os.path.join(folders["main"], f'{request.fixturename}.csv'))

    for i, response in enumerate(client.history):

        f_pickle = os.path.join(folders["pickle"], f"{request.fixturename}{i:03}.pkl")
        with open (f_pickle, 'wb') as f:
            pickle.dump(response, f)

        f_response = os.path.join(folders["response"], f"{request.fixturename}{i:03}.json")
        try:
            with open(f_response, 'w') as f:
                json.dump(response.json(), f, indent=4)

        except json.JSONDecodeError:
            with open(f_response, 'wb') as f:
                f.write(response.content)

        if response.request.body is None:
            continue
        try:
            data = json.loads(response.request.body)
            f_body = os.path.join(folders["body"], f"{request.fixturename}{i:03}.json")
            with open(f_body, 'w') as f:
                json.dump(data, f, indent=4)
        except json.JSONDecodeError:
            f_body = os.path.join(folders["body"], f"{request.fixturename}{i:03}.txt")
            if isinstance(response.request.body, str):
                data = response.request.body
                data = re.sub("(?<=password=)[^\n]*", "***********", data)  # do not print password
                with open(f_body, 'w') as f:
                    f.write(data)
            else:
                with open(f_body, 'wb') as f:
                    f.write(response.request.body)


def clear_history(folders, request):
    for filename in glob.glob(os.path.join(folders['response'], f"*.json")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['pickle'], f"*.pkl")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['body'], f"*.json")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['main'], f"*.csv")):
        os.remove(filename)
    for filename in glob.glob(os.path.join(folders['main'], f"*.txt")):
        os.remove(filename)


def get_history(folders, request):
    responses = []
    filenames = glob.glob(os.path.join(folders['pickle'], f"{request.fixturename}*.pkl"))
    filenames = sorted(filenames)
    for filename in filenames:
        with open(filename, "rb") as f:
            responses.append(pickle.load(f))
    return responses


def get_configuration_data(request):
    key = request.config.getoption("--config")

    # Use default configuration
    if not key:
        with open(__file__.replace("conftest.py", "_config/defaults.json")) as f:
            key = json.load(f)["configuration"]

    with open(__file__.replace("conftest.py", f"_config/configurations/{key}.json")) as f:
        data = json.load(f)

    return data


def open_client(request, user_key, client_type: Type = TrendMinerClient, mock_type: Type = MockClient):
    folders = get_folders(request)

    data = get_configuration_data(request)

    credentials = {
        "url": data["url"],
        "client_id": data["users"]["client"],
        "client_secret": keyring.get_password(data["url"], data["users"]["client"]),

    }

    if user_key != "client":
        credentials.update(
            {
                "username": data["users"][user_key],
                "password": keyring.get_password(data["url"], data["users"][user_key])
            }
        )

    mode = request.config.getoption("--mode")
    if mode == "mock":
        client = mock_type(**credentials, history=get_history(folders, request))
    elif mode == "real":
        client = client_type(**credentials, keep_history=False)
    elif mode == "log":
        clear_history(folders, request)
        client = client_type(**credentials, keep_history=True)
    else:
        raise ValueError

    return client, folders, mode


@pytest.fixture
def client(request):
    client, folders, mode = open_client(request, user_key="client")
    yield client
    if mode == "log":
        log_client(folders, request, client)


@pytest.fixture
def user1(request):
    client, folders, mode = open_client(request, user_key="user1")
    yield client
    if mode == "log":
        log_client(folders, request, client)


@pytest.fixture
def user2(request):
    client, folders, mode = open_client(request, user_key="user2")
    yield client
    if mode == "log":
        log_client(folders, request, client)


@pytest.fixture
def admin(request):
    client, folders, mode = open_client(request, user_key="admin")
    yield client
    if mode == "log":
        log_client(folders, request, client)


@pytest.fixture
def cfg(request):
    client, folders, mode = open_client(
        request,
        user_key="admin",
        client_type=ConfigClient,
        mock_type=MockConfigClient
    )
    yield client
    if mode=="log":
        log_client(folders, request, client)


@pytest.fixture
def prefix(request):
    """Yields a time-based prefix for creating new items to avoid clashes with existing or soft-deleted items"""

    folders = get_folders(request)
    file_path = os.path.join(folders["main"], f"prefix.txt")

    mode = request.config.getoption("--mode")
    if mode == "mock":
        with open(file_path, "r") as f:
            pf = f.read()
    else:
        data = get_configuration_data(request)
        pf = f"{data['prefix']}{round(datetime.datetime.now().timestamp()*1000)}"

    yield pf

    if mode == "log":
        with open(file_path, "w") as f:
            f.write(pf)


@pytest.fixture
def af_name(request):
    """
    Asset framework name fixture

    Parameters
    ----------
    request: _pytest.fixtures.SubRequest
        pytest request

    Returns
    -------
    af_name: str
        Asset framework name matching the chosen test configuration
    """

    return get_configuration_data(request)["af"]


@pytest.fixture
def mock(request):
    """
    Boolean on whether we are running a mock test

    Parameters
    ----------
    request: _pytest.fixtures.SubRequest
        pytest request

    Returns
    -------
    mock: bool
        Whether we are running a mock test

    """
    if request.config.getoption("--mode").lower().strip() == "mock":
        return True
    return False
