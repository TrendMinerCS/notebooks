from pprint import pprint


def test_csv_upload(user1):
    prefix = user1.unique_prefix
    tags = user1.tag.list(["TM_day_Europe_Brussels", "TM_hour_Europe_Brussels", "TM_year_Europe_Brussels"])
    interval = user1.interval.from_timedelta("1d").shift("-1d")
    for tag in tags:
        tag.name = f"{prefix}_{tag.name}"
    tag_data = {tag: tag.get_data(interval) for tag in tags}
    user1.io.tag.post(tag_data)
    user1.io.tag.post(tag_data)
    tag1 = tags[0]
    tag1 = user1.io.tag.from_name(tag1.name)
    user1.io.tag.delete(tag1)
    user1.io.tag.delete_all()


def test_work(user1):
    data = user1.io.work.export()
    data.update({"saved-items": []})  # empty the export
    user1.io.work.upload(data)  # upload empty data
    pprint(user1.io.work.result())
