from pprint import pprint


def test_create(user1):

    prefix = user1.unique_prefix

    hour = user1.tag.from_name("TM_hour_Europe_Brussels")
    search = user1.search.value(
        queries=[
            (hour, ">", 24)
        ],
        name=prefix,
    )
    search.post()

    monitor = user1.monitor.from_search(search)
    monitor._full_instance()
    monitor.email.to = "test@trendminer.com"
    monitor.email.subject = prefix
    monitor.email.message = "QA SDK"
    monitor.email.enabled = True

    monitor.webhook.url = "https://www.trendminer.com"
    monitor.webhook.enabled = True
    monitor.enabled = True

    item = user1.context.item(
        context_type="ANOMALY",
        components=[hour],
        description=prefix,
        keywords=[prefix]
    )
    monitor.context.item = item
    monitor.context.enabled = True
    monitor.put()
    monitor = user1.monitor.from_search(search)
    assert monitor.context.item is not None
    monitor.enabled = False
    monitor.put()
    search.delete()


def test_overview(user1):

    prefix = user1.unique_prefix

    hour = user1.tag.from_name("TM_hour_Europe_Brussels")
    search = user1.search.value(
        queries=[
            (hour, ">", 24)
        ],
        name=prefix,
    )
    search.post()
    assert user1.monitor.all(active_only=False)

    monitor = user1.monitor.from_search(search)
    monitor.enabled = True
    monitor.put()


    assert user1.monitor.from_identifier(monitor.identifier)
    assert user1.monitor.from_name(monitor.name)

    assert user1.monitor.all()

    pprint(user1.monitor.overview(since="2022-01-01"))

    search.delete()
