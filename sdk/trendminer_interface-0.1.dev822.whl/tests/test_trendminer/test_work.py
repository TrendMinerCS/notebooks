import pytest


def test_folder(user1):
    prefix = user1.unique_prefix
    new_folder = user1.folder(name=prefix, parent=None)
    new_folder.post()
    new_folder.name = prefix + "_edited"
    new_folder.put()
    new_folder = user1.folder.get(new_folder.identifier)
    new_subfolder = user1.folder(name=prefix, parent=new_folder.identifier)
    new_subfolder.post()
    new_folder.delete()


def test_browse(user1, user2):
    prefix = user1.unique_prefix
    folder = user1.folder(name=prefix, parent=None)
    folder.post()
    chv = user1.context.view(name=prefix, filters=user1.context.filter.period('1h'), parent=folder)
    chv.post()
    chv.access.add(user2.user.self().name, "read")
    assert chv.identifier in [item.identifier for item in folder.get_children()]
    assert chv.identifier in [item.identifier for item in folder.get_children(included=chv.content_type)]
    folder.delete()
    with pytest.raises(ValueError):
        folder.get_children(excluded="non-existing-content-type")
    assert user1.folder.root.get_children()


def test_path(user1):
    prefix = user1.unique_prefix
    path = f"{prefix}_l1/{prefix}_l2/{prefix}_l3"
    user1.folder.from_path(path, create_new=True)
    folder = user1.folder.get(path)
    chv = user1.context.view(name=prefix, parent=folder, filters=user1.context.filter.period('1h'))
    chv.post()
    assert chv.identifier == user1.context.view.get(path + f"/{prefix}").identifier
    assert folder.parent
    main_folder = user1.folder.get(prefix + '_l1')
    assert main_folder.get_children(folders_only=True)
    main_folder.delete()


def test_search(user1):
    prefix = user1.unique_prefix
    assert len(user1.search.value.by_name(prefix)) == 0
    folder = user1.folder(prefix)
    folder.post()
    db = user1.dashboard(tiles=[], name=prefix, parent=folder)
    db.post()
    assert len(user1.dashboard.by_name(prefix)) == 1
    db.delete()
    folder.delete()
