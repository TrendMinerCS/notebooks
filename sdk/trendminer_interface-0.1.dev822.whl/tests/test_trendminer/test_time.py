from datetime import datetime, timedelta
from trendminer_interface.times import Interval, TimedeltaFactory, DatetimeFactory


def test_timedelta(client):
    assert TimedeltaFactory(client=client).get("8h")
    assert TimedeltaFactory(client=client).get("1y12h")
    assert TimedeltaFactory(client=client).get("1d 14h 12s")
    assert TimedeltaFactory(client=client).get("1d 25h 12s")
    assert TimedeltaFactory(client=client).get("10M12d12h5s")
    assert TimedeltaFactory(client=client).get("1y 3M 12d 4m12s 14ms")
    assert TimedeltaFactory(client=client).get("15ms")
    assert TimedeltaFactory(client=client).get("1s").total_seconds() == 1
    assert TimedeltaFactory(client=client).get("135d").total_seconds() == 135*24*3600
    assert TimedeltaFactory(client=client).get(100).total_seconds() == 100
    assert TimedeltaFactory(client=client).get(timedelta(seconds=100)).total_seconds() == 100


def test_datetime(client):
    assert DatetimeFactory(client=client).get("2021").month == 1
    assert DatetimeFactory(client=client).get("2021-02-01 12:00:00.123").month == 2
    assert DatetimeFactory(client=client).get("2021-02-01T12:00:00Z").tzinfo.zone
    assert client.now()
    assert client.index_horizon.tzinfo.zone
    assert DatetimeFactory(client=client).get(datetime(year=2022, month=1, day=1)).tzinfo.zone


def test_interval(client):
    assert client.interval("2021").duration > timedelta(days=365)
    assert client.interval("2021-01-01 12:00:00", "2022").end.month == 1
    assert isinstance(client.interval.from_timedelta("10M12d12h5s"), Interval)
    interval = client.interval.from_timedelta("1h")
    assert isinstance(interval, Interval)
    assert isinstance(interval+"1h", Interval)
    assert isinstance("1h"+interval, Interval)
    assert(client.interval("2022-01-01", "2023-01-01").duration > timedelta(days=360))


def test_rounding(client):

    assert isinstance(TimedeltaFactory(client=client).round("1h30m29s"), timedelta)
    assert isinstance(TimedeltaFactory(client=client).round("1h30m31s"), timedelta)

    assert isinstance(DatetimeFactory(client=client).round("2022-01-01 12:12:40", "1h"), datetime)
    assert isinstance(DatetimeFactory(client=client).floor("2022-01-01 12:12:40", "1h"), datetime)
    assert isinstance(DatetimeFactory(client=client).ceil("2022-01-01 12:12:40", "1h"), datetime)

    interval = client.interval.from_timedelta("1h5m")
    assert interval.ceil(resolution="10m").duration > interval.duration
    assert interval.floor(resolution="10m").duration < interval.duration


def test_invert(client):
    search_interval = client.interval("2023-01-01 10:00", "2023-01-01 22:00")
    included = [
        client.interval("2023-01-01 12:00", "2023-01-01 14:00"),
        client.interval("2023-01-01 18:00", "2023-01-01 20:00"),
    ]
    excluded = client.interval.invert(included, span=search_interval)
    assert excluded


def test_ranges(client):
    weeks = client.interval.range(start="2022-01-01 08:00", freq="W", normalize=False, n_intervals=7)
    assert weeks
    interval = client.interval.from_timedelta("1W")
    assert interval.start
    days = client.interval.range(start=interval.start, end=interval.end, freq="D", normalize=True)
    assert days


def test_in(client):
    assert client.interval("2021-01-01", "2021-01-02") in client.interval("2021-01-01", "2021-01-03")
    assert not (client.interval("2021-01-01", "2021-01-03") in client.interval("2021-01-01", "2021-01-02"))


def test_div(client):
    assert client.interval("2021-01-01", "2021-01-02") / client.interval("2021-01-01", "2021-01-03") == 0.5
    assert client.interval("2021-01-01", "2021-01-03") / client.interval("2021-01-01", "2021-01-02") == 1.0
    assert client.interval("2021-01-01", "2021-01-03") / client.interval("2022-01-01", "2022-01-02") == 0.0


def test_sample(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-01 08:00:00")
    samples = interval.sample("1h", n=6, overlap=False, resolution="1m")
    assert not any([i1/i2 for i1, i2 in zip(samples[0:-1], samples[1:])])
    samples = interval.sample("1h", n=12, overlap=True, resolution="1m")
    assert any([i1/i2 for i1, i2 in zip(samples[0:-1], samples[1:])])


def test_before(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-01 08:00:00")
    interval.before(duration="1h",inplace=True)
    interval1 = interval.before(duration="1h")
    bef_check = client.interval("2021-12-31 23:00:00", "2022-01-01 00:00:00")
    assert interval == bef_check == interval1, "interval.before() does not work properly"


def test_after(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-01 08:00:00")
    interval.after(duration="1h",inplace=True)
    interval1 = interval.after(duration="1h")
    af_check = client.interval("2022-01-01 08:00:00", "2022-01-01 09:00:00")
    assert interval == af_check == interval1, "interval.after() does not work properly"


def test_floor(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-03 08:01:01")
    interval1 = client.interval("2022-01-01 00:00:00", "2022-01-03 08:00:00")
    interval2 = interval.floor(resolution="1h")
    interval.floor(resolution="1h",inplace=True)
    assert interval == interval1 == interval2, "interval.floor() should change resolution"


def test_ciel(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-03 08:01:01")
    interval1 = client.interval("2022-01-01 00:00:00", "2022-01-03 09:00:00")
    interval2 = interval.ceil(resolution="1h")
    interval.ceil(resolution="1h",inplace=True)
    assert interval == interval1 == interval2, "interval.ceil() should change resolution"


def test_shift(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-03 08:00:00")
    interval1 = client.interval("2022-01-01 01:00:00", "2022-01-03 09:00:00")
    interval.shift(shift="1h",inplace=True)
    assert interval == interval1, "interval.shift() should shift the time interval"


def test_sample_interval(client):
    interval = client.interval("2022-01-01 00:00:00", "2022-01-03 08:00:00")
    interval1 = client.interval("2022-01-01 01:00:00", "2022-01-03 09:00:00")
    interval_overlap = [interval,interval1]
    samples = client.interval.sample(interval_overlap, "1h", n=2)
    assert isinstance(samples, list), "Interval.sample should return a list"
    samples_overlap = client.interval.sample(interval_overlap, "1h", n=2, overlap=True)
    assert isinstance(samples_overlap, list), "Interval.sample should return a list"
