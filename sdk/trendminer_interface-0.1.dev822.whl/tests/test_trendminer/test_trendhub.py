from trendminer_interface.base import color
from trendminer_interface.times.interval import Interval


def test_create(user1):
    prefix = user1.unique_prefix
    thv = user1.trend.view(["TM_day_Europe_Brussels"], layers=["8h"], live=True, name=prefix)
    thv.post()
    thv = user1.trend.view.from_path(prefix)
    assert thv.live is True
    thv.live = False
    assert thv.live is False
    folder = user1.folder(prefix)
    folder.post()
    thv.folder = folder
    thv.put()
    folder.delete()


def test_data(user1, af_name):
    prefix = user1.unique_prefix
    thv = user1.trend.view(
        entries=[
            "TM_day_Europe_Brussels",
            "TM_hour_Europe_Brussels",
            f"{af_name}/Houston/Time/hour",
        ],
        layers=[
            ("2020", "2021"),
            ("2021", "2022"),
        ],
        live=True,
        name=prefix
    )
    thv.post()
    thv = user1.trend.view.get(prefix)
    data = thv.get_data(resolution="1d")
    thg = user1.trend.group(["TM_day_Europe_Brussels","TM_hour_Europe_Brussels"], "test group")
    assert isinstance(thg.tags, list), "group.tags() should return a list"
    assert isinstance(thv.layers[0].origin,Interval), "layers.origin() should return object of trendminer_interface.times.interval.Interval class"
    og_layer = thv.layers[0].interval
    new_layer = thv.layers[0].set_interval(('2021-01-01', '2022-01-01'))
    new_layer = thv.layers[0].set_interval(interval=['2021-01-01', '2022-01-01'],align_trailing=True)
    assert og_layer != new_layer, 'set_interval should change the interval'
    thv.delete()


def test_view(user1, af_name):
    prefix = user1.unique_prefix
    day = user1.tag.from_name("TM_day_Europe_Brussels")
    day.color = "green"
    day.color = color.to_color("hsl(120, 100%, 50%)")
    day.color = color.to_color("rgb(255, 0, 0)")
    day.shift = "-30m"
    hour = user1.tag.from_name("TM_hour_Europe_Brussels")
    hour.color = "red"
    hour.visible = False
    attribute = user1.attribute.from_path(f"{af_name}/Houston/Time/hour")
    attribute.shift = "15m"
    attribute.color = "black"
    view = user1.trend.view(
        entries=[
            day,
            hour,
            attribute
        ],
        layers=["8h"]
    )
    assert view.get_session_url()
    data = view.get_data(resolution="15m")[0]
    assert not data.empty
    scatter_prop = user1.trend.chart.scatter(grid=True, histogram=True, colored=True, correlation=True)
    scatter = user1.trend.view(["TM_day_Europe_Brussels", "TM_hour_Europe_Brussels"], layers=["8h"], live=True,name=prefix, chart=scatter_prop)
    settings_scatter = scatter_prop._json_settings()
    trend_prop = user1.trend.chart.trend(grid=True, filling=True, context=True)
    trend = user1.trend.view(["TM_day_Europe_Brussels"], layers=["8h"], live=True, name=prefix, chart=trend_prop)
    settings_trend = trend_prop._json_settings()


def test_view2(user1, af_name):
    prefix = user1.unique_prefix
    view = user1.trend.view(
        name=prefix,
        layers=["8h"],
        entries=[
            f"{af_name}/Houston/Time/hour",
            "TM_hour_Asia_Jakarta",
            user1.trend.group(
                entries=[
                    f"{af_name}/Hasselt/Time/hour",
                    "TM_hour_Japan",
                ],
                scale=[0, 25],
            )
        ]
    )
    view.post()
    view = user1.trend.view.from_identifier(view.identifier)
    view.delete()
