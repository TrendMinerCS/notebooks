def test_intervals(user1):
    intervals = [user1.interval.from_timedelta("1d")]
    f = user1.filter.from_intervals(intervals=intervals, name=f"{user1.unique_prefix}_intervals")
    f.post()
    f = user1.filter.from_identifier(f.identifier)
    f.description = "Updated"
    f.put()
    f.delete()


def test_searches(user1):

    prefix = user1.unique_prefix

    vbs = user1.search.value(
        queries=[("TM_hour_Europe_Brussels", ">", 12)],
        name=prefix,
    )
    vbs.post()

    sim = user1.search.similarity(
        queries=["TM_hour_Europe_Brussels", "TM_year_Europe_Brussels"],
        interval="8h",
        name=f"{prefix}_tag",
        threshold=90,
    )
    sim.post()

    for search in [vbs, sim]:
        f = user1.filter.from_search(search=search, filter_results=True, name=f"{prefix}_inclusive")
        f.post()
        f.properties.search.get_results("1w")
        f = user1.filter.from_identifier(f.identifier)
        f.description = "Updated"
        f.put()
        f.delete()
        search.delete()


def test_work(user1):

    prefix = user1.unique_prefix

    folder = user1.folder(name=prefix)
    folder.post()

    intervals = [user1.interval.from_timedelta("1d")]
    f = user1.filter.from_intervals(
        intervals=intervals,
        name=f"{prefix}",
        description="test",
        parent=prefix,
    )
    f.post()

    f = user1.filter.from_path(f"{prefix}/{prefix}")
    f._load()

    f = user1.filter.from_name(prefix)
    f._load()

    assert user1.filter.by_name(prefix)
    assert user1.filter.all()

    folder.delete()
