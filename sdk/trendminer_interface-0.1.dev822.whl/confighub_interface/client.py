import pytz

from trendminer_interface.authentication import BaseClient, TrendMinerSession

from .connector import ConnectorClient
from .user import ConfigUserClient
from .datasource import DatasourceClient
from .access import AccessClient
from .group import GroupClient
from .client_user import ClientUserClient


class ConfigClient(
    BaseClient,
    ConnectorClient,
    ConfigUserClient,
    DatasourceClient,
    AccessClient,
    GroupClient,
    ClientUserClient,
):

    def __init__(self, url, client_id, client_secret, username, password, verify=True, tz=pytz.utc):
        BaseClient.__init__(
            self,
            url=url,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            verify=verify,
            token=None,
        )

        # TODO: doing same thing as in TrendMinerClient. Should this perhaps be on BaseClient?
        self.tz = pytz.timezone(tz) if isinstance(tz, str) else tz
