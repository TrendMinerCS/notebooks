from trendminer_interface.base import ByFactory, TrendMinerFactory
from trendminer_interface.times import IntervalFactory

from .base import FilterPropertiesBase


class ManualFilterProperties(FilterPropertiesBase):
    """Properties of a manual filter created from a list of intervals

    Attributes
    ----------
    intervals : list of Interval
        Filtered-out intervals
    """
    properties_type = "MANUAL"
    intervals = ByFactory(IntervalFactory, "list")

    def __init__(self, client, intervals):
        super().__init__(client=client)
        self.intervals = intervals

    def _json_properties(self):
        return {
            "periods": [interval._json_short() for interval in self.intervals]
        }


class ManualFilterPropertiesFactory(TrendMinerFactory):
    """Factory for retrieving manual filter properties"""
    tm_class = ManualFilterProperties

    def _from_json(self, data):
        return self.tm_class(
            client=self.client,
            intervals=[
                IntervalFactory(client=self.client)._from_json_short(interval)
                for interval in data["properties"]["periods"]
            ]
        )
