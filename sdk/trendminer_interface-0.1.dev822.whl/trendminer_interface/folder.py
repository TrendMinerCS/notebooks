import re
import abc
import cachetools

from trendminer_interface.work.work_organizer_object import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.base import TrendMinerFactory, MultiFactory, to_subfactory, kwargs_to_class, Authenticated
from trendminer_interface.constants import FOLDER_BROWSE_SIZE, MAX_FOLDER_CACHE, WORK_ORGANIZER_CONTENT_OPTIONS
from trendminer_interface.exceptions import ResourceNotFound
from trendminer_interface.context.view import ContextHubViewFactory
from trendminer_interface.trendhub.view import TrendHubViewFactory
from trendminer_interface.search import ValueBasedSearchFactory, SimilaritySearchFactory
from trendminer_interface.tagbuilder import FormulaFactory, AggregationFactory
from trendminer_interface.dashhub import DashboardFactory
from trendminer_interface.filter import FilterFactory
from trendminer_interface.fingerprint import FingerprintFactory

from trendminer_interface import _input as ip


class FolderClient(abc.ABC):
    """Client for folder factory"""
    @property
    def folder(self):
        """Factory for creating and retrieving folders"""
        return FolderFactory(client=self)


class FolderBase(Authenticated, abc.ABC):
    """Abstract class implementing methods for getting items from a folder or the work organizer root folder"""

    def __init__(self, client):
        super().__init__(client=client)
        self.identifier = None

    def get_children(self, included=None, excluded=None, folders_only=False):
        """Get the items in the current folder

        Parameters
        ----------
        included : list of str, optional
            Included work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        excluded : list of str, optional
            Excluded work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        folders_only : bool, default False
            Whether to only search for subfolders. Ignores `included` and èxcluded`

        Notes
        -----
        In the backend, monitors are included in the work organizer for technical reasons. However, in the user
        interface they are always filtered out. When `excluded` is kept at `None`, monitors are therefore also filter
        out. An empty list needs to provided explicitly to include monitors (`excluded=[]`).
        """
        if excluded is None:
            excluded = ["MONITOR"]
        included = [t if isinstance(t, str) else t.content_type for t in ip.any_list(included)]
        excluded = [t if isinstance(t, str) else t.content_type for t in ip.any_list(excluded)]
        included = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in included]
        excluded = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in excluded]

        params = {
            "size": FOLDER_BROWSE_SIZE,
            "foldersOnly": folders_only,
            "parent": self.identifier,
        }

        if included:
            params.update({"includeTypes": included})
        elif excluded:
            params.update({"excludeTypes": excluded})

        response = self.client.session.get("/work/saveditem/browse", params=params)

        try:
            content = response.json()["_embedded"]["content"]
        except KeyError:
            content = []

        return [
            FolderContentFactory(client=self.client)._from_json_work_organizer(data) for data in content
        ]


    def get_child_from_name(self, ref, included=None, excluded=None, folders_only=False):
        """Get a single object from a folder by its name

        Parameters
        ----------
        ref : str
            Name of the child work organizer object saved in the folder
        included : list of str, optional
            Included work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        excluded : list of str, optional
            Excluded work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        folders_only : bool, default False
            Whether to only search for subfolders. Ignores `included` and èxcluded`

        Notes
        -----
        In the backend, monitors are included in the work organizer for technical reasons. However, in the user
        interface they are always filtered out. When `excluded` is kept at `None`, monitors are therefore also filter
        out. An empty list needs to provided explicitly to include monitors (`excluded=[]`).

        """
        content = self.get_children(included=included, excluded=excluded, folders_only=folders_only)
        return ip.object_match_nocase(content, attribute="name", value=ref)


class WorkOrganizerRoot(FolderBase):
    """Work organize root folder

    The root folder is an artificial construct. It is not an actual folder in the appliance. Its identifier is None, and
    it does not have a name or owner.

    When a work organizer object is stored in the root directory, it does not have a parent (`parent=None`). It does
    NOT have a WorkOrganizerRoot instance as parent.

    This class only implements the methods required to browse the work organizer root folder.
    """
    pass  # All methods are implemented on FolderBase


class Folder(WorkOrganizerObject, FolderBase):
    """Work organizer folder"""
    content_type = "FOLDER"

    def __init__(self, client, identifier, name, parent, owner, last_modified):
        super().__init__(client=client, identifier=identifier, name=name, description=None, parent=parent, owner=owner,
                         last_modified=last_modified)

    def _json_data(self):
        return

    def __json__(self):
        return {
            "id": self.identifier,
            "name": self.name,
            "folder": True,
            "parentId": self.parent.identifier if self.parent else None,
        }

    def _content_blueprint(self):
        raise NotImplementedError()

    # TODO: implement uniform strategy for cacheing and clearing the cache
    def _clear_cache(self):
        """Clear the folder getting cache every time the folder structure is changed"""
        self.client.folder.from_identifier.cache_clear()

    def _put_updates(self, response):
        super()._put_updates(response)
        self._clear_cache()

    def _post_updates(self, response):
        super()._post_updates(response)
        self._clear_cache()

    def _delete_updates(self, response):
        super()._delete_updates(response)
        self._clear_cache()

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< Folder | {str(self)} >>"

    def __str__(self):
        if self.name is None:
            return "<ROOT>"
        return self.name


class FolderFactory(WorkOrganizerFactory):
    """Factory for creating and retrieving folders"""
    tm_class = Folder

    def __call__(self, name, parent=None):
        """Instantiate a new work organizer folder

        Attributes
        ----------
        name : str
            Folder name
        parent : Folder, optional
            Parent folder. Leave at None to create a folder in the root work organizer folder

        Returns
        -------
        Folder
            New folder instance
        """
        return self.tm_class(client=self.client,
                             identifier=None,
                             name=name,
                             parent=parent,
                             owner=None,
                             last_modified=None,
                             )

    @kwargs_to_class
    def _from_json(self, data):
        """Full enriched payload"""
        kwargs = self._json_to_kwargs_base(data)
        kwargs.pop("description")  # no description for folders
        return kwargs

    def _from_json_work_organizer(self, data):
        """Browse payload is equal to full enriched payload"""
        return self._from_json(data)

    @property
    def root(self):
        """WorkOrganizerRoot instance with methods for browsing the work organizer root

        Returns
        -------
        WorkOrganizerRoot
        """
        return WorkOrganizerRoot(client=self.client)

    def from_path(self, ref, create_new=False):
        """Retrieve or create a folder on a given path

        Parameters
        ----------
        ref : str
            Folder path
        create_new : bool, default False
            Whether a new folder needs to be created at the given path if no folder is found there. Creates intermediate
            folders on the path too.

        Returns
        -------
        Folder
            Folder on the given path
        """
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.root

        # Iterate folders
        for part in parts:
            try:
                current_folder = current_folder.get_child_from_name(part, folders_only=True)
            except ResourceNotFound as e:
                if create_new:
                    if isinstance(current_folder, WorkOrganizerRoot):
                        parent = None  # Set parent to None if we are still in the root directory
                    else:
                        parent = current_folder
                    new_folder = self.client.folder(name=part, parent=parent)
                    new_folder.post()
                    current_folder = new_folder
                else:
                    raise e

        return current_folder

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=MAX_FOLDER_CACHE), key=TrendMinerFactory._cache_key_ref)
    def from_identifier(self, ref):
        """Retrieve folder from its identifier

        Parameters
        ----------
        ref : str
            Folder UUID

        Returns
        -------
        Folder
        """
        return super().from_identifier(ref)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path


class WorkOrganizerPlaceholder(WorkOrganizerObject):
    """Placeholder for work organizer objects which have not yet been implemented in the SDK

    These item can be managed and deleted in the work organizer, but they cannot otherwise be interacted with. Their
    data is simply dumped as a dict in the `data` parameter.

    Attributes
    ----------
    data : dict
        Dump of the object json data
    content_type : str
        Work organizer item type
    """
    def __init__(self,
                 client,
                 identifier,
                 name,
                 description,
                 parent,
                 owner,
                 last_modified,
                 data,
                 content_type,
                 ):
        super().__init__(client=client, identifier=identifier, name=name, description=description, parent=parent,
                         owner=owner, last_modified=last_modified)
        self.data = data
        self.content_type = content_type

    def _json_data(self):
        return self.data

    def _content_blueprint(self):
        pass

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< {self.content_type} (not implemented) | {self.name} >>"


class WorkOrganizerPlaceholderFactory(WorkOrganizerFactory):
    """Factory for retrieving work organizer placeholder objects"""
    tm_class = WorkOrganizerPlaceholder

    @kwargs_to_class
    def _from_json(self, data):
        """Full enriched payload"""
        return {
            **self._json_to_kwargs_base(data),
            "content_type": data["type"],
            "data": data["data"],
        }

    @kwargs_to_class
    def _from_json_work_organizer(self, data):
        """Need to add placeholder arguments not present in work organizer"""
        return {
            **super()._from_json_work_organizer.__wrapped__(self, data),
            "content_type": data["type"],
        }


implemented_factories = {
    factory.tm_class.content_type: factory
    for factory in [
        ContextHubViewFactory,
        TrendHubViewFactory,
        FolderFactory,
        ValueBasedSearchFactory,
        FormulaFactory,
        AggregationFactory,
        DashboardFactory,
        SimilaritySearchFactory,
        FilterFactory,
        FingerprintFactory,
    ]
}

# Initialize dummy factories for unimplemented methods
wo_factories = {
    content_type: WorkOrganizerPlaceholderFactory
    for content_type in WORK_ORGANIZER_CONTENT_OPTIONS
}

# Update with implemented factories
wo_factories.update(implemented_factories)


class FolderContentFactory(MultiFactory):
    """Generates objects from any content json content found in a folder"""

    factories = wo_factories

    @to_subfactory
    def _from_json(self, data):
        """Full response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data.get("type", "FOLDER")

    @to_subfactory
    def _from_json_work_organizer(self, data):
        """Limited response json from work organizer browsing"""
        return data.get("type", "FOLDER")

    @property
    def _get_methods(self):
        return ()
