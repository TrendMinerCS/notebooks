import abc


# TODO: only used for tags. Should also be used for nodes or not be used at all.
class Component(abc.ABC):
    """Superclass for ContextHub components"""
    component_type = None
