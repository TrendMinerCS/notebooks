from trendminer_interface import _input as ip
from trendminer_interface.base import Savable, TrendMinerFactory, ByFactory
from trendminer_interface.user import UserFactory


class AccessRule(Savable):
    """Access rule giving a user certain permissions to a certain object

    Attributes
    ----------
    parent : Any
        The object to which the access rule relates
    user : User
        The user to which the access rule relates
    permissions : list of str
        The permissions granted to the user
    endpoint : str
        The (relative) url endpoint for calls manipulating the access rule
    """
    user = ByFactory(UserFactory)

    def __init__(self, client, identifier, parent, user, permissions, endpoint):
        super().__init__(client=client, identifier=identifier)
        self.parent = parent
        self.user = user
        self.permissions = permissions
        self.endpoint = endpoint

    def __json__(self):
        return {
            "identifier": self.identifier,
            "permissions": self.permissions,
            "subjectType": self.user.subject_type,
            "subjectId": self.user.identifier,
        }

    @property
    def blueprint(self):
        return {
            "user": self.user.name,
            "permissions": self.permissions
        }

    def __repr__(self):
        return f"<< AccessRule | {self.user.name}: {','.join(self.permissions)} >>"


# TODO: unified approach for these types of child instances and factories; better handling of endpoint
# TODO: this should probably be an abstract class, with then specific subclasses for different object access rights. Currently it is very hard for the user to find what the access options are.
class AccessRuleFactory(TrendMinerFactory):
    """Factory for managing user access to a certain object"""
    tm_class = AccessRule

    def __init__(self, parent, endpoint, option_dict, derived_option_dict=None):
        super().__init__(client=parent.client)
        self._parent = parent
        self._option_dict = option_dict
        self._derived_option_dict = derived_option_dict or {}
        self._endpoint = endpoint or ""  # suffix to the url; e.g. /inherited for inherited permissions

    # Access rule needs a custom endpoint for inherited access properties
    @property
    def _endpoint(self):
        return self._custom_endpoint

    @_endpoint.setter
    def _endpoint(self, endpoint):
        self._custom_endpoint = endpoint

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        AccessRule
        """
        if "userDetailsResource" in data:
            user = UserFactory(client=self.client)._from_json_limited_id(data["userDetailsResource"])
        else:
            user = UserFactory(client=self.client)._from_json_everyone(data)

        return self.tm_class(
            client=self.client,
            identifier=data["identifier"],
            parent=self._parent,
            user=user,
            permissions=data["permissions"],
            endpoint=self._endpoint,
        )

    def all(self):
        """Retrieve all access rules for the object

        Returns
        -------
        list of AccessRule
        """
        response = self.client.session.get(self._endpoint)
        return [self._from_json(data) for data in response.json()]

    def _validate_permissions(self, values):
        permissions = []
        values = ip.any_list(values)
        for value in values:
            value = ip.case_correct(value, self._option_dict.keys())
            value = self._option_dict[value]
            permissions.append(value)
            for derived_permission in self._derived_option_dict.get(value, []):
                permissions.append(derived_permission)
        return list(set(permissions))

    def add(self, user, permissions):
        """Adds given permissions to the object for the given user

        Parameters
        ----------
        user : User or Any
            The user who is granted the permissions
        permissions : list of str
            The permissions granted to the user
        """
        rule = self.tm_class(
            client=self.client,
            identifier=None,
            parent=self._parent,
            user=user,
            permissions=self._validate_permissions(permissions),
            endpoint=self._endpoint,
        )
        rule.post()

    def remove(self, users):
        """Remove rules involving specific users on the object

        Parameters
        ----------
        users : list
            Users for which all access rules need to be removed
        """
        users = self.client.user.list(users)
        identifiers = [user.identifier for user in users]
        for rule in self.all():
            if rule.user.identifier in identifiers:
                rule.delete()

    def clear(self):
        """Clear all existing access rules on the object"""
        for rule in self.all():
            rule.delete()

    @property
    def _get_methods(self):
        return self.from_identifier,