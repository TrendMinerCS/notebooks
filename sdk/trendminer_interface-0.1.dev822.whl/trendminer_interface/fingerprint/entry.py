from trendminer_interface.base import MultiFactory, to_subfactory
from trendminer_interface.tag import TagFactory
from trendminer_interface.asset import AttributeFactory


class FingerprintEntryFactory(MultiFactory):
    """Factory for returing tag or attribue reference in Fingerprint hull json"""

    factories = {
        "TIME_SERIES": TagFactory,
        "ATTRIBUTE": AttributeFactory,
    }

    @to_subfactory
    def _from_json_fingerprint(self, data):
        return data["type"]

    def from_tag(self, ref):
        """Get tag from a reference

        Parameters
        ----------
        ref : Any
            Tag reference

        Returns
        -------
        Tag
        """
        return TagFactory(client=self.client).get(ref)

    def from_attribute(self, ref):
        """Get attribute from a reference

        Parameters
        ----------
        ref : Any
            Attribute reference

        Returns
        -------
        Attribute
        """
        return self.client.asset.get(ref)

    @property
    def _get_methods(self):
        return self.from_tag, self.from_attribute
