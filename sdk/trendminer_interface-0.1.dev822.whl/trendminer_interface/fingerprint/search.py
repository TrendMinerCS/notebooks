from trendminer_interface.base import Authenticated
from trendminer_interface.times import IntervalFactory
from .hull import FingerprintHull


class FingerprintSearch(Authenticated):
    """Fingerprint search

    A fingerprint search is not a work organizer object and cannot be saved. It can only be instantiated and executed.
    """

    def __init__(
            self,
            client,
            hulls,
            threshold,
    ):
        super().__init__(client=client)
        self.hulls = hulls
        self.threshold = threshold

    def get_results(self, interval="6M", excluded_intervals=None):
        """Gets fingerprint search results"""

        interval = IntervalFactory(client=self.client).get(interval)
        excluded_intervals = IntervalFactory(client=self.client).list(excluded_intervals)

        queries = [hull.__json__() for hull in self.hulls]
        min_duration = min([query["hulls"][-1]["offset"] for query in queries])

        data = {
            "contextTimePeriod": interval.__json__(),
            "filters": [i.__json__() for i in excluded_intervals],
            "params": {
                "detectionThreshold": self.threshold,
                "duration": min_duration,
            },
            "queries": queries,
        }

        r = self.client.session.post("/compute/fingerprintsearch/newSearch", json=data)

        results = [IntervalFactory(client=self.client)._from_json_fingerprint_search(data) for data in r.json()]
        results = sorted(results, key=lambda x: x.start)  # oldest result first

        return results


class FingerprintSearchFactory(Authenticated):
    tm_class = FingerprintSearch

    def __call__(self, hulls, threshold):
        """Instantiate new fingerprint search

        Parameters
        ----------
        hulls : list of FingerprintHull
            Tag hulls coming from a fingerprint
        threshold : float
            Detection thershold for matches. Value between 0 and 100.
        """
        return self.tm_class(
            client=self.client,
            hulls=hulls,
            threshold=threshold,
        )
