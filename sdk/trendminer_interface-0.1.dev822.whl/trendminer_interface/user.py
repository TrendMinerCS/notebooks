import cachetools
import posixpath
import abc

from .exceptions import FromJsonError
from .constants import KEYCLOAK_REALM, ADMIN_ROLE
from . import _input as ip
from trendminer_interface.base import Gettable, TrendMinerFactory, LazyLoadingClass, kwargs_to_class, ByFactory
from trendminer_interface.times import DatetimeFactory
from .constants import MAX_GET_SIZE, MAX_USER_CACHE


class UserClient(abc.ABC):
    """Client holding the UserFactory"""
    @property
    def user(self):
        """Factory for retrieving users"""
        return UserFactory(client=self)


class User(Gettable, LazyLoadingClass):
    """A TrendMiner user"""
    endpoint = f"/auth/realms/{KEYCLOAK_REALM}/local/users/"
    created = ByFactory(DatetimeFactory)

    def __init__(
        self,
        client,
        identifier,
        subject_type,
        name,
        admin,
        mail,
        first,
        last,
        created,
    ):
        Gettable.__init__(self, client=client, identifier=identifier)
        self.name = name
        self.first = first
        self.last = last
        self.identifier = identifier
        self.admin = admin
        self.mail = mail
        self.created = created
        self.subject_type = subject_type

    @property
    def everyone(self):
        """If user is everyone

        Returns
        -------
        bool
        """
        return self.identifier == "Everyone"

    @property
    def blueprint(self):
        return {"name": self.name}

    def _full_instance(self):
        if "identifier" in self.lazy:
            return self.client.user.from_name(ref=self.name)
        else:
            return self.client.user.from_identifier(ref=self.identifier)

    def __json__(self):
        return self.identifier

    def __repr__(self):
        return f"<< User | {self._repr_lazy('name')} >>"


class UserFactory(TrendMinerFactory):
    tm_class = User

    def __init__(self, client):
        super().__init__(client)

    def everyone(self):
        """Returns the 'Everyone' user needed to give all users permissions/access at once"""
        return self.tm_class(
            client=self.client,
            identifier="Everyone",
            subject_type="EVERYONE",
            name="Everyone",
            mail=None,
            admin=False,
            first=None,
            last=None,
            created=None,
        )

    def _query_users(self, params):
        content = self.client.session.paginated(keys=["_embedded", "content"]).get(self.tm_class.endpoint, params=params)
        return [self._from_json(data=data) for data in content]

    def from_identifier(self, ref):
        """Retrieve a user from their identifier

        Parameters
        ----------
        ref : str
            User UUID

        Returns
        -------
        User
        """
        link = posixpath.join(self._endpoint, ref)
        response = self.client.session.get(link)
        return self._from_json(response.json())

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=MAX_USER_CACHE), key=TrendMinerFactory._cache_key_ref)
    def from_name(self, ref):
        if ref.lower() == "everyone":
            return self.everyone()
        params={"username": ref, "size": 10}
        return ip.object_match_nocase(self._query_users(params), attribute="name", value=ref)

    def by_any(self, ref):
        "Searches by username, first name, last name, and email"
        return self._query_users(params={"search": ref, "size": MAX_GET_SIZE})

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=10), key=TrendMinerFactory._cache_key_no_args)
    def self(self):
        return self.from_name(self.client.username)

    def _from_json_everyone(self, data):
        if data.get("subjectType", "").upper() == "EVERYONE":
            return self.everyone()
        else: # pragma: no cover
            raise FromJsonError(data)

    def _json_to_kwargs_base(self, data):
        return {
            "first": data.get("firstName"),
            "last": data.get("lastName"),
            "subject_type": "USER",
        }

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["userId"],
            "name": data["username"],
            "admin": ADMIN_ROLE in data["roles"],
            "mail": data.get("email"),
            "created": data.get("createdDate"),
        }

    @kwargs_to_class
    def _from_json_limited(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["identifier"],
            "name": data["username"],
        }

    @kwargs_to_class
    def _from_json_limited_id(self, data):
        """Used in context filter and work organizer"""
        return {
            "identifier": data["userId"],
            "name": data["userName"],
        }

    @kwargs_to_class
    def _from_json_name_only(self, data):
        """Create lazy instance from only the name"""
        return {"name": data}

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        """Create lazy instance from only the identifier"""
        return {"identifier": data}

    @property
    def _get_methods(self):
        return self.from_name,

    @property
    def _search_methods(self):
        return self.by_any,
