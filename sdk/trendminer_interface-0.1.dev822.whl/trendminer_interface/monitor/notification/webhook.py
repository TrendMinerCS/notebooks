from .base import Notification


class WebhookNotification(Notification):
    def __init__(self, monitor, enabled, enabled_at, url):
        super().__init__(monitor, enabled, enabled_at)
        self.url = url

    @classmethod
    def _from_json(cls, monitor, data):
        """Response json to instance

        Attributes
        ----------
        monitor : Monitor
            monitor on which the notification is configured
        data : dict
            response json

        Returns
        -------
        WebhookNotification
        """
        return cls(
            monitor=monitor,
            enabled=data["enabled"],
            enabled_at=data.get("enabledAt"),
            url=data["url"],
        )

    def __json__(self):
        return {
            **super().__json__(),
            "url": self.url,
        }