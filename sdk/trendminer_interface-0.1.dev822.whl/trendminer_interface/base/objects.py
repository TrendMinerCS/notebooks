import abc
import json_fix  # noqa  #pylint: disable=unused-import
from copy import deepcopy

import posixpath


class Authenticated(abc.ABC):
    """Instances which requre authentication to the TrendMiner server

    Parameters
    ----------
    client: TrendMinerClient
        Client providing link to the appliance
    """
    def __init__(self, client):
        self.client = client

    def __repr__(self):
        return f"<< {self.__class__.__name__} >>"


class Serializable(Authenticated, abc.ABC):
    """Instances which are json-serializable on the TrendMiner server

    Attributes
    ----------
    client : TrendMinerClient
        Client authenticated to send requests to the appliance
    """

    def __init__(self, client):
        super().__init__(client)

    @abc.abstractmethod
    def __json__(self):
        """JSON representation of the instance used to create and update objects on the appliance

        We are using the `json_fix` package to make instances directly serializable via this method.

        Returns
        -------
        dict
            Instance JSON representation
        """
        pass

    def copy(self, attributes=None):
        """Creates deepcopy of the instance, optionally replacing some attributes in the copied instance

        Parameters
        ----------
        attributes: dict, optional
            Instance attributes and what to replace them with in the copy as key-value pairs in a dict

        Returns
        -------
        Any
            Deepcopy of the instance, potentially with some attributes changed.
        """
        attributes = attributes or {}
        copy = deepcopy(self)
        copy.client = self.client  # client needs to be explicitly assigned, since client.session does not copy over
        for key, value in attributes.items():
            setattr(copy, key, value)
        return copy


class Gettable(Serializable, abc.ABC):
    """TrendMiner instances which can be retrieved by a get request

    Attributes
    ----------
        identifier: str, optional
            Unique reference on the appliance
    """
    endpoint = None

    def __init__(self, client, identifier):
        super().__init__(client=client)
        self.identifier = identifier

    @property
    def link(self):
        """Link to existing object"""
        return posixpath.join(self.endpoint, self.identifier)


class Savable(Gettable, abc.ABC):
    """Instances which can be saved to the TrendMiner server"""

    def __init__(self, client, identifier):
        super().__init__(client=client, identifier=identifier)

    def _put_updates(self, response):
        """Update some instance attributes from a put response"""
        pass

    def _post_updates(self, response):
        """Update instance attributes from a post response"""
        self.identifier = response.json()["identifier"]

    def _delete_updates(self, response):
        """Update instance attributes form a delete response"""
        self.identifier = None

    def post(self):
        """Creates this instance on the TrendMiner appliance"""
        self.__json__()  # asserts object is no longer lazy
        self.identifier = None  # reset identifier to avoid overwriting
        response = self.client.session.post(self.endpoint, json=self)
        self._post_updates(response)

    def put(self):
        """Updates the appliance object to match this instance"""
        response = self.client.session.put(self.link, json=self)
        self._put_updates(response)

    def delete(self):
        """Remove this instance from the appliance"""
        self.client.session.delete(self.link)

    @property
    def blueprint(self):
        """Returns server agnostic dict representation of object"""
        raise NotImplementedError
