from trendminer_interface.base import Gettable, TrendMinerFactory, ByFactory
from trendminer_interface.times import time_json, Interval, DatetimeFactory, IntervalFactory
from trendminer_interface.exceptions import ResourceNotFound


class Event(Gettable):
    """A context item event

    An event is defined by a timestamp and a state. A context item event is assigned a unique identifier (uuid) by
    TrendMiner.

    Attributes
    ----------
    state : str
        The context event state
    timestamp: datetime.datetime
        The event timestamp
    """
    timestamp = ByFactory(DatetimeFactory)

    def __init__(self, client, identifier, state, timestamp):
        super().__init__(client=client, identifier=identifier)

        self.state = state
        self.timestamp = timestamp

    def __json__(self):
        return {"identifier": self.identifier, "occurred": time_json(self.timestamp), "state": self.state}

    def __repr__(self):
        return f"<< Event | {self.state} | {self.timestamp.ctime()} >>"


class EventFactory(TrendMinerFactory):
    """Factory for creating and retrieving context events

    Attributes
    ----------
    workflow : ContextWorkflow
        Workflow of the context item type. The workflow allows events can be generated from lists of timestamps, as
        the workflow reveals what the states of these events should be.
    """
    tm_class = Event

    def __init__(self, client, workflow):
        super().__init__(client=client)
        self.workflow = workflow

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Event
        """
        return self.tm_class(client=self.client,
                             identifier=data["identifier"],
                             state=data.get("state"),
                             timestamp=data["occurred"],
                             )

    def list(self, refs):
        """Generate list of events

        Parameters
        ----------
        refs : list
            Entries from which to generate events

        Returns
        -------
        list of Event
            Context item events
        """
        if isinstance(refs, Interval):
            return self.from_interval(refs)
        try:
            events = self.from_datetimes(refs)
        except (AttributeError, TypeError, IndexError, ResourceNotFound):
            events = super(EventFactory, self).list(refs)
            events.sort(key=lambda event: event.timestamp)
        return events

    def from_interval(self, ref):
        """Make list of events based on an interval

        Parameters
        ----------
        ref : Any
            A single (entry convertible to) Interval

        Returns
        -------
        list of Event
            List with two events, corresponding to the interval start and end timestamp. The states match the workflow
            start and end state.
        """
        ref = IntervalFactory(client=self.client).get(ref)

        if self.workflow is None:
            return [Event(client=self.client, identifier=None, state=None, timestamp=ref.start)]

        return [
            Event(client=self.client, identifier=None, state=self.workflow.states[0], timestamp=ref.start),
            Event(client=self.client, identifier=None, state=self.workflow.states[-1], timestamp=ref.end)
        ]

    # TODO: seems incorrect. Workflow states should not be iterated in order. Except for start and end state there should be no particular order. Perhaps possible do use default .list
    def from_datetimes(self, refs):
        """Make list of events from list of timestamps

        Parameters
        ----------
        refs : list
            List of (entries convertible to) datetime.datetime

        Returns
        -------
        list of Event
            List with events at the given timestamps, with states corresponding to the states in the workflow (in the
            same order). If the workflow is absent, only a single event is returned regardless of the number of entries.
        """
        times = DatetimeFactory(client=self.client).list(refs)

        if self.workflow is None:
            return [Event(client=self.client, identifier=None, state=None, timestamp=times[0])]

        return [
            Event(client=self.client, identifier=None, state=self.workflow.states[i], timestamp=ts)
            for i, ts in enumerate(times)
        ]
