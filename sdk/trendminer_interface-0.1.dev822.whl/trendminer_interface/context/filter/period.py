import isodate

from trendminer_interface.context.filter.base.filter import ContextFilter
from trendminer_interface.base import ByFactory, TrendMinerFactory
from trendminer_interface.times import TimedeltaFactory


class PeriodFilter(ContextFilter):
    """Filter on context item event time with dynamic period

    Attributes
    ----------
    period : Period
        Period on which to filter context item even time
    live : bool
        Whether the ContexHubView having this filter needs to update live
    """
    filter_type = 'PERIOD_FILTER'
    period = ByFactory(TimedeltaFactory)

    def __init__(self, client, period, live):
        super().__init__(client=client)
        self.period = period
        self.live = live

    def __json__(self):
        return {
            "live": self.live,
            "type": self.filter_type,
            "period": isodate.duration_isoformat(self.period),
        }


class PeriodFilterFactory(TrendMinerFactory):
    """Factory for creating period filter on context item event time"""
    tm_class = PeriodFilter

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        PeriodFilter
        """
        return self.tm_class(client=self.client, period=data["period"], live=data["live"])

    def __call__(self, period='8h', live=False):
        """Create new period filter for context item event time

        Attributes
        ----------
        period : Period or str
            Period on which to filter
        live : bool
            Whether the ContexHubView having this filter needs to update live
        """
        return self.tm_class(client=self.client, period=period, live=live)
