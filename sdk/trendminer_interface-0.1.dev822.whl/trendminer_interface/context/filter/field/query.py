from trendminer_interface.context.filter.base import ContextQuery, ContextQueryFactory


class NumericQuery(ContextQuery):
    """Filter on context field (in)equality to give value"""
    def __init__(self, client, operator, value):
        super().__init__(client=client, operator=operator, value=value)

    @property
    def value(self):
        """Filter value

        Returns
        -------
        value : float
            Numeric value to filter on
        """
        return self._value

    @value.setter
    def value(self, value):
        self._value = float(value)

    def __json__(self):
        return {
            "operator": self.operator_str,
            "value": self.value,
        }


class NumericQueryFactory(ContextQueryFactory):
    """Factory for creating NumericQuery"""
    tm_class = NumericQuery
