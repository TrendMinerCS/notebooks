import pandas as pd
import math

from datetime import datetime

from trendminer_interface.base import TrendMinerFactory
from trendminer_interface.times.parsers import string_to_datetime

from .timedelta_factory import TimedeltaFactory


# TODO: time factories need different error message and exception
class DatetimeFactory(TrendMinerFactory):
    """Factory for creating datetimes"""
    tm_class = datetime

    def _set_tz(self, ts):
        """Localize the datetime to the client timezone

        Adds the client timezone if no timezone is present

        Parameters
        ----------
        ts : datetime
            Input datetime

        Returns
        -------
        ts : datetime
        """
        if ts.tzinfo is None:
            ts = self.client.tz.localize(ts)
        else:
            ts = ts.astimezone(self.client.tz)

        return ts

    def from_str(self, ref):
        """Create datetime from str

        Unless the datetime is explicitly present in the string, the given timestamp will be assumed to be in the client
        timezone.

        Parameters
        ----------
        ref : str
            String convertible into datetime (e.g., '2024-01-17 16:00:12')

        Returns
        -------
        datetime
        """
        return string_to_datetime(ref)

    def from_timestamp(self, ref):
        """Create datetime from pandas Timestamp

        If not timezone info is present, the given timestamp will be assumed to be in the client timezone.

        Parameters
        ----------
        ref : pd.Timestamp
            String convertible into datetime (e.g., '2024-01-17 16:00:12')

        Returns
        -------
        datetime
        """
        # TODO: do we need this method?
        return ref.to_pydatetime()

    def get(self, ref):
        # Make sure the returned datetime is in the client timezone
        ref = super().get(ref)
        if isinstance(ref, self.tm_class):
            ref = self._set_tz(ref)
        return ref

    @property
    def _get_methods(self):
        return self.from_str, self.from_timestamp

    def _round(self, ts, resolution, rounding_fun):
        """Round datetime to given resolution using provided rounding function

        Parameters
        ----------
        ts : datetime
            Input datetime
        resolution : timedelta or str
            Rounding resolution
        rounding_fun : function
            Rounding function to apply

        Returns
        -------
        ts : datetime
            Rounded datetime
        """

        # Convert inputs if necessary
        resolution = TimedeltaFactory(client=self.client).get(resolution) or self.client.resolution
        ts = self.get(ts)

        # Round and return
        rounded_timestamp = rounding_fun(ts.timestamp() / resolution.total_seconds()) * resolution.total_seconds()
        return datetime.fromtimestamp(rounded_timestamp, tz=ts.tzinfo)

    def round(self, ts, resolution=None):
        """Round datetime to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : timedelta or str or float
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=round)

    def ceil(self, ts, resolution=None):
        """Round datetime up to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : timedelta or str or float
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=math.ceil)

    def floor(self, ts, resolution=None):
        """Round datetime down to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : timedelta or str or float
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=math.floor)
