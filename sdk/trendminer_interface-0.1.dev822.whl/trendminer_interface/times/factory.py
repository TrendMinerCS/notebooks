import numpy as np

from datetime import datetime, timedelta

from trendminer_interface.base import Authenticated

from .interval import Interval, IntervalFactory
from .datetime_factory import DatetimeFactory
from .timedelta_factory import TimedeltaFactory


class TimeFactory(Authenticated):
    """Factory with some time-related methods, also serving as parent to other time-related factories

    All outcomes are given in the client timezone
    """

    def now(self):
        """Current time

        Returns
        -------
        now : datetime
            The current time
        """
        return datetime.now(tz=self.client.tz)


    @property
    def interval(self):
        """Interval factory for generating intervals

        Returns
        -------
        IntervalFactory
        """
        return IntervalFactory(client=self.client)
