import isodate
import re
import pytz

from dateutil import parser
from datetime import datetime, timedelta


def string_to_datetime(time_str):
    date = parser.isoparse(time_str)
    return date


def string_to_timedelta(time_str):
    try:
        return isodate.parse_duration(time_str)
    except isodate.isoerror.ISO8601Error:
        pass

    time_str = time_str.replace(" ", "")

    negative = False
    if time_str[0] == "-":
        time_str = time_str[1:]
        negative = True

    regex = re.compile(
        r"((?P<years>[.\d]+?)[yY])?((?P<months>[.\d]+?)M)?((?P<weeks>[.\d]+?)[wW])?((?P<days>[.\d]+?)d)"
        r"?((?P<hours>[.\d]+?)h)?((?P<minutes>[.\d]+?)m)?((?P<seconds>[.\d]+?)s)?"
        r"((?P<milliseconds>[.\d]+?)ms)?$"
    )

    parts = regex.match(time_str)

    if parts is None:
        raise ValueError(f'Could not parse any time information from "{time_str}"')

    time_params = {
        name: float(param) for name, param in parts.groupdict().items() if param
    }

    days = time_params["days"] if "days" in time_params else 0
    months = time_params.pop("months") if "months" in time_params else 0
    years = time_params.pop("years") if "years" in time_params else 0

    time_params.update({"days": days + round(365.25 * (years + months / 12))})
    time_delta = timedelta(**time_params)

    if negative:
        time_delta = -time_delta

    return time_delta


def time_json(t):
    """Convert time to format typically used in json payload"""
    if t is None:
        return None

    if isinstance(t, datetime):
        return t.astimezone(pytz.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    if isinstance(t, timedelta):
        return isodate.duration_isoformat(t)

    raise TypeError(f"Cannot convert object of type {t.__type__} to json")