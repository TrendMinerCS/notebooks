import abc
import isodate
import datetime

from trendminer_interface.base import Serializable


class Slice(Serializable, abc.ABC):
    def __init__(self, client, is_open):
        super().__init__(client=client)
        self.is_open = is_open

    @property
    @abc.abstractmethod
    def start(self):
        pass

    @property
    @abc.abstractmethod
    def end(self):
        pass

    @property
    @abc.abstractmethod
    def duration(self):
        pass

    @property
    def duration_iso(self):
        return isodate.duration_isoformat(self.duration)

    def total_seconds(self):
        return self.duration.total_seconds()

    def __contains__(self, item):
        try:
            return (self.start <= item.start) and (item.end <= self.end)
        except AttributeError:
            item = self.client.time.datetime(item)
            return (self.start <= item) and (item <= self.end)

    def __truediv__(self, other):
        overlap = max(0, (min(self.end, other.end) - max(self.start, other.start)).total_seconds())
        return overlap/other.total_seconds()