from datetime import timedelta

from trendminer_interface.times.parsers import string_to_timedelta
from trendminer_interface.base import TrendMinerFactory


class TimedeltaFactory(TrendMinerFactory):
    tm_class = timedelta

    def from_seconds(self, ref):
        """Timedelta from number of seconds

        Parameters
        ----------
        ref : float
            Number of seconds

        Returns
        -------
        timedelta
        """
        return timedelta(seconds=ref)

    def from_str(self, ref):
        """Timedelta from string

        Parameters
        ----------
        ref : str
            String representing a duration (e.g., '17d 12h 30m 15s')

        Returns
        -------
        timedelta
        """
        return string_to_timedelta(ref)

    @property
    def _get_methods(self):
        return self.from_str, self.from_seconds

    def round(self, td, resolution=None):
        """Round timedelta to given resolution

        Parameters
        ----------
        td : timedelta or str or float
            Input duration
        resolution : timedelta or str or float
            Rounding resolution

        Returns
        -------
        td : timedelta
            Rounded timedelta
        """

        # Convert inputs if needed
        td = TimedeltaFactory(client=self.client).get(td)
        resolution = TimedeltaFactory(client=self.client).get(resolution) or self.client.resolution

        # Round and return
        seconds = round(td.total_seconds() / resolution.total_seconds()) * resolution.total_seconds()
        return timedelta(seconds=seconds)
