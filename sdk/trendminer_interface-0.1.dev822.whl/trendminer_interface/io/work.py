import json


from trendminer_interface.base import Authenticated
from trendminer_interface.user import User


class WorkIOFactory(Authenticated):
    endpoint = "ds/imported/timeseries/"

    def export(self, username=None):
        """Get work organizer content as a dict

        Parameters
        ----------
        username: str
            name of the user of which work organizer data is exported. Defaults to authenticated user.

        Returns
        -------
        dict
            Work organizer export
        """

        if isinstance(username, User):
            username = username.name

        params = {
            "username": username
        }

        response = self.client.session.get("work/export", params=params)
        return response.json()

    def upload(self, data, username=None, skip=True):
        """Upload dict of work organizer. Does not return outcome immediately. check outcome with .result()

        Parameters
        ----------
        data: dict
            data from work organizer export
        username: str
            name of the user to which the data needs to be uploaded as work organizer items. Defaults to authenticated
            user.
        skip: bool
            when True (default), duplicates (by identifier) will not be imported; when False, duplicates are replaced
        """
        if isinstance(username, User):
            username = username.name

        params = {
            "username": username,
            "skip": skip,
        }

        files = {"file": ("data.json", json.dumps(data, indent=4))}

        self.client.session.post("work/import", params=params, files=files)

    def result(self):
        """Retrieve the results from the current or last import"""

        response = self.client.session.get("work/import/result")
        return response.json()

