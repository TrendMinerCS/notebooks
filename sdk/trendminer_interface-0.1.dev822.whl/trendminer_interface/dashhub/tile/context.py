import abc

from .base import Tile, TileFactoryBase


class ContextTile(Tile, abc.ABC):
    """ContextHub tile parent class

    Tile content is a ContextHub view
    """
    visualization_type = "CONTEXT_HUB_VIEW"
    display_mode = None
    min_size = (1, 2)

    def _get_content(self, content):
        """Convert content into ContextHub view

        Attributes
        ----------
        content : ContextHubView or Any

        Returns
        -------
        ContextHub view
        """
        return self.client.context.view.get(content)

    def _json_configuration(self):
        return {
            "displayMode": self.display_mode,
            "configurationType": self.visualization_type,
            "contextViewId": self.content.identifier,
        }


class ContextTileFactory(TileFactoryBase, abc.ABC):
    """ContextHub tile parent class"""
    tm_class = ContextTile

    def _from_json_content(self, data):
        return self.client.context.view._from_json_identifier_only(data["contextViewId"])


class CounterTile(ContextTile):
    """ContextHub view counter tile"""
    display_mode = "COUNT"


class CounterTileFactory(ContextTileFactory):
    """ContextHub view counter tile factory"""
    tm_class = CounterTile


class TableTile(ContextTile):
    """ContextHub view table tile"""
    display_mode = "TABLE"


class TableTileFactory(ContextTileFactory):
    """ContextHub view table tile factory"""
    tm_class = TableTile


class GanttTile(ContextTile):
    """ContextHub view Gantt tile"""
    display_mode = "GANTT"


class GanttTileFactory(ContextTileFactory):
    """ContextHub view Gantt tile factory"""
    tm_class = GanttTile
