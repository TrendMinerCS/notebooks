from trendminer_interface.base import WorkOrganizerObject
from .base import FolderBase


class Folder(WorkOrganizerObject, FolderBase):
    """Work organizer folder"""
    content_type = "FOLDER"

    def __init__(self, client, identifier, name, parent, owner, last_modified):
        super().__init__(client=client, identifier=identifier, name=name, description=None, parent=parent, owner=owner,
                         last_modified=last_modified)

    def _json_data(self):
        return

    def __json__(self):
        return {
            "id": self.identifier,
            "name": self.name,
            "folder": True,
            "parentId": self.parent.identifier if self.parent else None,
        }

    def _content_blueprint(self):
        raise NotImplementedError()

    # TODO: implement uniform strategy for cacheing and clearing the cache
    def _clear_cache(self):
        """Clear the folder getting cache every time the folder structure is changed"""
        self.client.folder.from_identifier.cache_clear()

    def _put_updates(self, response):
        super()._put_updates(response)
        self._clear_cache()

    def _post_updates(self, response):
        super()._post_updates(response)
        self._clear_cache()

    def _delete_updates(self, response):
        super()._delete_updates(response)
        self._clear_cache()

    def _full_instance(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<< Folder | {str(self)} >>"

    def __str__(self):
        if self.name is None:
            return "<ROOT>"
        return self.name
