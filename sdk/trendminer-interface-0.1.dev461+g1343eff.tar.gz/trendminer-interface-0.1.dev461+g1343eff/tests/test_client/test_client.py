from pprint import pprint


def test_client_methods(client, user):
    for tmc in [client, user]:
        print(tmc)
        print(tmc.version)
        print(tmc.resolution)
        print(tmc.index_horizon)
        pprint(tmc.license)


def test_session(client, user):
    for tmc in [client, user]:
        print(tmc)
        print(tmc.session.access_expired)
        tmc.session.assure_valid_token()
        print(tmc.session.token)
        tmc.session.token_refresh()
        print(tmc.session.base_url)
        print(tmc.session.token_expiration_margin)
        print(tmc.session.token_decoded)
        pprint(tmc.session.userinfo())


def test_logout(user):
    user.logout()