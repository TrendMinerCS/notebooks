import keyring

url = "https://cs.trendminer.net"
client_id = "wdanielsclient"
username = "wdaniels"
tz = "Europe/Brussels"

user_credentials = {
    "url": url,
    "client_id": client_id,
    "client_secret": keyring.get_password(url, client_id),
    "username": username,
    "password": keyring.get_password(url, username),
    "tz": tz
}

client_credentials = {
    "url": url,
    "client_id": client_id,
    "client_secret": keyring.get_password(url, client_id),
    "tz": tz
}

confighub_credentials = {
    "url": url,
    "password": keyring.get_password(url, "admin"),
    "tz": tz
}
