Use Cases
=========

.. toctree::
    :maxdepth: 1

    transfering views to TrendMiner
    A-B test root cause analysis
    writing detected anomalies to trendminer
