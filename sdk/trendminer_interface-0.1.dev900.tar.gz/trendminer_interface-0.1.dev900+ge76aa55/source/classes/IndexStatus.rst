IndexStatus
============

Class
-----
.. autoclass:: trendminer_interface.tag.index.IndexStatus()
    :members:
    :inherited-members:
    :special-members: __call__


Factory
-------
.. autoclass:: trendminer_interface.tag.index.IndexStatusFactory()
    :members:
    :inherited-members:
    :special-members: __call__
