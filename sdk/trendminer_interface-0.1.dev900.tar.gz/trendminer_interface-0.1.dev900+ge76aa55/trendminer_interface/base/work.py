import abc
import re
import posixpath

from trendminer_interface.constants import WORK_ORGANIZER_SHARE_OPTIONS
from trendminer_interface.access import AccessRuleFactory
from trendminer_interface.user import UserFactory
from trendminer_interface.base import AsTimestamp

from trendminer_interface import _input as ip

from .objects import EditableBase, AuthenticatableBase
from .lazy_loading import LazyLoadingMixin
from .factory import FactoryBase, kwargs_to_class
from .descriptors import ByFactory
from .multifactory import MultiFactoryBase, to_subfactory


class WorkOrganizerObjectBase(EditableBase, LazyLoadingMixin, abc.ABC):
    """Superclass for objects that can be stored in the work organizer

    Attributes
    ----------
    name : str
        Object name
    description: str
        Object description
    owner : User
        The user that owns the object
    last_modified : pandas.Timestamp
        The date at which the object was last modified
    """
    endpoint = "/work/saveditem/"
    content_type = abc.abstractmethod(lambda: None)
    last_modified = AsTimestamp()
    owner = ByFactory(UserFactory)

    def __init__(self, client, identifier, name, description, parent, owner, last_modified):
        EditableBase.__init__(self=self, client=client, identifier=identifier)

        self.name = name
        self.description = description
        self.parent = parent
        self.owner = owner
        self.last_modified = last_modified

    @property
    def parent(self):
        """The folder in which the object is saved

        Returns
        -------
        parent : Folder
        """
        return self._parent

    @parent.setter
    def parent(self, parent):
        # Using a property avoids the circular import of Folder that would occur when using a descriptor
        from trendminer_interface.folder import FolderFactory
        self._parent = FolderFactory(client=self.client)._get(parent)

    def _post_updates(self, response):
        super()._post_updates(response)
        self.last_modified = response.json()["lastModifiedDate"]
        self.owner = UserFactory(client=self.client)._from_json_limited_id(response.json()["ownerUserDetails"])

    def _put_updates(self, response):
        super()._put_updates(response)
        self.last_modified = response.json()["lastModifiedDate"]
        self.owner = UserFactory(client=self.client)._from_json_limited_id(response.json()["ownerUserDetails"])

    @property
    def access(self):
        """Interface to factory for managing shared access to object

        Returns
        -------
        AccessRuleFactory
        """
        return AccessRuleFactory(parent=self,
                                 endpoint=f"{self.link}/accessrule",
                                 option_dict=WORK_ORGANIZER_SHARE_OPTIONS)

    @classmethod
    def is_folder(cls):
        return cls.content_type == "FOLDER"

    @abc.abstractmethod
    def _json_data(self):
        pass

    def _json(self):
        return {
            "identifier": self.identifier,
            "name": self.name,
            "description": self.description,
            "type": self.content_type,
            "folder": self.is_folder(),
            "parentId": self.parent.identifier if self.parent else None,
            "data": self._json_data()
        }

    def __repr__(self):
        return f"<< {type(self).__name__} | {self._repr_lazy('name')} >>"


class WorkOrganizerFactoryBase(AuthenticatableBase, abc.ABC):
    """General base class for getting objects from the work organizer

    Inherited by base factory for getting work organizer objects for one specific type, and multifactory for getting
    objects that are in a provided selection of types.
    """

    @property
    @abc.abstractmethod
    def _included(self):
        """Property returning what classes need to be included in folder browsing

        Writing this to a property so that it can be overwritten for MultiFactory instances which can return work
        organizer objects of multiple types.
        """
        pass

    def from_identifier(self, ref):
        """Get instance from UUID

        Parameters
        ----------
        ref : str
            UUID string of the work organizer item

        Returns
        -------
        WorkOrganizerObjectBase
        """
        url = posixpath.join("/work/saveditem/", ref)
        response = self.client.session.get(url)
        return self._from_json(response.json())

    def from_path(self, ref):
        """Retrieve object by its full path in the work organizer structure

        Parameters
        ----------
        ref : str
            Path string, e.g. my_folder/my_subfolder/my_object

        Returns
        -------
        Any
        """
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        from trendminer_interface.folder import FolderFactory
        current_folder = FolderFactory(client=self.client).root

        # Iterate folders
        for part in parts[0:-1]:
            current_folder = current_folder.get_child_from_name(part, folders_only=True)

        return current_folder.get_child_from_name(parts[-1], included=self._included)

    def _json_to_kwargs_common_base(self, data):
        """Elements that are shared by all formats"""
        from trendminer_interface.folder import FolderFactory
        return {
            "identifier": data["identifier"],
            "name": data["name"],
            "description": data.get("description"),
            "parent": (
                FolderFactory(client=self.client)._from_json_identifier_only(data["parentId"])
                if "parentId" in data else None
            ),
            "last_modified": data["lastModifiedDate"],
        }

    def _json_to_kwargs_base(self, data):
        """Base elements for full work organizer objects"""
        return {
            **self._json_to_kwargs_common_base(data),
            "owner": self.client.user._from_json_name_only(data["owner"])
        }

    @kwargs_to_class
    def _from_json_work_organizer(self, data):
        """Generate instances from browsing the work organizer"""
        return {
            **self._json_to_kwargs_common_base(data),
            "owner": UserFactory(client=self.client)._from_json_limited_id(data["ownerUserDetails"]),
        }

    @abc.abstractmethod
    def _from_json(self, data):
        pass

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        return {"identifier": data}

    def search(self, ref=None):
        """Search work organizer items of this type

        Parameters
        ----------
        ref : str, optional
            Name or description search condition. The '*' can be used as a wildcard

        Returns
        -------
        list
            Work organizer items of the given type matching the search query
        """
        params = {
            "includeTypes": [content_class.content_type for content_class in self._included],
            "includeData": False,
        }

        if ref is not None:
            params.update({"query": ref})

        content = self.client.session.paginated(keys=["_embedded", "content"]).get(
            url="work/saveditem/search",
            params=params
        )

        return [self._from_json_work_organizer(data) for data in content]

    def from_name(self, ref):
        """Retrieve work organizer item by its name

        If there are multiple items with the given name (of the same type), an error is thrown

        Parameters
        ----------
        ref : str
            work organizer name

        Returns
        -------
        Any
            Item with matching name
        """
        return ip.object_match_nocase(self.search(ref=ref), attribute="name", value=ref)

    def all(self):
        """Retrieve all work organizer objects of this type

        Returns
        -------
        list
            Work organizer items of the given type
        """
        return self.search(ref="*")


class WorkOrganizerObjectFactoryBase(WorkOrganizerFactoryBase, FactoryBase, abc.ABC):
    """Base class for getting work organizer items of a specific type"""

    @property
    def _included(self):
        return [self.tm_class]

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path, self.from_name


class WorkOrganizerObjectMultiFactoryBase(MultiFactoryBase, WorkOrganizerFactoryBase, abc.ABC):
    """Base MultiFactory class for getting work organizer objects of one of a number of types"""

    @property
    def _included(self):
        return [factory.tm_class for factory in self.factories.values()]

    @to_subfactory
    def _from_json(self, data):
        """Full response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return data.get("type", "FOLDER")

    @to_subfactory
    def _from_json_work_organizer(self, data):
        """Limited response json from work organizer browsing"""
        return data.get("type", "FOLDER")
