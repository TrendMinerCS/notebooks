import keyring

url = "https://tm-previous-release301.trendminer.net/"
client_id = "sdktest"
username1 = "sdk_user1"
username2 = "sdk_user2"
adminname = "wdaniels"
tz = "Europe/Brussels"

client = {
    "url": url,
    "client_id": client_id,
    "client_secret": keyring.get_password(url, client_id),
}

user1 = {
    **client,
    "username": username1,
    "password": keyring.get_password(url, username1)
}

asset_framework_name = "SDK test"

user2 = {
    **client,
    "username": username2,
    "password": keyring.get_password(url, username2)
}

application_administrator = {
    **client,
    "username": adminname,
    "password": keyring.get_password(url, adminname)
}

system_administrator = application_administrator
