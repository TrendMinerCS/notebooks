def test_create(user1):
    prefix = user1.unique_prefix
    folder = user1.folder.from_path(prefix, create_new=True)

    a = user1.aggregation(
        target="TM_hour_Europe_Brussels",
        name=prefix,
        operator="average",
        window="1h",
        position="backward",
        parent=folder,
    )

    a.save()
    a.window = "2h"
    a.update()

    assert user1.aggregation.all()
    assert user1.aggregation.from_identifier(a.identifier)
    assert user1.aggregation.from_path(f"{prefix}/{prefix}")
    assert user1.aggregation.from_name(prefix)
    assert folder.get_children(included=["aggregation"])
    assert folder.get_child_from_name(ref=prefix)

    a.delete()
    folder.delete()
