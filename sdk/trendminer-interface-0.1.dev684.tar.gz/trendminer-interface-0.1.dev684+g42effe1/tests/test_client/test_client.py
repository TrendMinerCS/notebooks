from pprint import pprint
from trendminer_interface.version import Version


def test_client_methods(client, user1):
    for tmc in [client, user1]:
        print(tmc)
        print(tmc.version)
        print(tmc.resolution)
        print(tmc.index_horizon)
        pprint(tmc.license)


def test_session(client, user1):
    for tmc in [client, user1]:
        print(tmc)
        print(tmc.session.access_expired)
        tmc.session.assure_valid_token()
        print(tmc.session.token)
        tmc.session.token_refresh()
        print(tmc.session.base_url)
        print(tmc.session.token_expiration_margin)
        print(tmc.session.token_decoded)


def test_logout(user1):
    user1.logout()


def test_version():
    v1 = Version.from_string("2023.R1.0-11")
    v2 = Version.from_string("2022.R3.1-01")
    v3 = Version.from_string("NIGHTLY")
    assert v1 > v2
    assert not v2 >= v1
    assert not v3 <= v1
    assert v1 == "2023.R1.0-11"
    assert v1 == "2023.R*"
    assert v1 == "2023.R*.*"
    assert v1 == "2023.R1"
    assert v3 > "2023.R3"
    assert not v1 >= "2023.R1.0-12"
    assert v1 <= "2023.R1.0"
