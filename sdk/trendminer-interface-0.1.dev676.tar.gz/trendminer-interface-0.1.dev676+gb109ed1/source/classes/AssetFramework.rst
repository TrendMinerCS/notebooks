AssetFramework
==============

Class
-----
.. autoclass:: trendminer_interface.asset.framework.AssetFramework()
    :members:
    :inherited-members:

Factory
-------
.. autoclass:: trendminer_interface.asset.framework.AssetFrameworkFactory()
    :members:
    :inherited-members:
    :special-members: __call__
