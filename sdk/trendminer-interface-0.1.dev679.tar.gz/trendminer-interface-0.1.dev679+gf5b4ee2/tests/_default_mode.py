# Default testing mode ("mock", "real", "log")
#
# real: runs everything against server without storing output.
# log: runs everything against server, stores outputs for later mocking.
# mock: runs all function against responses cached by running 'log' earlier.
#
# Needs to be set to "mock" upon packaging. Change temporarily for development purposes only.

default_mode = "real"
