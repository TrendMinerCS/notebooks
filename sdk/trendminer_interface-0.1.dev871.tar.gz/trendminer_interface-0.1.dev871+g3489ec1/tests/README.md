# tm-python-interface tests
Automated testing is done via `pytest`, and initially needs to run against a live TrendMiner server. Testers need to implement their own url and credentials for running the tests, as well as perform some initialization on the server. 

Server responses can be recorded using the `pytest-recording` plugin, so subsequent tests can be run locally against these recorded responses.

## Setup
The `tests/config_template.py` contains the blueprints of the parameters required for testing. Copy this file in the same directory under the name `config.py`, and then complete it.

Do NOT configure these tests to run against a production setup. They will pollute databases with soft deleted items, cause an increase in load during testing. When tests fail, this might also result in stray items (tags, context items, ...) which do not get cleaned up. In the worst case, items might also be created in a broken state, potentially leading to issues during server upgrades. 

### Asset framework
The asset framework stored under `tests/data/asset_framework.csv` is used during tests involving assets and attributes. This asset framework needs to be published on the test server prior to running test.

The name of the asset framework can be freely chosen, but the `asset_framework_name` parameter in `config.py` should be assigned correspondingly.

### Credentials
It is strongly discouraged to hard-code sensitive data such as passwords and client secrets in this file. Use a secure alternative such as environmental variables or the `keyring` package.

The following credentials should be provided:
- **client**: credentials for a TrendMiner client user.
- **user1**: credentials for a non-admin user. Used to test interactions with the work organizer.
- **user2**: credentials for a second user. Used to test interactions between two users (e.g. sharing items).
- **application_adminstrator**: credentials for an admin user. Used to test admin function on the appliance. Application admin users are not used for all tests since there could be tests that wrongfully succeed because of admin rights.
- **system_administrator**: credentials for a ConfigHub administrator. Used to test admin functions. Can be the same credentials as for the application administrator. Can be set to `None` if a tester does not wish to test ConfigHub functionality.

It is recommended to create a client and users specifically for the purpose of testing the SDK. Note that **users have to log in manually** to the appliance to change their password after they have been created in ConfigHub. Failure to do so will result in errors when programmatic access is attempted.

At the moment, tests exclusively use demo tags, meaning no data source access rights need to be given.

The same server url should be provided for all credentials.

### Automated setup
If you are setting up new testing environments regularly, consider creating an `autosetup.py` for automating (some of) the process. Clients and users can be created using the ConfigHubClient.

## Response recording
The  [vcr.py](https://vcrpy.readthedocs.io/) plugin is used to record server responses. The responses are stored in yaml files ('cassettes'), from which they are then retrieved for subsequent test runs.

The test recording behavior is controlled with the `--record` flag when running pytest. When added, tests will be run live against the server and the responses will be recorded in yaml files.

Cassettes are stored as `tests/{test subfolder}/{cassettes}/{test filename}/{test function name}/{client fixture name}.yaml`

Note that cassettes are excluded from version control, and thus every tester will have their own library of stored responses.
