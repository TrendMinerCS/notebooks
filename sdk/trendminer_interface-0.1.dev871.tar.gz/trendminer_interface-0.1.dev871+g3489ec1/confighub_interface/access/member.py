import abc
from trendminer_interface.base import FactoryBase, EditableBase, LazyLoadingMixin


class Member(EditableBase, LazyLoadingMixin, abc.ABC):
    member_type = None

    def __init__(self, client, identifier, name):
        super().__init__(client=client, identifier=identifier)
        self.name = name

    @property
    @abc.abstractmethod
    def path(self):
        pass

    def json_member(self):
        return {
            "id": self.identifier,  # not needed for ACL access
            "name": self.name,
            "type": self.member_type,
        }

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self._repr_lazy('name')} >>"


# TODO: clearer split between group and ACL, methods are completely different. Group does not support client.

class MemberFactoryBase(FactoryBase, abc.ABC):
    tm_class = Member

    @property
    def _factories(self):
        return self.client.group, self.client.user, self.client.client  # avoid circular import by going through client

    @property
    def _get_methods(self):
        return (factory.get for factory in self._factories)


class MemberFactoryACL(MemberFactoryBase):
    tm_class = Member

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """

        return {c.tm_class.member_type: c for c in self._factories}[data["type"]]._from_json_member_acl(data)


class MemberFactoryGroup(MemberFactoryBase):
    tm_class = Member

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Any
        """
        return {c.tm_class.member_type: c for c in self._factories}[data["type"]]._from_json_member_group(data)


class HasMembers(abc.ABC):
    """Boilerplate for classes that contain members (groups/users), to make sure we offer a consistent interface"""

    @abc.abstractmethod
    def members_get(self):
        pass

    @abc.abstractmethod
    def member_add(self, member):
        pass

    @abc.abstractmethod
    def member_remove(self, member):
        pass
