import pandas as pd
import math

from datetime import datetime

from trendminer_interface.base import FactoryBase

from .timedelta_factory import TimedeltaFactory


# TODO: time factories need different error message and exception
class DatetimeFactory(FactoryBase):
    """Factory for creating datetimes"""
    tm_class = datetime

    def _get(self, ref):
        # Make sure the returned datetime is in the client timezone
        ts = pd.Timestamp(ref)
        if not ts.tz:
            ts = ts.tz_localize(self.client.tz)
        else:
            ts = ts.tz_convert(self.client.tz)
        return ts

    def _round(self, ts, resolution, rounding_fun):
        """Round datetime to given resolution using provided rounding function

        Parameters
        ----------
        ts : pandas.Timestamp
            Input timestamp
        resolution : pandas.Timedelta
            Rounding resolution
        rounding_fun : function
            Rounding function to apply

        Returns
        -------
        ts : pd.Timestamp
            Rounded timestamp
        """

        # Convert inputs if necessary
        resolution = TimedeltaFactory(client=self.client)._get(resolution) or self.client.resolution
        ts = self._get(ts)

        # Round and return
        rounded_timestamp = rounding_fun(ts.timestamp() / resolution.total_seconds()) * resolution.total_seconds()
        return datetime.fromtimestamp(rounded_timestamp, tz=ts.tzinfo)

    def round(self, ts, resolution=None):
        """Round datetime to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : pandas.Timedelta
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=round)

    def ceil(self, ts, resolution=None):
        """Round datetime up to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : pandas.Timedelta
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=math.ceil)

    def floor(self, ts, resolution=None):
        """Round datetime down to given resolution

        Parameters
        ----------
        ts : datetime or str
            Input datetime
        resolution : pandas.Timedelta or str or float
            Rounding resolution

        Returns
        -------
        ts : datetime
            Rounded datetime
        """
        return self._round(ts=ts, resolution=resolution, rounding_fun=math.floor)
