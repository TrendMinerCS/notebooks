import pandas as pd
import trendminer_interface._input as ip
from trendminer_interface.constants import CALCULATION_OPTIONS


@pd.api.extensions.register_dataframe_accessor("interval")
class IntervalAccessor:

    def __init__(self, pandas_obj):
        self._validate(pandas_obj)
        self._obj = pandas_obj

    @staticmethod
    def _validate(obj):
        if not isinstance(obj.index.dtype, pd.IntervalDtype):
            raise AttributeError("Methods can only be applied on DataFrame with IntervalIndex index")

    def set_closed(self, closed):
        return self._obj.set_index(
            self._obj.index.set_closed(closed)
        )

    def __set_index(self, left, right, name, drop):
        new_index = pd.IntervalIndex.from_arrays(
            left=left if left is not None else self._obj.index.left,
            right=right if right is not None else self._obj.index.right,
            closed=self._obj.index.closed,
            name=name,
            dtype=self._obj.index.dtype,
        )

        return (
            self._obj
            .reset_index(drop=drop)
            .set_index(new_index, drop=drop)
        )

    def __move_index(self, left, right, name, drop):
        if left is not None:
            left = self._obj.index.left + pd.Timedelta(left)
        if right is not None:
            right = self._obj.index.right + pd.Timedelta(right)
        return self.__set_index(left=left, right=right, name=name, drop=drop)

    def grow(self, left=None, right=None, name=None, drop=True):
        if left is not None:
            left = -pd.Timedelta(left)
        return self.__move_index(left=left, right=right, name=name, drop=drop)

    def shrink(self, left=None, right=None, name=None, drop=True):
        if right is not None:
            right = -pd.Timedelta(right)
        return self.__move_index(left=left, right=right, name=name, drop=drop)

    def move(self, by, name=None, drop=True):
        return self.__move_index(left=by, right=by, name=name, drop=drop)

    def after_start(self, length, name=None, drop=True):
        return self.__set_index(
            right=self._obj.index.left + pd.Timedelta(length),
            left=None, name=name, drop=drop,
        )

    def after_end(self, length, name=None, drop=True):
        return self.__set_index(
            left=self._obj.index.right,
            right=self._obj.index.right + pd.Timedelta(length),
            name=name, drop=drop,
        )

    def before_start(self, length, name=None, drop=True):
        return self.__set_index(
            left=self._obj.index.left - pd.Timedelta(length),
            right=self._obj.index.left,
            name=name, drop=drop,
        )

    def before_end(self, length, name=None, drop=True):
        return self.__set_index(
            left=self._obj.index.right - pd.Timedelta(length),
            right=None, name=name, drop=drop,
        )

    def merge(self):
        """Group by merged non-overlapping interval

        Returns
        -------
        pandas.DataFrameGroupBy
        """

        # TODO: smarter implementation. Sort and then check overlap between neighbours?
        # List of intervals. Longer intervals first for speed.
        intervals = sorted(self._obj.index, key=lambda x: x.length, reverse=True)

        new_intervals = []
        while len(intervals) > 0:
            current_interval = intervals[0]
            overlapping = [current_interval]
            non_overlapping = []
            for interval in intervals[1:]:
                if current_interval.overlaps(interval):
                    overlapping.append(interval)
                else:
                    non_overlapping.append(interval)

            if len(overlapping) == 1:
                new_intervals.append(current_interval)
                intervals = non_overlapping
            else:
                new_start = min([interval.left for interval in overlapping])
                new_end = max([interval.right for interval in overlapping])
                current_interval = pd.Interval(left=new_start, right=new_end, closed=current_interval.closed)
                intervals = [current_interval] + non_overlapping

        new_index = pd.IntervalIndex(
            new_intervals,
            name=self._obj.index.name,
            closed=self._obj.index.closed,
        )

        return self._obj.groupby(
            lambda interval: new_index[new_index.overlaps(interval)].item(),
            sort=True,
        )

    def calculate(self, tag, operation, name):
        """Perform an aggregation operation on a tag for the dataframe intervals

        Parameters
        ----------
        tag : Tag
            The tag on which the operation happens
        operation : str
            mean, min, max, range, start, end, delta, integral, or stdev
        name : str
            Name under which the calculation result needs to be stored in the DataFrame.

        Returns
        -------
        pandas.DataFrame
        """

        operation = ip.correct_value(operation, CALCULATION_OPTIONS)

        interval_dict = {
            str(i): interval
            for i, interval in enumerate(self._obj.index)
        }

        interval_data = [
            {
                "key": i,  # Assign increasing integer
                "startDate": interval.left.isoformat(timespec="milliseconds"),
                "endDate": interval.right.isoformat(timespec="milliseconds"),
            }
            for i, interval in interval_dict.items()  # Enumerate over the index
        ]

        payload = {
            "searchType": operation,
            "tags": [
                {
                    "tagName": tag.name,
                    "timePeriods": interval_data,
                    "shift": int(tag.shift.total_seconds()),
                    "interpolationType": tag._interpolation_payload_str_lower,
                }
            ],
            "filters": [],
        }
        response = tag.client.session.post("/compute/calculate/", json=payload)

        values = pd.Series(
            name=name,
            data={
                interval_dict[result["key"]]: result.get("value")
                for result in response.json()
            }
        )

        return self._obj.join(values)

    def invert(self, name, span=None):
        """Get the intervals inbetween the current intervals

        The output will be sorted from oldest to newest intervals.

        Parameters
        ----------
        name : str
            Name of the new, inverted IntervalIndex
        span : pandas.Interval, optional
            Range over which the intervals need to be inverted. When given, the time from the start of the span to the
            start of the first input interval, and the time from the last input interval to the end of the range are
            also returned as part of the inverted intervals, as long as they are not shorter than the index resolution
            (to avoid small intervals at the edges as a result of rounding). The span needs to encompass all input
            intervals. When no span is given, only the intervals inbetween the input intervals are returned as inverted
            intervals.

        Returns
        -------
        pandas.DataFrame
            Empty DataFrame with inverted IntervalIndex

        Notes
        -----
        The `closed` attribute of the IntervalIndex will invert too ('left' <-> 'right'; 'neither' <-> 'both').

        """

        empty_df = pd.DataFrame(index=self._obj.index)

        # Handle span
        if span is not None:
            # TODO: span timezone

            # Keep only original intervals that overlap with the span
            empty_df = empty_df[empty_df.index.overlaps(span)]

            # Add zero length intervals at the edges of the span
            dummy_intervals = pd.DataFrame(
                index=pd.IntervalIndex.from_arrays(
                    left=[span.left, span.right],
                    right=[span.left, span.right],
                    closed=empty_df.index.closed,
                    name=empty_df.index.name,
                )
            )
            empty_df = pd.concat([empty_df, dummy_intervals])

        # Get non-overlapping initial index
        merged_index = empty_df.interval.merge().first().index

        inverted_closed = {
            "left": "right",
            "right": "left",
            "both": "neither",
            "neither": "both",
        }[merged_index.closed]

        inverted_index = pd.IntervalIndex.from_arrays(
            left=merged_index.right[:-1],
            right=merged_index.left[1:],
            closed=inverted_closed,
            name=name,
        )

        return pd.DataFrame(index=inverted_index)


    # TODO: sample

# TODO: series accessor (single row)