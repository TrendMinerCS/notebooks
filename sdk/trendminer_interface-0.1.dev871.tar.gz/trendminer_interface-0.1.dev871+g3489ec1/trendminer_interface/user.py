import cachetools
import posixpath
import abc

from .exceptions import FromJsonError
from .constants import KEYCLOAK_REALM
from . import _input as ip
from trendminer_interface.base import (RetrievableBase, FactoryBase, LazyLoadingMixin, kwargs_to_class, ByFactory,
                                       AsTimestamp)
from .constants import MAX_GET_SIZE, MAX_USER_CACHE


class UserClient(abc.ABC):
    """Client for UserFactory"""
    @property
    def user(self):
        """Factory for retrieving users

        Returns
        -------
        UserFactory
        """
        return UserFactory(client=self)


class User(RetrievableBase, LazyLoadingMixin):
    """A TrendMiner user or client user

    Attributes
    ----------
    name : str
        TrendMiner username. The username of client users is `service-account-{client id}`.
    first_name : str
        Assigned first name
    last_name : str
        Assigned last name
    roles : list of str
        Roles assigned to the User
            - default-roles-trendminer: regular user rights. Always present, except for special Everyone-user.
            - tm_admin: application administrator
            - tm_system_admin: ConfigHub access
            - tm_shared_space_user: Special purpose shared access user. Cannot be combined with any admin roles.
    mail : str
        User email
    created : datetime
        User creation time
    subject_type : str
        User subject type: `USER` for regular users, `EVERYONE` for special Everyone-user

    Notes
    -----
    A special Everyone-user exists which is used to give permissions to all users.
    """
    endpoint = f"/auth/realms/{KEYCLOAK_REALM}/local/users/"
    created = AsTimestamp()

    def __init__(
        self,
        client,
        identifier,
        subject_type,
        name,
        roles,
        mail,
        first_name,
        last_name,
        created,
    ):
        RetrievableBase.__init__(self, client=client, identifier=identifier)
        self.name = name
        self.first_name = first_name
        self.last_name = last_name
        self.roles = roles
        self.mail = mail
        self.created = created
        self.subject_type = subject_type

    def _full_instance(self):
        if "identifier" in self.lazy:
            return UserFactory(client=self.client).from_name(ref=self.name)
        else:
            return UserFactory(client=self.client).from_identifier(ref=self.identifier)

    def _json(self):
        return self.identifier

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"<< User | {self._repr_lazy('name')} >>"


class UserFactory(FactoryBase):
    tm_class = User

    def __init__(self, client):
        super().__init__(client)

    @property
    def everyone(self):
        """'Everyone' user needed to give all users permissions/access at once

        Returns
        -------
        everyone : User
            User with identifier and
        """
        return self.tm_class(
            client=self.client,
            identifier="Everyone",
            subject_type="EVERYONE",
            name="Everyone",
            mail=None,
            roles=[],
            first_name=None,
            last_name=None,
            created=None,
        )

    def from_identifier(self, ref):
        """Retrieve a user from their identifier

        Parameters
        ----------
        ref : str
            User UUID

        Returns
        -------
        User
            User with the given identifier
        """
        link = posixpath.join(self._endpoint, ref)
        response = self.client.session.get(link)
        return self._from_json(response.json())

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=MAX_USER_CACHE), key=FactoryBase._cache_key_ref)
    def from_name(self, ref):
        """Retrieve a user from their name

        Parameters
        ----------
        ref : name
            User username

        Returns
        -------
        User
            User with the given username

        Notes
        -----
        When given username is equal to `everyone` (case-insensitive), a special Everyone-user is returned.
        """
        if ref.lower() == "everyone":
            return self.everyone

        params = {"username": ref}

        response = self.client.session.get(self.tm_class.endpoint, params=params)
        content = response.json()["_embedded"]["content"]

        # Since the call only returns exact username matches, only a single object should be returned. Nonetheless, we
        # robustly select the exact match in case multiple results are returned.
        return ip.object_match_nocase([self._from_json(data=data) for data in content], attribute="name", value=ref)

    def search(self, ref):
        """Retrieve a user by any of their properties

        Searches by username, first name, last name, and email

        Parameters
        ----------
        ref : str
            Partial match for username, first name, last name or email

        Returns
        -------
        list of User
            Users with a property matching the given search string

        Notes
        -----
        There is no endpoint for searching users by a specific property (e.g. username)

        Client users cannot be retrieved by this method. They can be retrieved by their exact name
        (`service-account-{client id}`) using the `.from_name` method.

        Searching for a first or last name with a string that includes spaces does not work.
        """
        params={
            "search": ref,
            "size": MAX_GET_SIZE
        }

        content = self.client.session.paginated(keys=["_embedded", "content"]).get(
            self.tm_class.endpoint,
            params=params
        )

        return [self._from_json(data=data) for data in content]

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=10), key=FactoryBase._cache_key_ref)
    def from_client(self, ref=None):
        """Get the user from an authenticated client

        Parameters
        ----------
        ref : TrendMinerClient, optional
            The client from which to get the authenticated user. Defaults to the client used to call this method.

        Returns
        -------
        User
            The user authenticated in the client
        """
        client = ref or self.client
        return self.from_name(client.username)

    def _from_json_everyone(self, data):
        if data.get("subjectType", "").upper() == "EVERYONE":
            return self.everyone
        else: # pragma: no cover
            raise FromJsonError(data)

    def _json_to_kwargs_base(self, data):
        return {
            "first_name": data.get("firstName"),
            "last_name": data.get("lastName"),
            "subject_type": "USER",
        }

    @kwargs_to_class
    def _from_json(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["userId"],
            "name": data["username"],
            "roles": data["roles"],
            "mail": data.get("email"),
            "created": data.get("createdDate"),
        }

    @kwargs_to_class
    def _from_json_limited(self, data):
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["identifier"],
            "name": data["username"],
        }

    @kwargs_to_class
    def _from_json_limited_id(self, data):
        """Used in context filter and work organizer"""
        return {
            "identifier": data["userId"],
            "name": data["userName"],
        }

    @kwargs_to_class
    def _from_json_name_only(self, data):
        """Create lazy instance from only the name"""
        return {"name": data}

    @kwargs_to_class
    def _from_json_identifier_only(self, data):
        """Create lazy instance from only the identifier"""
        return {"identifier": data}

    @property
    def _get_methods(self):
        return self.from_name,
