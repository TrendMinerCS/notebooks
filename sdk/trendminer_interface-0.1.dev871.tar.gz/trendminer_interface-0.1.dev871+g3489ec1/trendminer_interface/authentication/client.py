import abc

from .session import TrendMinerSession


class BaseClient(abc.ABC):
    """Handles all authentication for the client. Stores the session."""

    def __init__(
            self,
            url,
            client_id,
            client_secret,
            username,
            password,
            token,
            verify
    ):

        self.session = TrendMinerSession(base_url=url, verify=verify)
        self.session.login(client_id=client_id,
                           client_secret=client_secret,
                           username=username,
                           password=password,
                           token=token,
                           )

    def logout(self):
        """Explicit session logout. Invalidates token."""
        self.session.logout()

    @property
    def url(self):
        """TrendMiner appliance url"""
        return self.session.base_url

    def __repr__(self):
        return f"<< {self.__class__.__name__}" \
               f" | {self.url}" \
               f" | {self.session.token_decoded['preferred_username']} >>"

