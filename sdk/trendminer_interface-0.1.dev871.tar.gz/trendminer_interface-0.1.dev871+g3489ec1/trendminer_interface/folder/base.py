import abc

from trendminer_interface import _input as ip

from trendminer_interface.base import AuthenticatableBase
from trendminer_interface.constants import FOLDER_BROWSE_SIZE, WORK_ORGANIZER_CONTENT_OPTIONS


class FolderBase(AuthenticatableBase, abc.ABC):
    """Abstract base class for work organizer Folder and RootFolder

    Implements methods for getting items from a folder or the work organizer root folder
    """

    def __init__(self, client):
        super().__init__(client=client)
        self.identifier = None

    def get_children(self, included=None, excluded=None, folders_only=False):
        """Get the items in the current folder

        Parameters
        ----------
        included : list of str, optional
            Included work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        excluded : list of str, optional
            Excluded work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        folders_only : bool, default False
            Whether to only search for subfolders. Ignores `included` and èxcluded`

        Notes
        -----
        In the backend, monitors are included in the work organizer for technical reasons. However, in the user
        interface they are always filtered out. When `excluded` is kept at `None`, monitors are therefore also filter
        out. An empty list needs to provided explicitly to include monitors (`excluded=[]`).
        """
        if excluded is None:
            excluded = ["MONITOR"]
        included = [t if isinstance(t, str) else t.content_type for t in ip.any_list(included)]
        excluded = [t if isinstance(t, str) else t.content_type for t in ip.any_list(excluded)]
        included = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in included]
        excluded = [ip.correct_value(t, WORK_ORGANIZER_CONTENT_OPTIONS) for t in excluded]

        params = {
            "size": FOLDER_BROWSE_SIZE,
            "foldersOnly": folders_only,
            "parent": self.identifier,
        }

        if included:
            params.update({"includeTypes": included})
        elif excluded:
            params.update({"excludeTypes": excluded})

        response = self.client.session.get("/work/saveditem/browse", params=params)

        try:
            content = response.json()["_embedded"]["content"]
        except KeyError:
            content = []

        from .content_factory import FolderContentMultiFactory
        return [
            FolderContentMultiFactory(client=self.client)._from_json_work_organizer(data) for data in content
        ]


    def get_child_from_name(self, ref, included=None, excluded=None, folders_only=False):
        """Get a single object from a folder by its name

        Parameters
        ----------
        ref : str
            Name of the child work organizer object saved in the folder
        included : list of str, optional
            Included work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        excluded : list of str, optional
            Excluded work organizer item types. Options are: "VIEW", "FINGERPRINT", "CONTEXT_LOGBOOK_VIEW", "DASHBOARD",
            "FORMULA", "AGGREGATION", "VALUE_BASED_SEARCH", "DIGITAL_STEP_SEARCH", "SIMILARITY_SEARCH", "AREA_SEARCH",
            "CROSS_ASSET_VALUE_BASED_SEARCH", "TREND_HUB_2_VIEW", "FILTER", "MACHINE_LEARNING", "PREDICTIVE",
            "LEGACY_FINGERPRINT", "MONITOR"
        folders_only : bool, default False
            Whether to only search for subfolders. Ignores `included` and èxcluded`

        Notes
        -----
        In the backend, monitors are included in the work organizer for technical reasons. However, in the user
        interface they are always filtered out. When `excluded` is kept at `None`, monitors are therefore also filter
        out. An empty list needs to provided explicitly to include monitors (`excluded=[]`).

        """
        content = self.get_children(included=included, excluded=excluded, folders_only=folders_only)
        return ip.object_match_nocase(content, attribute="name", value=ref)
