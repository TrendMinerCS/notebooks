import json


def test_create(user1, af_name):

    prefix = user1.unique_prefix

    # folder
    folder = user1.folder.from_path(prefix, create_new=True)

    # trend
    thv = user1.trend.view(["TM_hour_Europe_Brussels"], layers=["8h"], live=True, name=prefix, parent=folder)
    thv.save()

    # context
    chv = user1.context.view(
        name=prefix,
        filters=[
            user1.context.filter.period("1h"),
            user1.context.filter.components(["TM_hour_Europe_Brussels"]),
        ],
        parent=folder
    )
    chv.save()

    # monitor
    vbs = user1.search.value("TM_hour_Europe_Brussels > 12", name=prefix, parent=folder)
    vbs.save()
    monitor = vbs.get_monitor()
    monitor.enabled = True
    monitor.update()

    # url
    url = "https://www.trendminer.com/wp-content/uploads/" \
          "2019/06/RGB-1-trendminer-logo-horizontal-fullcolor1200-300x90.png"

    # current values 1
    conditions1 = [
        user1.dashboard.values.condition(">", 10, "red"),
        user1.dashboard.values.condition("between", [0, 10], "orange"),
        (">=", 10, "#005EB8"),
        ]

    entries1 = [
        user1.dashboard.values.entry(component="TM_hour_Europe_Brussels", color='black', conditions=conditions1)
    ]

    # current values 2
    entries2 = [
        user1.dashboard.values.entry(
            component=f"{af_name}/Houston/Time/Day",
            conditions=[
                ("=", "Tuesday", "green"),
                ("contains", "u", "yellow"),
                ("contains", "w", "orange"),
                ("does not contain", "s", "red"),
                ("!=", "Friday", "red"),
            ]
        ),
        user1.dashboard.values.entry(
            component=f"{af_name}/Houston/Time/Hour",
            color="black",
            conditions=[
                ("between", [0, 10], "green"),
                ("between", [10, 20], "orange"),
                (">", 20, "red"),
            ]
        ),
        user1.dashboard.values.entry(
            component=f"{af_name}/Hasselt/Time/Year",
            color="blue"
        ),
        user1.dashboard.values.entry(
            component=f"{af_name}/Hasselt/Time/Hour",
            color="green",
            conditions=[
                ("not between", ["0, 10"], "red")
            ]
        ),
        user1.dashboard.values.entry(
            component=f"{af_name}/Houston/Time/Hour",
            color="green",
            conditions=[
                ("not between", ["0, 10"], "red")
            ]
        ),
    ]

    # collect tiles
    tiles = [
        user1.dashboard.trend(thv, x=0, y=0, rows=4, cols=4, title="Trend"),
        user1.dashboard.count(chv, x=4, y=0, rows=4, cols=2, title="Count"),
        user1.dashboard.gantt(chv, x=0, y=4, rows=4, cols=6, title="Gantt"),
        user1.dashboard.table(chv, x=0, y=8, rows=4, cols=10),
        user1.dashboard.monitor(monitor, x=6, y=0, rows=4, cols=2,
                                inactive_text="All good",
                                inactive_color="blue",
                                inactive_icon="snowflake",
                                ),
        user1.dashboard.external(url, x=6, y=4, rows=4, cols=4),
        user1.dashboard.values(entries1, x=8, y=0, rows=4, cols=2, graph=False, digits=0, timestamp=False),
        user1.dashboard.values(entries2, x=10, y=0, rows=12, cols=2, graph_duration="2h", digits=1),
        user1.dashboard.text("<p>MY TEXT</p>", x=0, y=12),
    ]

    # create dashboard
    db = user1.dashboard(
        tiles=tiles,
        name=prefix,
        parent=folder,
        scrollable=True,
    )

    db.save()
    db = user1.dashboard.from_identifier(db.identifier)
    assert db.tiles[0].content.get_data(resolution="5m")
    assert db.tiles[4].content.name

    db = user1.dashboard.from_path(f"{prefix}/{prefix}")
    db.live = True
    db.scrollable = False
    db.update()

    assert folder.get_children()

    folder.delete()
