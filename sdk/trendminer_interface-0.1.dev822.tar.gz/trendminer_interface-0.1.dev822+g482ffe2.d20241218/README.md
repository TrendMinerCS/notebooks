# TrendMiner Python Interface

## Goal 

The goal of this package is to provide a user-friendly interface to all TrendMiner functionality. This allows a user
to automate any in-app workflow with python. As such, this package should prove very useful as a basis for creating
scripts that automate tasks, or that extend upon the basic TrendMiner functionality.

This package is a work in progress. Not all in-app functionality is represented, and the package should not be
considered stable (names may change; functions have not been tested thoroughly).

## Development

To get started with development execute the following:

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
pip install -r dev_requirements.txt
```

For more info on automated testing, see [tests/README.md](./tests/README.md)

## TO DO: structural changes and enhancements

### Code quality
- [ ] Pylint checkers

### Structural changes
- [ ] Rethink factory classes. Currently, the SearchFactory copies methods from WorkOrganizerObjectFactory
- [ ] Rename and restructure files and classes: currently a lot of variation on class naming and in what folder they are.
- [ ] .get and .search methods should be private. We want users to learn to use specific methods.
- [ ] from_name should get priority on from_identifier in _get_methods method. A user will much more often input a string with the name than the identifier string. Going for from_name first will save us a failed request
- [ ] remove the blueprints concept. Too much work and complexity to implement.
- [ ] Implement an abstract base class for dependent items
  - access rights
  - context item attachments
  - Asset framework sync status
  - Tag index status
- [ ] base module code TODOs
- [ ] Methods that invoke an API call should not be properties, but explicit get_... methods
- [ ] Consistent factory naming: needs to be clear if it is an abstract factory (base) or a Multifactory.
- [ ] Always use factory object directly, not a path from self.client. Factories can be imported in the methods themselves to avoid circular imports.
- [ ] Eliminate multifactories as much as possible. Let user explicitly construct at least the user-facing types (tags, attributes, assets)
- [ ] General json method should be reserved only for where the object can actually be saved.
- [ ] Rethink _post_upgrades and _put_upgrades methods. These are partially re-implementing the logic from the factory methods.
- [ ] Investigate if it is worth changing to a single get/search method which take multiple arguments, which work with AND logic e.g.: `Tag.get(name, identifier)`, `Tag.search(name, description)`.
- [ ] Double underscore methods for truly private methods that should only be used completely internally?
- [ ] Class attribute consistency: they should always be implemented on an abstract base class, and that abstract base class should verify that they are defined using `abc.abstractmethod(lambda: None)
- [ ] Class naming should make it clear when a class is a Mixin
- [ ] Would it be better to rename `post` and `put` methods to `save` and `update`, respectively?
- [ ] Rethink lazy loading. Could it be more granular? In some cases, there is no single endpoint which loads all the data (e.g for a Tag) and complex logic is required anyway.
- [ ] revisit copy behaviour. We are mixing copy and deepcopy. Confusing to implement our own copy method, rather than use magic methods.

### Work / folder
- [x] Do not call work organizer with IncludeData=True, as this does not include all data. Better to load an initial object and let lazy loading to take care of the rest. Cfr. work TODO
- [x] Get rid of root folder concept (cfr folder TODO)
- [x] Evaluate file structure. A lot of content in folder.py, which sits separated from the work module
- [x] Remove `Folder.subfolders` utility method. Not worth the introduction of another method since it only does browse(folders_only=True). Also seems inconsistent to have a dedicated browse method only for folders.
- [x] Refactor `Folder` method names and parameters to be consistent with the asset framework
  - [x] `Folder.get` -> `Folder.get_child_from_name`
  - [x] `Folder.browse` -> `Folder.get_children`. 
  - [x] `WorkOrganizerObject.__call__` parameter `folder` -> `parent`
- [x] Remove `Folder.add_folder` utility method, which shortcuts folder instantiation + post. Creates too many different methods to do the same thing, is not consistent with asset tree builder, and is not consistent with other work organizer objects.
- [x] Add `excluded` and `folders_only` parameters to `Folder.get_child_from_name`. This is more consistent and removes the need for object matching logic in the `.from_path` methods, since they can then use a `get_child_from_name` call directly.
- [x] `SearchFactory(Multifactory).from_path` duplicates folder code

### Documentation
- [ ] Documentation structure review

### Assets
- [x] Code TODOs
- [x] Add digital twin builder functionality
- [x] root_asset property -> get_root_asset method
- [x] Get rid of root asset
- [x] Method to retrieve specific child directly from asset
- [x] Explicitly split between asset and attribute factories -> more explicit usage and less complicated code
- [x] Asset.children property -> Asset.get_children method
- [x] by_rsql should be made private

### Caching
- [ ] Cacheing review: which (other) objects can be cached?
- [ ] Caching strategy for asset, placed on the browse; cache should be cleared when AF is updated
- [ ] Would it be better if the caches lived on the client level? Now caches can be filled with references to clients that no longer exist. Would also simplify clearing of cache.
- [ ] There is no entry added in the cache when a request fails. So when looping over a get method where failure is common/expected, we still can send many many requests.
- [ ] Caching user documentation in README
- [ ] folder.py TODO on caching strategy

### Versioning
- [x] Make versions specific to the TrendMiner version. Check the version when creating a client and throw a warning if that TrendMiner version is not explicitly supported.
- [x] Remove Version object: too much complexity for the added value

### Tags
- [x] ~~Tag should have an interpolation type attribute. Now we only have a tag type attribute, but from many endpoints we only receive the interpolation type, giving us no choice but to set the tag type to LazyAttribute(). This generates unnecessary _full_instance() calls.~~ -> Simplicity > small performance gain
- [x] Endpoint for getting the last value
- [x] Get imported tag (cfr io TODO)
- [x] Code TODOs
- [x] Tag and attribute should have shared mixin, which should have `_from_json_current_value_tile`.
- [x] Implement dedicated get_data methods for each form: get_data (interpolated), get_index_data, get_chart_data

### Monitors
- [ ] Rethink search-monitor relationship. What are the workflows by which we can get these. Should there not be a search attribute in MonitorFactory and the other way around?
- [ ] Allow fingerprint monitoring

### ConfigHub datasources
- [ ] ConfigHub datasource creation is broken because of API changes
- [ ] Support all datasource types, including context and asset data
- [ ] Test for all datasource types

### ConfigHub users
- [ ] Support non-local users. Currently, we are hard-coding the /local/users/ endpoint

### Users
- [x] ~~Add support for non-local users. Cfr. user.py TODO~~
- [ ] Add docstrings to user classes

### Searches
- [ ] Allow the direct creation of value-based search query filters; analogous to client.search.similarity.query
- [ ] Implement similarity search 'limitResults' optional parameter
- [ ] Code TODOs

### TrendHub
- [ ] TrendHub view filters should be accounted for when getting tag data for the view (those periods should be skipped)
- [ ] Review class-based configuration of TrendHub views. Some configuration options are still in raw json format.
- [ ] Support for filters? Implementation of Filter class?
- [ ] Layer TODOs
- [ ] trendhub TODOs

### ContextHub
- [ ] Review class-based configuration of TrendHub views. Some configuration options are still in raw json format.
- [ ] Implement context item type/field by_name method -> use this also in the from_name methods
- [ ] Support scatter type for ContextHub views
- [ ] Implement method to see if context item is approved
- [ ] Better control of context item events: only possible to create events from list of timestamps or from interval. If there are 4 possible states, but we only want to use 3 of them for our context item, there is no way to do this.
- [ ] Code TODOs
- [ ] Review if ContextItem.fields should be private

### Time utility functions
- [ ] time/* Code TODOs
- [x] Should the Period class exist? It is so far only used in the context period filter, and could just be defined as a duration.
- [x] Time factory classes should become TrendMinerFactory, ~~and have more defined `__call__` methods~~.

### DashHub
- [ ] Add support for text tile
- [ ] Add support for external content tile

### Layers
- [ ] Investigate if Fingerprint and TrendHub Layer(Factory) should have joint base classes.

### Intervals
- [ ] Investigate if it would be possible to do method chaining (similar to pandas) for lists of intervals and context items. This would require a class that (at least conceptually) subclasses list. This would allow to drop the `inplace` parameter on calculations.
- [ ] Review all interval methods and magic methods, especially together with a potential new IntervalList class. Make behaviour logical and consistent.
- [ ] Interval.data should be private.

### Tests
- [x] Tests should not print output; makes it hard to debug using temporary print statements

### Packages
- [ ] Get rid of json_fix package
- [ ] See if we 100% need to include numpy