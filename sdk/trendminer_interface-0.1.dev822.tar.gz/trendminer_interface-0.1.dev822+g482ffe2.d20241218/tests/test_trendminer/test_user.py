def test_self(client, user1):
    assert user1.user.self()
    assert client.user.self()


def test_everyone(client):
    assert client.user.everyone()


def test_search(client, user1):
    user = client.user.from_name(user1.username)
    assert client.user.by_any(user.name)
    assert client.user.by_any(user.first.replace(" ", "*"))
    assert client.user.by_any(user.last.replace(" ", "*"))
    assert client.user.by_any(user.mail)
    assert client.user.from_identifier(user.identifier)
