# Copy this file and name it config.py
# Make sure to read tests/README.md

url = "https://my-test-server.trendminer.net/"

asset_framework_name = "SDK test"

# Client user
client = {
    "url": url,
    "client_id": "",
    "client_secret": "",
    "tz": "Europe/Brussels",
}

# Regular user 1
user1 = {
    **client,
    "username": "",
    "password": "",
}

# Regular user 2
user2 = {
    **client,
    "username": "",
    "password": "",
}

# Application admin user
application_administrator =  {
    **client,
    "username": "",
    "password": "",
}

# System administrator user (for ConfigHub tests)
system_administrator =  {
    **client,
    "username": "",
    "password": "",
}
