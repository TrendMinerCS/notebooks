import abc
import posixpath

from trendminer_interface.base import TrendMinerFactory
from trendminer_interface.constants import MAX_GET_SIZE


class ContextConfigurationFactoryMixin(TrendMinerFactory, abc.ABC):
    """Mixin class for context configuration class factories

    Factories for
    - Context workflow
    - Context field
    - Context type

    Implements sql-style query searching and some base retrieval methods
    """

    def _query_params(self, params):
        """Execute an sql-style query on the TrendMiner appliance

        Parameters
        ----------
        params : dict
            Request parameters. Needs to contain the sql query under the "query" key.

        Returns
        -------
        list
            List of instances matching the given query.
        """
        params.update({"size": MAX_GET_SIZE})
        content = self.client.session.paginated(keys=["content"]).get(self._endpoint + "search", params=params)
        return [self._from_json(data) for data in content]

    def _query_search(self, ref, search_key):
        """Sends sql query where we search for a single given key to match a value

        Parameters
        ----------
        ref : str
            The value to match
        search_key : str
            The key which needs to match this value

        Returns
        -------
        list
            List of instances where the given key matches the given value
        """
        params = {"query": f"{search_key}=='{ref}'"}
        return self._query_params(params)

    def _query_in(self, refs, search_key):
        """Sends sql query where we search for a single given key to be any of a number of given values

        Parameters
        ----------
        refs : list of str
            The list of values the key should match one of
        search_key : str
            The key with which to match the value

        Returns
        -------
        list
            List of instances where the given key matches one of the given values
        """
        queries = ",".join([f"'{ref}'" for ref in refs])
        params = {"query": f"{search_key}=in=({queries})"}
        return self._query_params(params)

    @abc.abstractmethod
    def _from_json(self, data):
        pass

    def from_identifier(self, ref):
        """Retrieve instances from its identifier

        Parameters
        ----------
        ref : str
            Instance UUID

        Returns
        -------
        Any
            Instance with the given UUI
        """
        link = posixpath.join(self._endpoint, ref)
        response = self.client.session.get(link)
        return self._from_json(response.json())

    def all(self):
        """Retrieve all instances

        Returns
        -------
        list
            List of all instances the user has access to
        """
        params = {"size": MAX_GET_SIZE}
        content = self.client.session.paginated(keys=["content"]).get(self._endpoint, params=params)
        return [self._from_json(data) for data in content]
