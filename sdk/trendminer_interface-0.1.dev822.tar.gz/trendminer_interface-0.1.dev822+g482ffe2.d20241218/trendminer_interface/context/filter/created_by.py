from trendminer_interface.context.filter.base.filter import ContextFilter
from trendminer_interface.base import TrendMinerFactory, ByFactory
from trendminer_interface.user import UserFactory


class CreatedByFilter(ContextFilter):
    """Filter on context item creator

    Attributes
    ----------
    users : list of User or ClientUser
        Users on which to filter
    """
    filter_type = "CREATED_BY_FILTER"
    users = ByFactory(UserFactory, "list")

    def __init__(self, client, users):
        super().__init__(client=client)
        self.users = users

    def __json__(self):
        return {
            **super().__json__(),
            "users": self.users,
        }


class CreatedByFilterFactory(TrendMinerFactory):
    """Factory for created-by context filter creation"""
    tm_class = CreatedByFilter

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        CreatedByFilter
        """
        return self.tm_class(
            client=self.client,
            users=[
                UserFactory(client=self.client)._from_json_limited_id(user)
                for user in data["userDetails"]
            ]
        )

    def __call__(self, users):
        """Create new CreatedByFilter

        Parameters
        ----------
        users : list
            List of (reference to) User or ClientUser


        Returns
        -------
        CreatedByFilter
            Filter on context item creator
        """
        return self.tm_class(client=self.client, users=users)
