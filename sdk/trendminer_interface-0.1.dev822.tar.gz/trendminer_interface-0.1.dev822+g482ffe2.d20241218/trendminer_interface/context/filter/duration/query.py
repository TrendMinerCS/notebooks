from trendminer_interface.context.filter.base import ContextQuery, ContextQueryFactory
from trendminer_interface.times import time_json, TimedeltaFactory
from trendminer_interface.base import ByFactory


class DurationQuery(ContextQuery):
    """Query based on context item duration

    Attributes
    ----------
    value : datetime.timedelta
        Context item duration criterion
    """
    value = ByFactory(TimedeltaFactory)

    def __init__(self, client, operator, value):
        super().__init__(client=client, operator=operator, value=value)

    def __json__(self):
        return {
            "operator": self.operator_str,
            "value": time_json(self.value),
        }


class DurationQueryFactory(ContextQueryFactory):
    """Factory for creating context item duration queries"""
    tm_class = DurationQuery
