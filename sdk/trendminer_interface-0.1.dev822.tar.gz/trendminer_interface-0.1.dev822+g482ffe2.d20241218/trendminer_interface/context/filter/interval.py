from trendminer_interface.context.filter.base.filter import ContextFilter
from trendminer_interface.times import time_json, IntervalFactory
from trendminer_interface.base import ByFactory, TrendMinerFactory


class IntervalFilter(ContextFilter):
    """Filter on context item event or creation time through fixed interval

    Attributes
    ----------
    interval : Interval
        The time interval on which to filter
    created_date : bool, default False
        Whether we need to filter on creation time rather than event time
    """
    filter_type = 'INTERVAL_FILTER'
    interval = ByFactory(IntervalFactory)

    def __init__(self, client, interval, created_date):
        super().__init__(client=client)
        self.interval = interval
        self.created_date = created_date

    def __json__(self):
        data = {
            "startDate": time_json(self.interval.start),
            "endDate": time_json(self.interval.end),
            "type": self.filter_type,
        }

        if self.created_date:
            data.update({'intervalType': 'CREATED_DATE'})

        return data


class IntervalFilterFactory(TrendMinerFactory):
    """Factory for creating context interval filter"""
    tm_class = IntervalFilter

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        IntervalFilter
        """
        return self.tm_class(
            client=self.client,
            interval=IntervalFactory(client=self.client)._from_json(data),
            created_date=data.get("intervalType") == 'CREATED_DATE'
        )

    def __call__(self, interval, created_date=False):
        """Create new filter on context item interval

        Parameters
        ----------
        interval : Any
            Interval on which to filter
        created_date : bool
            Whether we need to filter on creation time rather than event time

        Returns
        -------
        IntervalFilter
            Interval filter on context item event or creation time
        """
        return self.tm_class(client=self.client, interval=interval, created_date=created_date)