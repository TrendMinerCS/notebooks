from trendminer_interface.base import TrendMinerFactory, Serializable, ByFactory
from trendminer_interface.times import time_json, IntervalFactory
from trendminer_interface import _input as ip
from trendminer_interface.constants import LINE_STYLES


class FingerprintLayer(Serializable):
    interval = ByFactory(IntervalFactory)

    def __init__(
            self,
            client,
            base,
            interval,
            name,
            line_style,
            hidden_references,
    ):
        super().__init__(client=client)
        self.base = base
        self.interval = interval
        self.name = name
        self.line_style = line_style
        self.hidden_references = hidden_references

    @property
    def line_style(self):
        if self.base:
            return "SOLID"
        return self._line_style if self._line_style != "SOLID" else "DASHED"

    @line_style.setter
    @ip.options(LINE_STYLES)
    def line_style(self, line_style):
        self._line_style = line_style

    def __json__(self):
        return {
            "base": self.base,
            "name": self.name,
            "properties": {
                "lineStyle": self.line_style,
                "hiddenDataReferences": self.hidden_references,
            },
            "timePeriodStart": time_json(self.interval.start),
            "timePeriodEnd": time_json(self.interval.end),
        }


class FingerprintLayerFactory(TrendMinerFactory):
    tm_class = FingerprintLayer

    @property
    def _get_methods(self):
        return self.from_interval,

    def from_interval(self, interval):
        """Create a FingerprintLayer from a given Interval

        Intended to convert list of intervals into layers when the user creates a view.
        Layer will not be base by default, and have the "DASHED" linestyle.

        Parameters
        ----------
        interval : Interval or Any
            Interval to be turned into a layer
        """
        return self.tm_class(
            client=self.client,
            base=False,
            interval=interval,
            name="",
            line_style="DASHED",
            hidden_references=[],
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        FingerprintLayer
        """
        return self.tm_class(
            client=self.client,
            base=data["base"],
            interval=IntervalFactory(client=self.client)._from_json_fingerprint_layer(data),
            name=data["name"],
            line_style=data["properties"]["lineStyle"],
            hidden_references=data["properties"]["hiddenDataReferences"],
        )
