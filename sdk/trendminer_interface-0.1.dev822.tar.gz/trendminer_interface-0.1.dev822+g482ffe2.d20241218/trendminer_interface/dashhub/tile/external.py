from .base import Tile, TileFactoryBase


class ExternalContentTile(Tile):
    """External content dasbhoard tile"""
    visualization_type = "EXTERNAL_CONTENT"
    min_size = (1, 2)

    def _json_configuration(self):
        return {
            "url": self.content
        }


class ExternalContentTileFactory(TileFactoryBase):
    """Factory for creating external conten dahboard tiles"""
    tm_class = ExternalContentTile

    def _from_json_content(self, data):
        return data["url"]
