from trendminer_interface.base import Serializable, TrendMinerFactory, AsColor
from trendminer_interface.tag import Tag
from trendminer_interface.component_factory import ComponentFactory
from trendminer_interface.base import ByFactory
from .condition import CurrentValueConditionFactory


class CurrentValueEntry(Serializable):
    """Current value tile entry

    Attributes
    ----------
    component : Tag or Attribute
        Time-series component giving the current value
    color : Color
        Default color if no condition is triggered
    conditions : list of CurrentValueCondition
        Conditions for the color of the tile
    """
    component = ByFactory(ComponentFactory)
    conditions = ByFactory(CurrentValueConditionFactory, "list")
    color = AsColor(choose=True)

    def __init__(self, client, component, color, conditions):
        Serializable.__init__(self, client=client)
        self.color = color  # Unconditioned color
        self.component = component
        self.conditions = conditions

    def __json__(self):
        return {
            "componentIdentifier": self.component.identifier,
            "conditions": [{"color": self.color.hex_l.upper(), "values": []}] + self.conditions,
            "identifier": self.component.identifier,
            "path": None if isinstance(self.component, Tag) else self.component.path_hex,
            "type": self.component.component_type,
        }


class CurrentValueEntryFactory(TrendMinerFactory):
    """Factory for instantiating and retrieving current value entries"""
    tm_class = CurrentValueEntry

    def __call__(self, component, color="blue", conditions=None):
        """Instantiate a new current value tile entry

        Parameters
        ----------
        component : Tag or Attribute of str
            Time-series component giving the current value
        color : Color or str
            Default color if no condition is triggered
        conditions : list of CurrentValueCondition or list of tuple, optional
            Conditional coloring criteria for the tile

        Returns
        -------
        CurrentValueEntry
        """
        return self.tm_class(
            client=self.client,
            component=component,
            color=color,
            conditions=conditions,
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        CurrentValueEntry
        """
        return self.tm_class(
            client=self.client,
            component=ComponentFactory(client=self.client)._from_json_current_value_tile(data),
            color=data["conditions"][0]["color"],  # unconditioned maps to entry color, not to a separate condition
            conditions=[
                CurrentValueConditionFactory(client=self.client)._from_json(condition)
                for condition in data["conditions"][1:]  # First condition is a blank for some reason
            ]
        )

