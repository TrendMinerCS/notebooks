import abc
import time

from trendminer_interface.base import WorkOrganizerObject, WorkOrganizerFactory
from trendminer_interface.constants import SEARCH_REFRESH_SLEEP, MAX_GET_SIZE
from trendminer_interface.times import IntervalFactory
from trendminer_interface.base import ByFactory, kwargs_to_class

import trendminer_interface._input as ip

from .calculation import SearchCalculationFactory


class Search(WorkOrganizerObject, abc.ABC):
    """Base class for searches

    Attributes
    ----------
    search_request_identifier : str
        UUID of the latest search request, required to extract the search results. Automatically added/updated when
        executing the search.
    calculations : list of SearchCalculation
        Calculations added to the search
    identifier_complex : str
        UUID that is used for retrieving a monitor; "complexId" in the backend
    """
    search_type = None
    refresh_sleep = SEARCH_REFRESH_SLEEP

    interval = ByFactory(IntervalFactory)
    calculations = ByFactory(SearchCalculationFactory, "list")

    def __init__(
            self,
            client,
            identifier,
            identifier_complex,
            name,
            description,
            parent,
            owner,
            last_modified,
            calculations,
    ):
        super().__init__(client=client, identifier=identifier, name=name, description=description, parent=parent,
                         owner=owner, last_modified=last_modified)

        self.search_request_identifier = None
        self.calculations = calculations
        self.identifier_complex = identifier_complex

    def _full_instance(self):
        if "identifier" not in self.lazy:
            return self.client.search.from_identifier(self.identifier)

        # Identifier is lazy when we get a search from a monitor
        # If name is also lazy, the name is loaded when we load the monitor
        if "name" in self.lazy:
            self.get_monitor()
            assert "name" not in self.lazy

        # Retrieve potential matches by name; match exactly on the complex identifier
        return ip.object_match_nocase(
            self.client.search.by_name(self.name),
            "identifier_complex",
            self.identifier_complex
        )

    @property
    @abc.abstractmethod
    def tags(self):
        """Tags used in the search"""
        pass

    def _post_updates(self, response):
        super()._post_updates(response)
        self.identifier_complex = response.json()["complexId"]

    def _json_definition(self):
        return {
            "calculations": self.calculations,
            "type": self.content_type,
        }

    def execute(self, interval='6M', excluded_intervals=None):
        """Execute the search on the server

        Does not retrieve the results. Only retrieves the `search_request_identifier` attribute, allowing the results
        can be extracted with the `extract_results` method.

        Parameters
        ----------
        interval : Interval or Any, default '6M'
            Interval to search in
        excluded_intervals : list of Interval or Any
            Intervals to filter out while searching
        """
        interval = IntervalFactory(client=self.client).get(interval)
        excluded_intervals = IntervalFactory(client=self.client).list(excluded_intervals)
        json_search = {
            "contextTimePeriod": interval,
            "definition": self._json_definition(),
            "exclusionPeriods": excluded_intervals,
        }
        response = self.client.session.post("/compute/search-requests", json=json_search)
        self.search_request_identifier = response.json()["id"]

    def extract_results(self):
        """Extract the results of the latest search execution

        Uses the `search_request_identifier` attribute to extract the results. Search must have been executed first
        using the `execute` method, and execution must have finished. Readyness can be checked with the `ready` method.

        Returns
        -------
        list of Interval
            Search results, including calculations
        """
        content = self.client.session.paginated(keys=["content"]).get(
            f"/compute/search-requests/{self.search_request_identifier}/results",
            params={"size": MAX_GET_SIZE},
        )

        results = [IntervalFactory(client=self.client)._from_json_search_result(data) for data in content]
        results = sorted(results, key=lambda x: x.start)  # oldest result first

        # null results not part of json result, set them manually
        # convert digital tag results
        for calculation in self.calculations:
            numeric = calculation.tag.numeric
            if not numeric:
                states = calculation.tag.states
            for result in results:
                result.data.setdefault(calculation.key)
                if not numeric and isinstance(result.data[calculation.key], int):
                    result.data[calculation.key] = states.get(result.data[calculation.key])

        return results

    def ready(self):
        """Checks wether the latest search execution has finished

        Results can only be retrieved after execution has finished on the server.

        Returns
        -------
        ready : bool
            Wether the latest search execution has finished
        """
        response = self.client.session.get(
            f"/compute/search-requests/{self.search_request_identifier}",
        )
        return response.json()["status"].upper() != "IN_PROGRESS"

    def get_results(self, interval="6M", excluded_intervals=None):
        """Executes search and extracts results from the server

        Convenience method for the user. Combines the `execute` and `extract_results` methods. Waits before execution
        has finished (checked in a loop) before the extraction to avoid errors. Downside is that code execution is
        halted (from doing things not requiring the search results) while search execution on the appliance is ongoing.

        Parameters
        ----------
        interval : Interval or Any, default '6M'
            Interval to search in
        excluded_intervals : list of Interval or Any
            Intervals to filter out while searching

        Returns
        -------
        list of Interval
            Search results, including calculations and potentially similarity score (interval["score"]). Sorted always
            from oldest to newest.
        """
        self.execute(interval=interval, excluded_intervals=excluded_intervals)
        time.sleep(self.refresh_sleep)
        while not self.ready():
            time.sleep(self.refresh_sleep)
        return self.extract_results()

    def get_monitor(self):
        """Retrieve the monitor belonging to the search

        Returns
        -------
        Monitor
        """
        return self.client.monitor.from_search(self)


class SearchFactoryBase(WorkOrganizerFactory, abc.ABC):
    """Base factory for searches"""

    @kwargs_to_class
    def _from_json_monitor(self, data):
        """Construct search from monitor json

        For when getting monitor from search id
        """
        return {
            "identifier_complex": data["searchId"],
            "owner": self.client.user._from_json_name_only(data["username"]),
            "name": data["name"],
        }

    @kwargs_to_class
    def _from_json_monitor_all(self, data):
        """Construct search from monitor json when getting a list of all monitors

        Contrary to when getting a single monitor, no info on the owner is returned. In theory, this should always be
        the `client.user`, but for robustness we only work with the info that is actually returned and leave the owner
        as a LazyAttribute.
        """
        return {
            "identifier_complex": data["searchId"],
            "name": data["name"],
        }

    @kwargs_to_class
    def _from_json_monitor_nameless(self, data):
        """Construct search from direct call to monitor ID. Does not retrieve monitor name."""
        return {
            "identifier_complex": data["searchId"],
            "owner": self.client.user._from_json_name_only(data["username"]),
        }

    @kwargs_to_class
    def _from_json_filter(self, data):
        return {
            "identifier_complex": data["properties"]["searchIdentifier"],
            "name": data["properties"]["searchMetaData"]["name"],
            "description": data["properties"]["searchMetaData"]["description"]
        }
