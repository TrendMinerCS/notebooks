from copy import deepcopy

from trendminer_interface import _input as ip
from trendminer_interface.constants import CALCULATION_OPTIONS
from trendminer_interface.times import IntervalFactory


def calculate(tag, intervals, operation, key=None, inplace=False, fun=None):
    """Perform an aggregation operation on a tag for given intervals

    Parameters
    ----------
    tag : Tag
        The tag on which the operation happens
    intervals : list
        Intervals or context items on which to perform the aggregation
    operation : str
        mean, min, max, range, start, end, delta, integral, or stdev
    key : str, optional
        Key under which the calculation result needs to be stored on the interval. Defaults to the given operation.
    inplace : bool, default False
        When True, no value is returned, but the calculation results are added to the input values under the given
        key. Otherwise, copies of the intervals are returned on which the calculations results have been added.
    fun : function, optional
        Function to be applied to calculation results, e.g., `lambda x: x*24` to correct integral calculation units
        (from days to hours)

    Returns
    -------
    list or None
        Returns intervals and/or context items when `inplace=False`, no output if `inplace=True`. For intervals,
        calculations are added under `Interval.data`. When `inplace=True`, for context items the values are added under
        `ContextItem.fields`.
    """
    key = key or operation
    operation = CALCULATION_OPTIONS[ip.case_correct(operation, CALCULATION_OPTIONS.keys())]

    fun = fun or (lambda v: v)
    intervals = ip.any_list(intervals)
    if len(intervals) == 0:
        if inplace:
            return
        return []
    intervals = [
        IntervalFactory(client=tag.client).get(interval)
        if not isinstance(interval, tag.client.context.item.tm_class)
        else interval
        for interval in intervals
    ]

    interval_dict = {f"{key}{i}": interval for i, interval in enumerate(intervals)}

    from trendminer_interface.context import ContextItem
    payload = {
        "searchType": operation,
        "tags": [
            {
                "tagName": tag.name,
                "timePeriods": [
                    {"key": interval_key, **interval.__json__()}
                    if not isinstance(interval, ContextItem)
                    else {"key": interval_key, **interval.interval.__json__()}
                    for interval_key, interval in interval_dict.items()
                ],
                "shift": int(tag.shift.total_seconds()),
                "interpolationType": tag._interpolation_payload_str_lower,
            }
        ],
        "filters": [],
    }
    response = tag.client.session.post("/compute/calculate/", json=payload)

    if tag.numeric:
        mapper = lambda v: fun(v)
    else:
        mapper = lambda v: fun(tag.states.get(v))

    value_dict = {result["key"]: mapper(result.get("value")) for result in response.json()}

    if inplace:
        for interval_key, interval in interval_dict.items():
                interval.update({key: value_dict[interval_key]})

    else:
        output_intervals = []
        for interval_key, interval in interval_dict.items():
            output_interval = interval.copy()
            output_interval.update({key: value_dict[interval_key]})
            output_intervals.append(output_interval)

        return output_intervals
