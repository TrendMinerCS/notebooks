import numpy as np
import pandas as pd
import random
import abc

from collections.abc import MutableMapping

from trendminer_interface.base import ByFactory, TrendMinerFactory, Serializable

from .parsers import time_json
from .datetime_factory import DatetimeFactory
from .timedelta_factory import TimedeltaFactory


class IntervalClient(abc.ABC):
    """Client for interval factory"""

    @property
    def interval(self):
        """Datasource factory

        Returns
        -------
        DatasourceFactory
        """
        return IntervalFactory(client=self)


class Interval(Serializable, MutableMapping):
    """Time interval, potentially with data attached

    Attributes
    ----------
    start : datetime
        Interval start timestamp
    end : datetime
        Interval end timestamp
    data : dict
        Data associated with the interval. There are no constraints to what can be in the dict, though typically the
        dict keys would be strings. An Interval can be used to create a ContextItem, in which case `data` will be turned
        into  the `fields` attribute, and dict values should thus be of a type valid for field values (float or str).
    is_open : bool
        Whether the interval was still uncompleted in some way when it was retrieved, e.g.,  a search result that is
        still ongoing. The end timestamp should in that case be equal to the interval creation time (though will not
        update after creation).

    Notes
    -----
    Interval instances can be directly used like a dict instance. For example, calling `interval["temp"]` would be short
    for calling `interval.data["temp"]`.

    """
    start = ByFactory(DatetimeFactory)
    end = ByFactory(DatetimeFactory)

    def __init__(self, client, start, end, is_open, data=None, identifier=None):
        super().__init__(client=client)
        self.is_open = is_open
        self.start = start
        self.end = end
        self.is_open = is_open
        self.data = data or {}
        self.identifier = identifier

    @property
    def duration(self):
        """Interval duration

        Cannot be set directly, but is a result of interval start and end timestamp.

        Returns
        -------
        timedelta
        """
        return self.end - self.start

    def total_seconds(self):
        """Interval duration in number of seconds

        Cannot be set directly, but is a result of interval start and end timestamp.

        Returns
        -------
        float
        """
        return self.duration.total_seconds()

    def floor(self, resolution=None, inplace=False):
        """Round down start and end dates to the given resolution, potentially narrowing down the interval"""
        new_start = DatetimeFactory(client=self.client).ceil(self.start, resolution=resolution)
        new_end = DatetimeFactory(client=self.client).floor(self.end, resolution=resolution)

        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return IntervalFactory(client=self.client)(new_start, new_end, data=self.data)

    def __floor__(self):
        return self.floor()

    def ceil(self, resolution=None, inplace=False):
        """Round up start and end dates to the given resolution, potentially expanding the interval"""
        new_start = DatetimeFactory(client=self.client).floor(self.start, resolution=resolution)
        new_end = DatetimeFactory(client=self.client).ceil(self.end, resolution=resolution)

        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return IntervalFactory(client=self.client)(new_start, new_end, data=self.data)

    def __ceil__(self):
        return self.ceil()

    def before(self, duration, inplace=False):
        """Get the interval leading up to the current interval

        Parameters
        ----------
        duration : Any
            Value convertible into timedelta. Duration of the interval to be returned.
        inplace : bool, default False

        Returns
        -------
        Interval or None
            The interval before the current interval (when `inplace=False`)
        """

        duration = TimedeltaFactory(client=self.client).get(duration)
        new_start = self.start - duration
        new_end = self.start
        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return IntervalFactory(client=self.client)(new_start, new_end, data=self.data)

    def after(self, duration, inplace=False):
        """Get the interval after the current interval

        Parameters
        ----------
        duration : Any
            Value convertible into timedelta. Duration of the interval to be returned.
        inplace : bool, default False

        Returns
        -------
        Interval or None
            The interval after the current interval (when `inplace=False`)
        """

        duration = TimedeltaFactory(client=self.client).get(duration)
        new_start = self.end
        new_end = self.end + duration
        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return IntervalFactory(client=self.client)(new_start, new_end, data=self.data)

    def shift(self, shift, inplace=False):
        """Shift the full interval over a given time

        Parameters
        ----------
        shift : timedelta or str
            The distance with which to shift the interval
        inplace : bool, default False
            Whether the current interval should be edited in place, or a new edited interval should be returned.

        Returns
        -------
        Interval or None
            An edited interval, or no output (when `inplace=False`)
        """
        shift = TimedeltaFactory(client=self.client).get(shift)
        new_start = self.start + shift
        new_end = self.end + shift
        if inplace:
            self.start = new_start
            self.end = new_end
        else:
            return IntervalFactory(client=self.client)(new_start, new_end, data=self.data)

    # TODO: much more logical to have an `n` parameter with the number of intervals
    # TODO: do we need this method at all? Only used in Tag.get_data
    def split(self, max_size):
        """Split the period into equal intervals smaller or equal to the given size
        """
        max_size = TimedeltaFactory(client=self.client).get(max_size)
        if self.duration <= max_size:
            return [self]

        intervals = int(np.ceil(self.total_seconds() / max_size.total_seconds()))

        dates = pd.date_range(self.start, self.end, periods=intervals+1)
        dates = dates.round("1ms")  # Round to the highest resolution supported by TrendMiner

        return [
            IntervalFactory(client=self.client)(start, end, data=self.data)
            for start, end in zip(dates[0:-1], dates[1:])
        ]

    # TODO: Make the sample function use the factory.sample function to avoid double codeblocks
    def sample(self, duration, n=1, overlap=False, resolution=None):
        """Sample random sub-intervals from the current interval

        Parameters
        ----------
        duration : timedelta
            Duration of the sample intervals
        n : int, default 1
            Number of intervals to return
        overlap : bool, default False
            Whether the returned sample intervals can overlap
        resolution : timedelta, optional
            The resolution to which all inputs and outputs will be rounded. Defaults to your index resolution.

        Returns
        -------
        list of Interval
            Randomly sampled intervals
        """

        resolution = TimedeltaFactory(client=self.client).get(resolution) or self.client.resolution
        duration = TimedeltaFactory(client=self.client).get(duration)

        # round the intervals

        interval = self.floor(resolution=resolution)
        duration = TimedeltaFactory(client=self.client).round(duration)

        relative_duration = duration/resolution

        if overlap:
            max_value = int((interval.duration - duration)/resolution)
            values = [random.randint(0, max_value) for _ in range(n)]
            values.sort()
        else:
            max_value = int((interval.duration - n*duration)/resolution)
            values = [random.randint(0, max_value) for _ in range(n)]
            values.sort()
            values = [value + i*relative_duration for i, value in enumerate(values)]

        return [
            IntervalFactory(client=self.client)(
                interval.start + value * resolution,
                interval.start + value * resolution + duration,
                data=self.data,
                ) for value in values
        ]

    def __json__(self):
        return {"startDate": time_json(self.start), "endDate": time_json(self.end)}

    def _json_short(self):
        """Json representation with start/end rather than startDate/endDate"""
        return {"start": time_json(self.start), "end": time_json(self.end)}

    def __contains__(self, item):
        try:
            return (self.start <= item.start) and (item.end <= self.end)
        except AttributeError:
            item = DatetimeFactory(client=self.client).get(item)
            return (self.start <= item) and (item <= self.end)

    def __truediv__(self, other):
        overlap = max(0, (min(self.end, other.end) - max(self.start, other.start)).total_seconds())
        return overlap/other.total_seconds()

    # TODO: is this really logical behaviour? A user might also expect the end timestamp to increase
    def __add__(self, other):
        other = TimedeltaFactory(client=self.client).get(other)
        return IntervalFactory(client=self.client)(self.start+other, self.end+other)

    # TODO: cfr. __add__
    def __radd__(self, other):
        return self.__add__(other)

    def __repr__(self):
        value_str = ", ".join([f"{key}: {value}" for key, value in self.data.items()])
        if value_str:
            value_str = f" | {value_str} "
        return f"<< {type(self).__name__} | {self.start} | {self.duration} {value_str}>>"

    def __getitem__(self, item):
        return self.data.__getitem__(item)

    def __setitem__(self, key, value):
        if not isinstance(key, str):
            raise TypeError(f"{self.__class__.__name__} keys can only be strings")
        self.data.__setitem__(key, value)

    def __delitem__(self, key):
        self.data.__delitem__(key)

    def __iter__(self):
        return self.data.__iter__()

    def __len__(self):
        return self.data.__len__()

    def __bool__(self):
        # An existing interval should always evaluate to True
        # This implementation is needed to avoid evaluating to False when data is empty
        return True


class IntervalFactory(TrendMinerFactory):
    tm_class = Interval

    def __call__(self, start, end=None, data=None, is_open=False):
        """Create a new Interval

        Parameters
        ----------
        start : datetime or str
            The start timestamp
        end : datetime or str, optional
            The end timestamp. Defaults to the current time.
        data : dict, optional
            The data attached to the interval
        is_open : bool, default False
            Whether the Interval is open-ended at creation time
        """
        return self.tm_class(
            client=self.client,
            start=start,
            end=end or self.client.now(),
            data=data,
            is_open=False,
        )

    def from_timedelta(self, ref):
        """Create an interval from a timedelta

        Creates an interval with the given duration that runs up until the current time. Gives the last x time.

        Parameters
        ----------
        ref : timedelta or str
            The duration of the interval as a timedelta, or a string (e.g., '8h', '3M', '17d 15h 3m 12s')

        Returns
        -------
        Interval
            An interval with the given duration, with as end timestamp the current time
        """
        duration = TimedeltaFactory(client=self.client).get(ref)
        end = self.client.now()
        start = end - duration
        return self.tm_class(client=self.client, start=start, end=end, is_open=False, data=None)

    def from_tuple(self, ref):
        """Create an interval from a tuple of start and end timestamps

        Parameters
        ----------
        ref : tuple
            Tuple of start and end timestamps. Can contain datetime or string.

        Returns
        -------
        Interval
        """
        return self.tm_class(client=self.client, start=ref[0], end=ref[1], is_open=False, data=None)

    def range(self, start=None, end=None, n_intervals=None, freq="D", normalize=False):
        """Uses pandas.date_range to generate intervals with a fixed frequency

        Generates a range over the given timespan using pandas.data_range, and then converts those into intervals by
        taking iterating over the returned datetimes. The timezone given to date_range is always the client timezone.
        More info: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.date_range.html

        Keep in mind that the returned intervals are always interlocking. For example, requesting business days
        (freq='B') will return a series of four 1-day intervals followed by a 3-day interval (Friday-Monday).

        Attributes
        ----------
        start : datetime, optional
            Left bound for generating intervals
        end : datetime, optional
            Right bound for generating intervals
        n_intervals : int, optional
            number of intervals to generate
        freq : str or pandas.DateOffset, default 'D'
            Frequency strings can have multiples, e.g. '5H'. List of frequency aliases can be found here:
            https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases
        normalize : bool, default False
            Normalize start/end dates to midnight before generating date range

        Returns
        -------
        intervals : list of Interval

        """

        if n_intervals is None:
            periods = None
        else:
            periods = n_intervals + 1

        dates = pd.date_range(
            start=DatetimeFactory(client=self.client).get(start),
            end=DatetimeFactory(client=self.client).get(end),
            periods=periods,
            freq=freq,
            normalize=normalize,
            tz=self.client.tz,
        ).tolist()

        return [self.__call__(start, end) for start, end in zip(dates[0:-1], dates[1:])]

    # TODO: span keyword naming is not consistent with other similar implementations
    # TODO: should take resolution argument
    def invert(self, intervals, span=None):
        """Return intervals consisting of the time between the input intervals

        The output will always be sorted from oldest to newest intervals.

        Parameters
        ----------
        intervals : list
            List of intervals that need to be inverted
        span : Interval, optional
            Range over which the intervals need to be inverted. When given, the time from the start of the span to the
            start of the first input interval, and the time from the last input interval to the end of the range are
            also returned as part of the inverted intervals, as long as they are not shorter than the index resolution
            (to avoid small intervals at the edges as a result of rounding). The span needs to encompass all input
            intervals. When no span is given, only the intervals inbetween the input intervals are returned as inverted
            intervals.

        Returns
        -------
        list of Interval
            inverted intervals

        """
        intervals = self.union(intervals)
        intervals = sorted(intervals, key=lambda x: x.start)

        start_times = [interval.end for interval in intervals[:-1]]
        end_times = [interval.start for interval in intervals[1:]]

        inverted_intervals = [self.__call__(start, end) for start, end in zip(start_times, end_times)]

        if span is not None:
            span = self.get(span)
            first_interval = self.__call__(span.start, intervals[0].start)
            last_interval = self.__call__(intervals[-1].end, span.end)
            if first_interval.duration >= self.client.resolution:
                inverted_intervals.insert(0, first_interval)
            if last_interval.duration >= self.client.resolution:
                inverted_intervals.append(last_interval)

        return inverted_intervals

    def union(self, intervals):
        """Joins overlapping intervals together

        Parameters
        ----------
        intervals : list of Interval
            Potentially overlapping intervals

        Returns
        -------
        list of Interval
            Reduced non-overlapping list of intervals

        """
        intervals = self.list(intervals)

        # Longer intervals first for speed
        intervals = sorted(intervals, key=lambda x: x.duration, reverse=True)

        new_intervals = []
        while len(intervals) > 0:
            current_interval = intervals[0]
            overlapping = [current_interval]
            non_overlapping = []
            for interval in intervals[1:]:
                if (interval.start in current_interval) or (interval.end in current_interval):
                    overlapping.append(interval)
                else:
                    non_overlapping.append(interval)

            if len(overlapping) == 1:
                new_intervals.append(current_interval)
                intervals = non_overlapping
            else:
                new_start = min([interval.start for interval in overlapping])
                new_end = max([interval.end for interval in overlapping])
                current_interval = self.__call__(new_start, new_end)
                intervals = [current_interval] + non_overlapping

        return sorted(new_intervals, key=lambda x: x.start)

    def sample(self, intervals, duration, n=1, overlap=False, resolution=None):
        """Sample random sub-intervals from a given list of intervals

        Parameters
        ----------
        intervals : list of Interval
            Intervals from which to sample. Input intervals are sampled proportional to their duration.
        duration : timedelta
            Duration of the sample intervals
        n : int, default 1
            Number of intervals to return
        overlap : bool, default False
            Whether the returned sample intervals can overlap
        resolution : timedelta, optional
            The resolution to which all inputs and outputs will be rounded. Defaults to your index resolution.

        Returns
        -------
        list of Interval
            Randomly sampled intervals
        """

        resolution = TimedeltaFactory(client=self.client).get(resolution) or self.client.resolution
        duration = TimedeltaFactory(client=self.client).get(duration)
        intervals = self.union(intervals)
        intervals = [interval.floor(resolution=resolution) for interval in intervals]

        # Determine how many samples to draw from each interval
        weights = [interval.duration.total_seconds() for interval in intervals]
        groups = range(0, len(intervals))

        if overlap:
            valid = np.array([interval.duration >= duration for interval in intervals])
            selection = np.array(random.choices(groups, weights=weights*valid, k=n))
            counter = np.array([sum(selection == group) for group in groups], dtype=int)

        else:
            max_samples = [np.floor(interval.duration/duration) for interval in intervals]
            sample_limit = int(sum(max_samples))

            if sample_limit < n:
                raise ValueError(f"Can only extract {sample_limit} non-overlapping samples, {n} requested")

            counter = np.zeros(len(intervals), dtype=int)
            for i in range(0, n):
                valid = counter < max_samples
                group = random.choices(groups, weights=weights*valid)
                counter[group] += 1

        return [
            sample for interval, c in zip(intervals, counter)
            for sample in interval.sample(duration=duration, n=c, resolution=resolution, overlap=overlap)
        ]

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Interval
        """
        return self.tm_class(
            client=self.client,
            start=data["startDate"],
            end=data["endDate"],
            is_open=data.get("openEnded", False),
        )

    def _from_json_short(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Interval
        """
        return self.tm_class(
            client=self.client,
            start=data["start"],
            end=data["end"],
            is_open=False,
        )

    def _from_json_search_result(self, data):
        properties = data["properties"]
        is_open = properties.pop("openEnded")
        return self.tm_class(
            client=self.client,
            start=data["start"],
            end=data["end"],
            is_open=is_open,
            identifier=data["id"],
            data={
                **data["calculations"],
                **properties,
            }
        )

    def _from_json_similarity_search_query(self, data):
        return self.tm_class(
            client=self.client,
            start=data["originalStartDate"],
            end=data["originalEndDate"],
            is_open=False,
            data=None,
        )

    def _from_json_fingerprint_layer(self, data):
        return self.tm_class(
            client=self.client,
            start=data["timePeriodStart"],
            end=data["timePeriodEnd"],
            is_open=False,
            data=None,
        )

    def _from_json_fingerprint_search(self, data):
        return self.tm_class(
            client=self.client,
            start=data["startDate"],
            end=data["endDate"],
            is_open=data["openEnded"],
            data={
                "score": data["score"]
            }
        )

    @property
    def _get_methods(self):
        return self.from_timedelta, self.from_tuple
