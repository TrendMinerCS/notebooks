from trendminer_interface.base import TrendMinerFactory, LazyLoadingClass, LazyAttribute, Savable
from trendminer_interface import _input as ip


class ConnectorClient:
    @property
    def connector(self):
        return ConnectorFactory(client=self)


class Connector(Savable, LazyLoadingClass):
    endpoint = "/ds/connectors/"

    def __init__(
            self,
            client,
            identifier,
            name,
            host,
            username,
    ):

        super().__init__(client=client, identifier=identifier)

        self.name = name
        self.username = username
        self.host = host

    def __json__(self, password=None):
        return {
            "connectorId": self.identifier,
            "host": self.host,
            "name": self.name,
            "username": self.username,
            "password": password,
        }

    def post(self, password=""):
        self.identifier = None  # prevents accidental overwriting
        payload = self.__json__(password=password)
        response = self.client.session.post(self.endpoint, json=payload)
        self._post_updates(response)

    def put(self, password=""):
        payload = self.__json__(password=password)
        response = self.client.session.put(self.link, json=payload)
        self._put_updates(response)

    def _post_updates(self, response):
        self.identifier = response.json()["connectorId"]

    def blueprint(self):
        raise NotImplementedError

    def _full_instance(self):
        return ConnectorFactory(client=self.client).get(self.identifier)

    def __repr__(self):
        return f"<< Connector | {self._repr_lazy('name')} >>"


class ConnectorFactory(TrendMinerFactory):
    tm_class = Connector

    def __call__(self, name, host, username="", password=""):
        return Connector(
            client=self.client,
            identifier=None,
            name=name,
            host=host,
            username=username,
        )

    def from_name(self, ref):
        return ip.object_match_nocase(self.all(), attribute="name", value=ref)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    def _from_json_identifier_only(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data,
            name=LazyAttribute(),
            host=LazyAttribute(),
            username=LazyAttribute(),
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Connector
        """
        return self.tm_class(
            client=self.client,
            identifier=data["connectorId"],
            name=data["name"],
            host=data["host"],
            username=data["username"],
        )

