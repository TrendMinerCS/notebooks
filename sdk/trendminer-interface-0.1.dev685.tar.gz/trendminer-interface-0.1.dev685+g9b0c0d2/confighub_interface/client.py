import pytz

from trendminer_interface.times import TimeClient
from trendminer_interface.authentication import BaseClient, TrendMinerSession

from .connector import ConnectorClient
from .user import ConfigUserClient
from .datasource import DatasourceClient
from .access import AccessClient
from .group import GroupClient
from .client_user import ClientUserClient


class ConfigClientCollection(
    BaseClient,
    ConnectorClient,
    ConfigUserClient,
    DatasourceClient,
    AccessClient,
    GroupClient,
    ClientUserClient,
    TimeClient,
):
    """Collects clients. Used as base for ConfigClient and MockConfigClient."""
    def __init__(self, url, client_id, client_secret, username, password, verify, keep_history, tz, session_type):
        BaseClient.__init__(
            self,
            url=url,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            verify=verify,
            keep_history=keep_history,
            session_type=session_type,
            token=None,
        )
        TimeClient.__init__(self, tz=tz)


class ConfigClient(ConfigClientCollection):
    def __init__(self, url, client_id, client_secret, username, password,  verify=True, keep_history=False, tz=pytz.utc):
        ConfigClientCollection.__init__(
            self,
            url=url,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            verify=verify,
            keep_history=keep_history,
            tz=tz,
            session_type=TrendMinerSession,
        )