import pandas as pd
import json
from trendminer_interface.asset import Asset, Attribute


def test_asset(user1, af_name, prefix):

    # Root
    root = user1.asset.root()
    print(root.children)

    # Asset get
    asset = user1.asset.from_path(f"{af_name}/Hasselt/Plant")
    assert user1.asset.from_identifier(asset.identifier)
    asset = user1.asset.get(f"{af_name}/Hasselt/Plant")
    assert asset.source
    assert asset.children
    assert asset.parent
    assert asset.path

    # Attribute get
    assert user1.asset.from_path(f"{af_name}/Hasselt/Time/Hour")
    assert user1.asset.from_identifier(asset.identifier)
    attribute = user1.asset.get(f"{af_name}/Hasselt/Time/Hour")
    assert attribute.source
    assert attribute.tag
    assert attribute.interpolation in ["LINEAR", "STEPPED"]
    assert attribute.isnumeric()
    assert json.dumps(attribute.__json__())

    assert isinstance(attribute.parent, Asset)
    assert attribute.path

    # Retrieving from context items
    for component in [attribute, asset]:
        item = user1.context.item(
            context_type="INFORMATION",
            components=[component],
            events=[user1.time.now()],
        )

        item.post()

        item = user1.context.item.from_identifier(item.identifier)
        assert isinstance(item.components[0], type(component))

        item.delete()

    # Retrieving from current value tile
    db = user1.dashboard(
        name=prefix,
        tiles=[
            user1.dashboard.values(
                [user1.dashboard.values.entry(component=attribute)],
                x=0,
                y=0
            )
        ]
    )
    db.post()
    db = user1.dashboard.from_identifier(db.identifier)
    assert isinstance(db.tiles[0].content[0].component, Attribute)
    db.delete()

    # Asset search
    assert user1.asset.by_template("time tags")
    assert user1.asset.by_template("time tags", frameworks=[af_name])

    assert user1.asset.by_name(ref="Hasselt")
    assert user1.asset.by_name(ref="Hasselt", frameworks=af_name)

    assert user1.asset.by_description(ref="US offices")
    assert user1.asset.by_description(ref="US offices", frameworks=af_name)

    assert user1.asset.search("US offices")

    # Attribute search
    assert user1.asset.by_name(ref="day", frameworks=[af_name])
    assert user1.asset.by_template(ref="day", frameworks=af_name)
    assert user1.asset.by_description(ref="Product density", frameworks=[af_name])


def test_frameworks(admin, af_name):

    # Frameworks
    assert len(admin.asset.framework.all()) > 0
    af = admin.asset.framework.from_name(af_name)
    af = admin.asset.framework.from_identifier(af.identifier)
    af.export()
    assert af.edited is False
    assert af.root_asset

    # Sync status
    assert len(admin.asset.framework.sync.all()) > 0
    assert af.sync.status == "DONE"
    assert af.sync.name
    assert af.sync.ended > af.sync.started
    assert af.af_type


def test_framework_create(admin, prefix, user1, mock):

    # Create
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[
            ["", "/" + prefix, prefix, prefix, "ASSET", prefix, "", ""],
            ["", f"/{prefix}/attribute", "attribute", "a dummy attribute", "ATTRIBUTE", "dummy attribute template",
             "TM_hour_Europe_Brussels", ""]
        ],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.post()
    print(af.ordering)
    af.wait_for_sync(sleep=(not mock)*0.5)
    af = admin.asset.framework.from_identifier(af.identifier)

    af.published = True
    af.put()

    af.export()
    af.df.loc[0, "description"] = "updated description"
    assert af.edited is True
    af.put()

    # Access rights
    asset = af.root_asset
    asset.access.add(user1.username, "read")
    print(asset.access.all())
    print(asset.children[0].access_inherited.all())
    asset.access.remove(user1.username)
    print(asset.access.all())
    asset.access.add(user1.username, "browse")
    print(asset.access.all())
    asset.access.add("everyone", "read")
    print(asset.access.all())
    asset.access.clear()
    print(asset.access.all())

    # Retrieve without permissions
    asset_no_access = user1.asset.from_path_hex(asset.path_hex)

    # Test getting deleted attributes
    attribute = admin.asset.from_path(f"{prefix}/{prefix}/attribute")
    item = admin.context.item(
        context_type="INFORMATION",
        components=[attribute],
        events=[admin.time.now()]
    )
    item.post()
    af.delete()
    assert admin.asset.from_identifier(attribute.identifier)
    assert admin.context.item.from_identifier(item.identifier).components[0]
    item.delete()


def test_framework_errors(admin, prefix):
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "incorrect path", prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.post()
    af.wait_for_sync()
    assert isinstance(af.get_errors(), pd.DataFrame)
    af.delete()


def test_from_trendhub_attribute(user1, af_name, prefix):
    attribute = user1.asset.from_path(f"{af_name}/Hasselt/Time/Hour")
    thv = user1.trend.view(
        layers=["8h"],
        entries=[attribute],
        name=prefix,
    )
    thv.post()

    thv = user1.trend.view.from_identifier(thv.identifier)
    assert thv.entries[0].source
