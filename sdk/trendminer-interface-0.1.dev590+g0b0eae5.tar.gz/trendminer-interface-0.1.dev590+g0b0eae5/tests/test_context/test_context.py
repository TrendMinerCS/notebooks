from pprint import pprint


def test_view(user1, prefix):
    folder = user1.folder(prefix)
    folder.post()
    view = user1.context.view(
        [
            user1.context.filter.period("1y")
        ],
        name=prefix,
        description=prefix,
        folder=prefix,
    )
    view.post()
    view = user1.context.view.from_path(f"{prefix}/{prefix}")
    print(view)
    assert len(view.filters) > 0
    folder.delete()

    filters = [
        user1.context.filter.period('1h')
    ]
    view = user1.context.view(filters=filters, name=prefix)
    view.post()
    view.filters = view.filters + [user1.context.filter.users(user1.user.self())]
    view.description = "new_description"
    view.put()
    view2 = user1.context.view.get(view.identifier)
    assert view2.description == view.description
    view2.delete()


def test_full_flow(admin, prefix):

    # fields
    key_num = prefix + "num"
    f_num = admin.context.field(key=key_num,
                                name=key_num,
                                field_type="Numeric",
                                placeholder='numeric field')
    assert isinstance(f_num.blueprint, dict), 'AssertionError: blueprint is not dict'
    f_num.post()
    f_num.placeholder = 'edited placeholder'
    f_num.put()

    key_str = prefix + "str"
    f_str = admin.context.field(key=key_str,
                                name=key_str,
                                field_type="STRING",
                                placeholder='string field')
    f_str.post()
    f_str.name = f_str.name + "_edited"
    f_str.put()

    key_enum = prefix + "enum"
    f_enum = admin.context.field(key=key_enum,
                                 name=key_enum,
                                 field_type="enumeration",
                                 placeholder=None,
                                 options=["yes", "no"])
    f_enum.post()
    f_enum.options.append("maybe")
    f_enum.put()

    assert admin.context.field.all()

    # workflow
    wf = admin.context.workflow(name=prefix + "wf",
                                states=["QA_start", "QA_end"],
                                )
    wf.post()
    # types
    type1 = admin.context.type(key=prefix + "t1",
                               name="QA type 1",
                               workflow=wf,
                               fields=[f_num.name, f_str.key, f_enum.identifier],
                               color="green",
                               audit_trail_enabled=True,
                               approvals_enabled=True
                               )
    type1.post()
    type1.name = type1.name + " updated"
    type1.put()

    type2 = admin.context.type(key=prefix + "t2",
                               name="QA type 2",
                               workflow=None,
                               fields=[f_num, f_str],
                               color=None,
                               audit_trail_enabled=False,
                               approvals_enabled=False
                               )
    type2.post()
    type2.color = 'blue'
    type2.fields = type2.fields + [f_enum]
    type2.put()

    # items
    other_property_key = prefix + '_other'
    component = 'TM_day_Europe_Brussels'
    item = admin.context.item(context_type=type1.key,
                              components=[component],
                              events=admin.time.slice('1h'),
                              keywords=[prefix],
                              fields={
                                 f_str: 'test',
                                 f_enum.key: 'yes',
                                 f_num.key: 12.3,
                                 other_property_key: 'other',
                             }
                              )
    item.post()
    item.description = prefix
    item.put()
    item.approve()
    item.remove_approval()
    item.approve()
    assert item.interval.data
    assert item.key == admin.context.item.get(item.identifier).key
    assert admin.context.item.get(item.key).description == item.description

    # filters
    kw = admin.context.filter.keywords([prefix])
    filter_sets = [
        [kw],
        [admin.context.filter.field(field=f_num, values=[">12", ('<', 15)])],
        [admin.context.filter.field(field=f_str, values=['test', 'foo'])],
        [admin.context.filter.field(field=f_enum, values=['yes', 'maybe'])],
        [admin.context.filter.property(key=other_property_key, values='other')],
        [admin.context.filter.approval(True), kw],
        [admin.context.filter.context_types([type1.key])],
        [admin.context.filter.users([admin.user.self()]), kw],
        [admin.context.filter.components([component]), kw],
        [admin.context.filter.duration(['> 50m', ('<', 3700)]), kw],
        [admin.context.filter.description(prefix)],
        [admin.context.filter.interval(admin.time.interval('1h')), kw],
        [admin.context.filter.period(admin.time.period('1h')), kw],
        [admin.context.filter.states(['QA_end']), kw],
        [admin.context.filter.interval(admin.time.interval('1h').shift("5m"), created_date=True), kw],
        [admin.context.filter.created_date(('<=', admin.time.now() + admin.time.timedelta("5m"))), kw]
    ]

    for i, filters in enumerate(filter_sets):
        print(f"{i} - {filters}")
        chv = admin.context.view(
            name=f"{prefix}_view{i}",
            description="view test",
            filters=filters,
        )
        chv.post()
        chv = admin.context.view.from_identifier(chv.identifier)
        assert len(chv.search_items()) == 1
        chv.delete()

    # cleanup
    item.delete()
    type1.delete()
    type2.delete()
    f_num.delete()
    f_str.delete()
    f_enum.delete()
    wf.delete()


def test_items(user1):
    hour = user1.tag.from_name("TM_hour_Europe_Brussels")
    anomaly = user1.context.item(context_type="ANOMALY",
                                 events=["2021", "2022"],
                                 components=["TM_day_Europe_Brussels"])

    anomaly = user1.context.item(context_type="ANOMALY",
                                 events=user1.time.interval("2021", "2022"),
                                 components=["TM_day_Europe_Brussels"])

    info = user1.context.item(context_type="INFORMATION",
                              events=["2021-01-01"],
                              components=["TM_day_Europe_Brussels"])

    info = user1.context.item(context_type="INFORMATION",
                              events=user1.time.datetime("2021-01-01"),
                              components=["TM_day_Europe_Brussels"])

    info.post()

    info = user1.context.item.get(info.identifier)
    info.delete()

    item = user1.context.item(context_type="ANOMALY",
                              components=["TM_day_Europe_Brussels"],
                              events=user1.time.period("8h"),
                              description="sdk test",
                              keywords=["QA"],
                              )
    hour.calculate(
        intervals=[item],
        operation="start",
        key="hour",
        inplace=True,
        fun=lambda x: f"{x:02}:00"
    )
    assert item.get("hour")
    item.post()
    item = user1.context.item.get(item.key)
    item = user1.context.item.get(item.identifier)
    assert item.get("hour")
    item.delete()

def test_item_history(user1, prefix):
    item = user1.context.item(context_type="ANOMALY",
                              components=["TM_day_Europe_Brussels"],
                              events=user1.time.period("8h"),
                              description="sdk test",
                              keywords=["QA"],
                              )
    item.post()
    history1 = item.history()
    item.description = "sdk test2"
    item.events = user1.time.period("9h")
    item.post()
    history2 = item.history()
    assert history1 != history2, "history should have changed"
    item.delete()


def test_bulk_items(client, prefix):
    intervals = client.time.interval("1y").split(max_size="1d")
    item = client.context.item("Anomaly", components="TM_day_Europe_Brussels", keywords=[prefix])
    items = [item.copy({"events": interval}) for interval in intervals]
    df = client.io.context.structure(items)
    print(df)
    client.context.item.bulk_post(items)
    chv = client.context.view(
        filters=[
            client.context.filter.keywords([prefix])
        ]
    )
    assert len(chv.search_items()) == len(intervals)
    chv.delete_items()


def test_from_search(user1, prefix):
    vbs = user1.search.value(
        queries=[("TM_hour_Europe_Brussels", ">", 12)],
        operator="AND"
    )

    results = vbs.get_results("1M")

    item = user1.context.item(
        context_type="ANOMALY",
        components="TM_day_Europe_Brussels",
        events=None,
        description=None,
        fields=None,
        keywords=[prefix, f"{prefix}/{prefix}.xlsx", prefix]
    )

    items = [item.copy({"events": result}) for result in results]

    user1.context.item.bulk_post(items)

    chv = user1.context.view(
        filters=[user1.context.filter.keywords([prefix])]
    )
    assert len(chv.search_items()) == len(items)
    chv.delete_items()


def test_filter_modes(admin, prefix):

    # create context fields
    key_num = prefix + "num"
    f_num = admin.context.field(key=key_num,
                                name=key_num,
                                field_type="Numeric",
                                placeholder='numeric field')
    f_num.post()

    key_str = prefix + "str"
    f_str = admin.context.field(key=key_str,
                                name=key_str,
                                field_type="STRING",
                                placeholder='string field')
    f_str.post()

    key_enum = prefix + "enum"
    f_enum = admin.context.field(key=key_enum,
                                 name=key_enum,
                                 field_type="enumeration",
                                 placeholder=None,
                                 options=["yes", "no"])
    f_enum.post()

    # create view
    chv = admin.context.view(
        filters=[
            admin.context.filter.period("1M"),
            admin.context.filter.components(mode="non empty"),
            admin.context.filter.description(mode="empty"),
            admin.context.filter.keywords(mode="empty"),
            admin.context.filter.field(f_num, mode="empty"),
            admin.context.filter.field(f_str, mode="empty"),
            admin.context.filter.field(f_enum, mode="empty"),
            admin.context.filter.states(mode="closed")
        ]
    )
    chv.post()
    chv = admin.context.view.from_identifier(chv.identifier)
    pprint([f.__json__() for f in chv.filters])
    chv.search_items()
    chv.delete()
    f_num.delete()
    f_str.delete()
    f_enum.delete()
